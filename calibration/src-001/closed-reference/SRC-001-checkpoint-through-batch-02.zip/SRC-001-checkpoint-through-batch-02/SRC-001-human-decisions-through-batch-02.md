# SRC-001 Human Decisions Through Batch 02

> NONCANONICAL HUMAN-REVIEWED DEVELOPMENT-CALIBRATION RECORD

Criteria remain pinned and unchanged. Exact quotations preserve frozen text, including degraded typography.

## C-001 — duplicate

- Locator: `L16-L16`
- Original criterion: `1`
- Human status: `AUTHORITATIVE_FOR_THIS_NONCANONICAL_CHECKPOINT`
- Reason: The centrality assertion is retained by the more scoped C-007 occurrence.

### Exact original quote

```text
Relational reasoning is a central component of generally intelligent behavior,
```

- Duplicate representative retained: `C-007`

## C-002 — edit

- Locator: `L16-L17`
- Original criterion: `6`
- Human status: `AUTHORITATIVE_FOR_THIS_NONCANONICAL_CHECKPOINT`
- Reason: Restore the omitted grammatical subject without importing the separate centrality assertion.

### Exact original quote

```text
but has proven
diﬃcult for neural networks to learn.
```

### C-002 — criterion 6

- Evidence locator: `L16-L17`
- Exact evidence:

```text
but has proven
diﬃcult for neural networks to learn.
```

- Normalized wording: Relational reasoning has proven difficult for neural networks to learn.
- Dependencies: `C-001 (source-sentence antecedent; itself duplicate of C-007)`
- Flags: `contrastive-but-retained-as-context`
- Normalization record status: `human-adopted`

## C-003 — calibration-accept

- Locator: `L17-L19`
- Original criterion: `2`
- Human status: `AUTHORITATIVE_FOR_THIS_NONCANONICAL_CHECKPOINT`
- Reason: Atomic RN module and problem-class statement.

### Exact original quote

```text
In this paper we describe how to use Relation Networks
(RNs) as a simple plug-and-play module to solve problems that fundamentally hinge on relational
reasoning.
```

### C-003 — criterion 2

- Evidence locator: `L17-L19`
- Exact evidence:

```text
In this paper we describe how to use Relation Networks
(RNs) as a simple plug-and-play module to solve problems that fundamentally hinge on relational
reasoning.
```

- Normalized wording: In this paper we describe how to use Relation Networks (RNs) as a simple plug-and-play module to solve problems that fundamentally hinge on relational reasoning.
- Normalization record status: `mechanical-linewrap-only-checkpoint-transcription`

## C-004 — calibration-accept

- Locator: `L19-L22`
- Original criterion: `5`
- Human status: `AUTHORITATIVE_FOR_THIS_NONCANONICAL_CHECKPOINT`
- Reason: Preserve all three test domains; state-of-the-art and super-human performance apply only to CLEVR.

### Exact original quote

```text
We tested RN-augmented networks on three tasks: visual question answering
using a challenging dataset called CLEVR, on which we achieve state-of-the-art, super-human
performance; text-based question answering using the bAbI suite of tasks; and complex reasoning
about dynamic physical systems.
```

### C-004 — criterion 5

- Evidence locator: `L19-L22`
- Exact evidence:

```text
We tested RN-augmented networks on three tasks: visual question answering
using a challenging dataset called CLEVR, on which we achieve state-of-the-art, super-human
performance; text-based question answering using the bAbI suite of tasks; and complex reasoning
about dynamic physical systems.
```

- Normalized wording: We tested RN-augmented networks on three tasks: visual question answering using a challenging dataset called CLEVR, on which we achieve state-of-the-art, super-human performance; text-based question answering using the bAbI suite of tasks; and complex reasoning about dynamic physical systems.
- Normalization record status: `mechanical-linewrap-only-checkpoint-transcription`

## C-005 — calibration-accept

- Locator: `L22-L24`
- Original criterion: `5`
- Human status: `AUTHORITATIVE_FOR_THIS_NONCANONICAL_CHECKPOINT`
- Reason: Preserve Sort-of-CLEVR and the without-RN/with-RN comparison.

### Exact original quote

```text
Then, using a curated dataset called Sort-of-CLEVR we show
that powerful convolutional networks do not have a general capacity to solve relational questions,
but can gain this capacity when augmented with RNs.
```

### C-005 — criterion 5

- Evidence locator: `L22-L24`
- Exact evidence:

```text
Then, using a curated dataset called Sort-of-CLEVR we show
that powerful convolutional networks do not have a general capacity to solve relational questions,
but can gain this capacity when augmented with RNs.
```

- Normalized wording: Then, using a curated dataset called Sort-of-CLEVR we show that powerful convolutional networks do not have a general capacity to solve relational questions, but can gain this capacity when augmented with RNs.
- Normalization record status: `mechanical-linewrap-only-checkpoint-transcription`

## C-006 — calibration-accept

- Locator: `L24-L26`
- Original criterion: `4`
- Human status: `AUTHORITATIVE_FOR_THIS_NONCANONICAL_CHECKPOINT`
- Reason: Preserve “can” and “implicitly”; do not strengthen into guaranteed explicit entity identification.

### Exact original quote

```text
Our work shows how a deep learning
architecture equipped with an RN module can implicitly discover and learn to reason about
entities and their relations.
```

### C-006 — criterion 4

- Evidence locator: `L24-L26`
- Exact evidence:

```text
Our work shows how a deep learning
architecture equipped with an RN module can implicitly discover and learn to reason about
entities and their relations.
```

- Normalized wording: Our work shows how a deep learning architecture equipped with an RN module can implicitly discover and learn to reason about entities and their relations.
- Normalization record status: `mechanical-linewrap-only-checkpoint-transcription`

## C-007 — calibration-accept

- Locator: `L28-L29`
- Original criterion: `1`
- Human status: `AUTHORITATIVE_FOR_THIS_NONCANONICAL_CHECKPOINT`
- Reason: Retained representative for relational-reasoning centrality, with entity/property scope and citations.

### Exact original quote

```text
The ability to reason about the relations between entities and their properties is central to generally
intelligent behavior (Figure 1) [ 18, 15].
```

### C-007 — criterion 1

- Evidence locator: `L28-L29`
- Exact evidence:

```text
The ability to reason about the relations between entities and their properties is central to generally
intelligent behavior (Figure 1) [ 18, 15].
```

- Normalized wording: The ability to reason about the relations between entities and their properties is central to generally intelligent behavior (Figure 1) [ 18, 15].
- Normalization record status: `mechanical-linewrap-only-checkpoint-transcription`

## C-008 — calibration-accept

- Locator: `L29-L31`
- Original criterion: `4`
- Human status: `AUTHORITATIVE_FOR_THIS_NONCANONICAL_CHECKPOINT`
- Reason: Illustrative scenario only; do not universalize.

### Exact original quote

```text
Consider a child proposing a race between the two trees
in the park that are furthest apart: the pairwise distances between every tree in the park must be
inferred and compared to know where to run.
```

### C-008 — criterion 4

- Evidence locator: `L29-L31`
- Exact evidence:

```text
Consider a child proposing a race between the two trees
in the park that are furthest apart: the pairwise distances between every tree in the park must be
inferred and compared to know where to run.
```

- Normalized wording: Consider a child proposing a race between the two trees in the park that are furthest apart: the pairwise distances between every tree in the park must be inferred and compared to know where to run.
- Normalization record status: `mechanical-linewrap-only-checkpoint-transcription`

## C-009 — calibration-accept

- Locator: `L31-L33`
- Original criterion: `4`
- Human status: `AUTHORITATIVE_FOR_THIS_NONCANONICAL_CHECKPOINT`
- Reason: Illustrative plausible narrative only; preserve contextual integration.

### Exact original quote

```text
Or, consider a reader piecing together evidence to
predict the culprit in a murder-mystery novel: each clue must be considered in its broader context to
build a plausible narrative and solve the mystery.
```

### C-009 — criterion 4

- Evidence locator: `L31-L33`
- Exact evidence:

```text
Or, consider a reader piecing together evidence to
predict the culprit in a murder-mystery novel: each clue must be considered in its broader context to
build a plausible narrative and solve the mystery.
```

- Normalized wording: Or, consider a reader piecing together evidence to predict the culprit in a murder-mystery novel: each clue must be considered in its broader context to build a plausible narrative and solve the mystery.
- Normalization record status: `mechanical-linewrap-only-checkpoint-transcription`

## C-010 — calibration-accept

- Locator: `L34-L34`
- Original criterion: `1`
- Human status: `AUTHORITATIVE_FOR_THIS_NONCANONICAL_CHECKPOINT`
- Reason: Preserve symbolic-AI scope, “inherently,” and citations [32, 11].

### Exact original quote

```text
Symbolic approaches to artiﬁcial intelligence are inherently relational [32, 11].
```

### C-010 — criterion 1

- Evidence locator: `L34-L34`
- Exact evidence:

```text
Symbolic approaches to artiﬁcial intelligence are inherently relational [32, 11].
```

- Normalized wording: Symbolic approaches to artiﬁcial intelligence are inherently relational [32, 11].
- Normalization record status: `mechanical-linewrap-only-checkpoint-transcription`

## C-011 — calibration-accept

- Locator: `L34-L36`
- Original criterion: `2`
- Human status: `AUTHORITATIVE_FOR_THIS_NONCANONICAL_CHECKPOINT`
- Reason: Retain the coherent procedure: define symbolic relations, then reason using listed methods.

### Exact original quote

```text
Practitioners deﬁne
the relations between symbols using the language of logic and mathematics, and then reason about
these relations using a multitude of powerful methods, including deduction, arithmetic, and algebra.
```

### C-011 — criterion 2

- Evidence locator: `L34-L36`
- Exact evidence:

```text
Practitioners deﬁne
the relations between symbols using the language of logic and mathematics, and then reason about
these relations using a multitude of powerful methods, including deduction, arithmetic, and algebra.
```

- Normalized wording: Practitioners deﬁne the relations between symbols using the language of logic and mathematics, and then reason about these relations using a multitude of powerful methods, including deduction, arithmetic, and algebra.
- Normalization record status: `mechanical-linewrap-only-checkpoint-transcription`

## C-012 — too-broad

- Locator: `L37-L38`
- Original criterion: `6`
- Human status: `AUTHORITATIVE_FOR_THIS_NONCANONICAL_CHECKPOINT`
- Reason: The sentence contains two independently adjudicable symbolic-approach limitations.

### Exact original quote

```text
But symbolic approaches suﬀer from the symbol grounding problem and are not robust to small
task and input variations [ 11].
```

### C-012a — criterion 6

- Evidence locator: `L37-L38`
- Exact evidence:

```text
But symbolic approaches suﬀer from the symbol grounding problem
```

- Normalized wording: Symbolic approaches suffer from the symbol grounding problem.
- Citation scope: [11] shared across the original sentence
- Normalization record status: `human-adopted`

### C-012b — criterion 6

- Evidence locator: `L37-L38`
- Exact evidence:

```text
and are not robust to small
task and input variations [ 11].
```

- Normalized wording: Symbolic approaches are not robust to small task and input variations.
- Citation scope: [11] shared across the original sentence
- Normalization record status: `human-adopted`

## C-013 — too-broad

- Locator: `L38-L39`
- Original criterion: `4`
- Human status: `AUTHORITATIVE_FOR_THIS_NONCANONICAL_CHECKPOINT`
- Reason: Representation construction and generalization are independently adjudicable claims.

### Exact original quote

```text
Other approaches, such as those based on statistical learning, build
representations from raw data and often generalize across diverse and noisy conditions [ 25].
```

### C-013a — criterion 2

- Evidence locator: `L38-L39`
- Exact evidence:

```text
Other approaches, such as those based on statistical learning, build
representations from raw data
```

- Normalized wording: Approaches such as those based on statistical learning build representations from raw data.
- Citation scope: [25] shared across the original sentence
- Normalization record status: `human-adopted`

### C-013b — criterion 1

- Evidence locator: `L38-L39`
- Exact evidence:

```text
and often generalize across diverse and noisy conditions [ 25].
```

- Normalized wording: Approaches such as those based on statistical learning often generalize across diverse and noisy conditions.
- Citation scope: [25] shared across the original sentence
- Flags: `preserve-often`
- Normalization record status: `human-adopted`

## C-014 — calibration-accept

- Locator: `L39-L41`
- Original criterion: `6`
- Human status: `AUTHORITATIVE_FOR_THIS_NONCANONICAL_CHECKPOINT`
- Reason: Preserve data-poor condition, sparse-but-complex relational structure, “often,” and citations.

### Exact original quote

```text
However,
a number of these approaches, such as deep learning, often struggle in data-poor problems where the
underlying structure is characterized by sparse but complex relations [ 7, 23].
```

### C-014 — criterion 6

- Evidence locator: `L39-L41`
- Exact evidence:

```text
However,
a number of these approaches, such as deep learning, often struggle in data-poor problems where the
underlying structure is characterized by sparse but complex relations [ 7, 23].
```

- Normalized wording: However, a number of these approaches, such as deep learning, often struggle in data-poor problems where the underlying structure is characterized by sparse but complex relations [ 7, 23].
- Normalization record status: `mechanical-linewrap-only-checkpoint-transcription`

## C-015 — calibration-accept

- Locator: `L56-L60`
- Original criterion: `1`
- Human status: `AUTHORITATIVE_FOR_THIS_NONCANONICAL_CHECKPOINT`
- Reason: Illustrative CLEVR caption; preserve four-object relational versus one-object attribute contrast.

### Exact original quote

```text
Figure 1: An illustrative example from the CLEVR dataset of relational reasoning . An
image containing four objects is shown alongside non-relational and relational questions. The
relational question requires explicit reasoning about the relations between the four objects in the
image, whereas the non-relational question requires reasoning about the attributes of a particular
object.
```

### C-015 — criterion 1

- Evidence locator: `L56-L60`
- Exact evidence:

```text
Figure 1: An illustrative example from the CLEVR dataset of relational reasoning . An
image containing four objects is shown alongside non-relational and relational questions. The
relational question requires explicit reasoning about the relations between the four objects in the
image, whereas the non-relational question requires reasoning about the attributes of a particular
object.
```

- Normalized wording: Figure 1: An illustrative example from the CLEVR dataset of relational reasoning . An image containing four objects is shown alongside non-relational and relational questions. The relational question requires explicit reasoning about the relations between the four objects in the image, whereas the non-relational question requires reasoning about the attributes of a particular object.
- Normalization record status: `mechanical-linewrap-only-checkpoint-transcription`

## C-016 — calibration-accept

- Locator: `L63-L64`
- Original criterion: `7`
- Human status: `AUTHORITATIVE_FOR_THIS_NONCANONICAL_CHECKPOINT`
- Reason: Preserve “we explore”; this is not a proven general solution.

### Exact original quote

```text
Here, we explore “Relation Networks” (RN) as a general solution to relational reasoning in neural
networks.
```

### C-016 — criterion 7

- Evidence locator: `L63-L64`
- Exact evidence:

```text
Here, we explore “Relation Networks” (RN) as a general solution to relational reasoning in neural
networks.
```

- Normalized wording: Here, we explore “Relation Networks” (RN) as a general solution to relational reasoning in neural networks.
- Normalization record status: `mechanical-linewrap-only-checkpoint-transcription`

## C-017 — calibration-accept

- Locator: `L64-L64`
- Original criterion: `2`
- Human status: `AUTHORITATIVE_FOR_THIS_NONCANONICAL_CHECKPOINT`
- Reason: Preserve explicit computational focus and citation [35].

### Exact original quote

```text
RNs are architectures whose computations focus explicitly on relational reasoning [ 35].
```

### C-017 — criterion 2

- Evidence locator: `L64-L64`
- Exact evidence:

```text
RNs are architectures whose computations focus explicitly on relational reasoning [ 35].
```

- Normalized wording: RNs are architectures whose computations focus explicitly on relational reasoning [ 35].
- Normalization record status: `mechanical-linewrap-only-checkpoint-transcription`

## C-018 — too-broad

- Locator: `L65-L67`
- Original criterion: `2`
- Human status: `AUTHORITATIVE_FOR_THIS_NONCANONICAL_CHECKPOINT`
- Reason: The related-model inventory and the RN-specific descriptors are independently adjudicable architecture claims.

### Exact original quote

```text
Although several other models supporting relation-centric computation have been proposed, such
as Graph Neural Networks, Gated Graph Sequence Neural Networks, and Interaction Networks,
[37, 26, 2], RNs are simple, plug-and-play, and are exclusively focused on ﬂexible relational reasoning.
```

### C-018a — criterion 2

- Evidence locator: `L65-L67`
- Exact evidence:

```text
Although several other models supporting relation-centric computation have been proposed, such
as Graph Neural Networks, Gated Graph Sequence Neural Networks, and Interaction Networks,
[37, 26, 2]
```

- Normalized wording: Several other models supporting relation-centric computation have been proposed, including Graph Neural Networks, Gated Graph Sequence Neural Networks, and Interaction Networks.
- Citation scope: [37, 26, 2]
- Flags: `nonexhaustive-several`
- Normalization record status: `human-adopted`

### C-018b — criterion 2

- Evidence locator: `L65-L67`
- Exact evidence:

```text
RNs are simple, plug-and-play, and are exclusively focused on ﬂexible relational reasoning.
```

- Normalized wording: RNs are simple, plug-and-play, and exclusively focused on flexible relational reasoning.
- Flags: `source-contrast-retained`
- Normalization record status: `human-adopted`

## C-019 — calibration-accept

- Locator: `L68-L69`
- Original criterion: `4`
- Human status: `AUTHORITATIVE_FOR_THIS_NONCANONICAL_CHECKPOINT`
- Reason: Preserve “can,” joint training, CNN/LSTM scope, implicit object-like representations, and use for relational reasoning.

### Exact original quote

```text
Moreover, through joint training RNs can inﬂuence and shape upstream representations in CNNs
and LSTMs to produce implicit object-like representations that it can exploit for relational reasoning.
```

### C-019 — criterion 4

- Evidence locator: `L68-L69`
- Exact evidence:

```text
Moreover, through joint training RNs can inﬂuence and shape upstream representations in CNNs
and LSTMs to produce implicit object-like representations that it can exploit for relational reasoning.
```

- Normalized wording: Moreover, through joint training RNs can inﬂuence and shape upstream representations in CNNs and LSTMs to produce implicit object-like representations that it can exploit for relational reasoning.
- Normalization record status: `mechanical-linewrap-only-checkpoint-transcription`

## C-020 — too-broad

- Locator: `L70-L72`
- Original criterion: `3`
- Human status: `AUTHORITATIVE_FOR_THIS_NONCANONICAL_CHECKPOINT`
- Reason: The application method and the benchmark difficulty explanation have different claim roles.

### Exact original quote

```text
We applied an RN-augmented architecture to CLEVR [ 15], a recent visual question answering
(QA) dataset on which state-of-the-art approaches have struggled due to the demand for rich
relational reasoning.
```

### C-020a — criterion 3

- Evidence locator: `L70-L72`
- Exact evidence:

```text
We applied an RN-augmented architecture to CLEVR [ 15]
```

- Normalized wording: The authors applied an RN-augmented architecture to CLEVR.
- Citation scope: [15]
- Normalization record status: `human-adopted`

### C-020b — criterion 4

- Evidence locator: `L70-L72`
- Exact evidence:

```text
a recent visual question answering
(QA) dataset on which state-of-the-art approaches have struggled due to the demand for rich
relational reasoning.
```

- Normalized wording: CLEVR is described as a publication-relative recent visual-question-answering dataset on which state-of-the-art approaches had struggled because of the demand for rich relational reasoning.
- Dependencies: `C-020a`
- Citation scope: [15] shared identification context
- Flags: `publication-relative-recent`
- Normalization record status: `human-adopted`

## C-021 — too-narrow-repaired-by-dependency

- Locator: `L72-L73`
- Original criterion: `5`
- Human status: `AUTHORITATIVE_FOR_THIS_NONCANONICAL_CHECKPOINT`
- Reason: The exact quote omits the CLEVR evaluation condition; restore it through dependency rather than widening.

### Exact original quote

```text
Our networks vastly outperformed the best generally-applicable visual QA
architectures, and achieve state-of-the-art, super-human performance.
```

### C-021 — criterion 5

- Evidence locator: `L72-L73`
- Exact evidence:

```text
Our networks vastly outperformed the best generally-applicable visual QA
architectures, and achieve state-of-the-art, super-human performance.
```

- Normalized wording: On CLEVR, the authors report two results for their RN-augmented networks: they vastly outperformed the best generally applicable visual-question-answering architectures, and they achieve state-of-the-art, super-human performance.
- Dependencies: `C-020a`
- Flags: `preserve-source-tense-achieve`
- Normalization record status: `human-adopted`

## C-022 — too-broad

- Locator: `L73-L74`
- Original criterion: `5`
- Human status: `AUTHORITATIVE_FOR_THIS_NONCANONICAL_CHECKPOINT`
- Reason: The reported state-description result and the versatility interpretation are independently adjudicable.

### Exact original quote

```text
RNs also solve CLEVR from
state descriptions, highlighting their versatility in regards to the form of their input.
```

### C-022a — criterion 5

- Evidence locator: `L73-L74`
- Exact evidence:

```text
RNs also solve CLEVR from
state descriptions
```

- Normalized wording: The authors report that RNs also solve CLEVR from state descriptions.
- Dependencies: `C-020a`
- Normalization record status: `human-adopted`

### C-022b — criterion 4

- Evidence locator: `L73-L74`
- Exact evidence:

```text
highlighting their versatility in regards to the form of their input.
```

- Normalized wording: The authors state that solving CLEVR from state descriptions highlights RN versatility with respect to input form.
- Dependencies: `C-022a`
- Flags: `no-invariance-or-universality-imported`
- Normalization record status: `human-adopted`

## C-023 — calibration-accept

- Locator: `L74-L75`
- Original criterion: `5`
- Human status: `AUTHORITATIVE_FOR_THIS_NONCANONICAL_CHECKPOINT`
- Reason: Retain bAbI condition and exact 18/20 result; citation [41] identifies the suite.

### Exact original quote

```text
We also applied
an RN-based architecture to the bAbI text-based QA suite [ 41] and solved 18/20 of the subtasks.
```

### C-023 — criterion 5

- Evidence locator: `L74-L75`
- Exact evidence:

```text
We also applied
an RN-based architecture to the bAbI text-based QA suite [ 41] and solved 18/20 of the subtasks.
```

- Normalized wording: We also applied an RN-based architecture to the bAbI text-based QA suite [ 41] and solved 18/20 of the subtasks.
- Normalization record status: `mechanical-linewrap-only-checkpoint-transcription`

## C-024 — calibration-accept

- Locator: `L76-L77`
- Original criterion: `3`
- Human status: `AUTHORITATIVE_FOR_THIS_NONCANONICAL_CHECKPOINT`
- Reason: Retain training on challenging relational inferences over physical systems and motion-capture data; no metric is supplied.

### Exact original quote

```text
Finally, we trained an RN to make challenging relational inferences about complex physical systems
and motion capture data.
```

### C-024 — criterion 3

- Evidence locator: `L76-L77`
- Exact evidence:

```text
Finally, we trained an RN to make challenging relational inferences about complex physical systems
and motion capture data.
```

- Normalized wording: Finally, we trained an RN to make challenging relational inferences about complex physical systems and motion capture data.
- Normalization record status: `mechanical-linewrap-only-checkpoint-transcription`

## C-025 — calibration-accept

- Locator: `L77-L78`
- Original criterion: `4`
- Human status: `AUTHORITATIVE_FOR_THIS_NONCANONICAL_CHECKPOINT`
- Reason: Retain cross-domain success interpretation and dependency on the domain-specific preceding results.

### Exact original quote

```text
The success of RNs across this set of substantially dissimilar task domains
is testament to the general utility of RNs for solving problems that require relation reasoning.
```

### C-025 — criterion 4

- Evidence locator: `L77-L78`
- Exact evidence:

```text
The success of RNs across this set of substantially dissimilar task domains
is testament to the general utility of RNs for solving problems that require relation reasoning.
```

- Normalized wording: The success of RNs across this set of substantially dissimilar task domains is testament to the general utility of RNs for solving problems that require relation reasoning.
- Dependencies: `C-020a`, `C-021`, `C-022a`, `C-023`, `C-024`
- Normalization record status: `mechanical-linewrap-only-checkpoint-transcription`

## C-026 — edit

- Locator: `L80-L80`
- Original criterion: `1`
- Human status: `AUTHORITATIVE_FOR_THIS_NONCANONICAL_CHECKPOINT`
- Reason: Criterion 2 is the direct fit for the RN architectural-component definition.

### Exact original quote

```text
An RN is a neural network module with a structure primed for relational reasoning.
```

### C-026 — criterion 2

- Evidence locator: `L80`
- Exact evidence:

```text
An RN is a neural network module with a structure primed for relational reasoning.
```

- Normalized wording: An RN is a neural-network module whose structure is primed for relational reasoning.
- Normalization record status: `human-adopted`

## C-027 — calibration-accept

- Locator: `L80-L82`
- Original criterion: `4`
- Human status: `AUTHORITATIVE_FOR_THIS_NONCANONICAL_CHECKPOINT`
- Reason: Retain the design philosophy and the stated mechanism-to-property link.

### Exact original quote

```text
The design
philosophy behind RNs is to constrain the functional form of a neural network so that it captures the
core common properties of relational reasoning.
```

### C-027 — criterion 4

- Evidence locator: `L80-L82`
- Exact evidence:

```text
The design
philosophy behind RNs is to constrain the functional form of a neural network so that it captures the
core common properties of relational reasoning.
```

- Normalized wording: The design philosophy behind RNs is to constrain the functional form of a neural network so that it captures the core common properties of relational reasoning.
- Normalization record status: `mechanical-linewrap-only-checkpoint-transcription`

## C-028 — too-broad

- Locator: `L82-L85`
- Original criterion: `4`
- Human status: `AUTHORITATIVE_FOR_THIS_NONCANONICAL_CHECKPOINT`
- Reason: The RN capacity claim and the two architecture analogies are independently adjudicable.

### Exact original quote

```text
In other words, the capacity to compute relations
is baked into the RN architecture without needing to be learned, just as the capacity to reason
about spatial, translation invariant properties is built-in to CNNs, and the capacity to reason about
sequential dependencies is built into recurrent neural networks.
```

### C-028a — criterion 2

- Evidence locator: `L82-L85`
- Exact evidence:

```text
In other words, the capacity to compute relations
is baked into the RN architecture without needing to be learned
```

- Normalized wording: The capacity to compute relations is built into the RN architecture without needing to be learned.
- Dependencies: `C-027`
- Flags: `capacity-not-specific-relations`
- Normalization record status: `human-adopted`

### C-028b — criterion 2

- Evidence locator: `L82-L85`
- Exact evidence:

```text
just as the capacity to reason
about spatial, translation invariant properties is built-in to CNNs
```

- Normalized wording: The capacity to reason about spatial, translation-invariant properties is built into convolutional neural networks.
- Flags: `analogy-not-paper-result`
- Normalization record status: `human-adopted`

### C-028c — criterion 2

- Evidence locator: `L82-L85`
- Exact evidence:

```text
and the capacity to reason about
sequential dependencies is built into recurrent neural networks.
```

- Normalized wording: The capacity to reason about sequential dependencies is built into recurrent neural networks.
- Flags: `analogy-not-paper-result`
- Normalization record status: `human-adopted`

## C-029 — calibration-accept

- Locator: `L86-L95`
- Original criterion: `2`
- Human status: `AUTHORITATIVE_FOR_THIS_NONCANONICAL_CHECKPOINT`
- Reason: Retain Equation 1 and its symbol definitions as one formal architectural definition.

### Exact original quote

```text
In its simplest form the RN is a composite function:
RN(O) =fφ

∑
i,j
gθ(oi,oj)

, (1)
where the input is a set of “objects” O ={o1,o 2,...,o n}, oi∈ Rm is the ith object, and fφ and gθ
are functions with parameters φ and θ, respectively.
```

### C-029 — criterion 2

- Evidence locator: `L86-L95`
- Exact evidence:

```text
In its simplest form the RN is a composite function:
RN(O) =fφ

∑
i,j
gθ(oi,oj)

, (1)
where the input is a set of “objects” O ={o1,o 2,...,o n}, oi∈ Rm is the ith object, and fφ and gθ
are functions with parameters φ and θ, respectively.
```

- Normalized wording: In its simplest form the RN is a composite function: RN(O) =fφ  ∑ i,j gθ(oi,oj)  , (1) where the input is a set of “objects” O ={o1,o 2,...,o n}, oi∈ Rm is the ith object, and fφ and gθ are functions with parameters φ and θ, respectively.
- Flags: `formal-material`, `exact-frozen-degraded-rendering-preserved`
- Note: PDF-readable equation is interpretive rendering metadata only.
- Normalization record status: `mechanical-linewrap-only-checkpoint-transcription`

## C-030 — edit

- Locator: `L95-L95`
- Original criterion: `2`
- Human status: `AUTHORITATIVE_FOR_THIS_NONCANONICAL_CHECKPOINT`
- Reason: Retain the paper-specific MLP implementation as a separate criterion-3 claim.

### Exact original quote

```text
For our purposes, fφ and gθ are MLPs
```

### C-030 — criterion 3

- Evidence locator: `L95`
- Exact evidence:

```text
For our purposes, fφ and gθ are MLPs
```

- Normalized wording: For the authors’ purposes, \(f_\phi\) and \(g_\theta\) are multilayer perceptrons.
- Dependencies: `C-029`
- Flags: `paper-specific-scope`
- Normalization record status: `human-adopted`

## C-031 — too-narrow-repaired-by-dependency

- Locator: `L98-L98`
- Original criterion: `2`
- Human status: `AUTHORITATIVE_FOR_THIS_NONCANONICAL_CHECKPOINT`
- Reason: Restore parameter identities and paper-specific scope through dependencies without merging.

### Exact original quote

```text
parameters are learnable synaptic weights, making RNs end-to-end diﬀerentiable.
```

### C-031 — criterion 4

- Evidence locator: `L98`
- Exact evidence:

```text
parameters are learnable synaptic weights, making RNs end-to-end diﬀerentiable.
```

- Normalized wording: For the authors’ implementation, the parameters \(\phi\) and \(\theta\) are learnable synaptic weights, making RNs end-to-end differentiable.
- Dependencies: `C-029`, `C-030`
- Flags: `no-optimization-convergence-performance-claim`
- Normalization record status: `human-adopted`

## C-032 — edit

- Locator: `L98-L100`
- Original criterion: `1`
- Human status: `AUTHORITATIVE_FOR_THIS_NONCANONICAL_CHECKPOINT`
- Reason: Criterion 2 more precisely captures the component output and inferential role; keep intact.

### Exact original quote

```text
We call the output
of gθ a “relation”; therefore, the role of gθ is to infer the ways in which two objects are related, or if
they are even related at all.
```

### C-032 — criterion 2

- Evidence locator: `L98-L100`
- Exact evidence:

```text
We call the output
of gθ a “relation”; therefore, the role of gθ is to infer the ways in which two objects are related, or if
they are even related at all.
```

- Normalized wording: The authors call the output of \(g_\theta\) a “relation”; the role of \(g_\theta\) is to infer how two objects are related, including whether they are related at all.
- Dependencies: `C-029`
- Flags: `no-guaranteed-correct-detection`
- Normalization record status: `human-adopted`

## C-033 — too-broad

- Locator: `L101-L103`
- Original criterion: `1`
- Human status: `AUTHORITATIVE_FOR_THIS_NONCANONICAL_CHECKPOINT`
- Reason: The three stated strengths are independently adjudicable while retaining their original list relationship.

### Exact original quote

```text
RNs have three notable strengths: they learn to infer relations, they are data eﬃcient, and they
operate on a set of objects – a particularly general and versatile input format – in a manner that is
order invariant.
```

### C-033a — criterion 1

- Evidence locator: `L101-L103`
- Exact evidence:

```text
RNs have three notable strengths: they learn to infer relations
```

- Normalized wording: The authors identify learning to infer relations as a notable strength of RNs.
- Flags: `member-of-original-three-strengths-list`
- Normalization record status: `human-adopted`

### C-033b — criterion 1

- Evidence locator: `L101-L103`
- Exact evidence:

```text
they are data eﬃcient
```

- Normalized wording: The authors identify data efficiency as a notable strength of RNs.
- Flags: `qualitative-no-metric`, `member-of-original-three-strengths-list`
- Normalization record status: `human-adopted`

### C-033c — criterion 1

- Evidence locator: `L101-L103`
- Exact evidence:

```text
and they
operate on a set of objects – a particularly general and versatile input format – in a manner that is
order invariant.
```

- Normalized wording: RNs operate on a set of objects—a particularly general and versatile input format—in an order-invariant manner.
- Flags: `member-of-original-three-strengths-list`, `order-invariance-only`
- Normalization record status: `human-adopted`

## C-034 — edit

- Locator: `L104-L105`
- Original criterion: `2`
- Human status: `AUTHORITATIVE_FOR_THIS_NONCANONICAL_CHECKPOINT`
- Reason: Remove the flattened subsection heading as repetition; retain the new mechanism explanation.

### Exact original quote

```text
RNs learn to infer relations The functional form in Equation 1 dictates that an RN should
consider the potential relations between all object pairs.
```

### Duplicate fragment

```text
RNs learn to infer relations
```
- Duplicate of: `C-033a`

### C-034 — criterion 4

- Evidence locator: `L104-L105`
- Exact evidence:

```text
The functional form in Equation 1 dictates that an RN should
consider the potential relations between all object pairs.
```

- Normalized wording: The functional form in Equation 1 dictates that an RN should consider the potential relations between all object pairs.
- Dependencies: `C-029`
- Flags: `preserve-dictates`, `preserve-should-consider`, `potential-not-actual`
- Normalization record status: `human-adopted`

## C-035 — too-broad

- Locator: `L105-L107`
- Original criterion: `2`
- Human status: `AUTHORITATIVE_FOR_THIS_NONCANONICAL_CHECKPOINT`
- Reason: The knowledge boundary and the resulting learning requirement have different claim roles.

### Exact original quote

```text
This implies that an RN is not necessarily
privy to which object relations actually exist, nor to the actual meaning of any particular relation.
Thus, RNs must learn to infer the existence and implications of object relations.
```

### C-035a — criterion 6

- Evidence locator: `L105-L107`
- Exact evidence:

```text
This implies that an RN is not necessarily
privy to which object relations actually exist, nor to the actual meaning of any particular relation.
```

- Normalized wording: An RN is not necessarily privy to which object relations actually exist or to the actual meaning of any particular relation.
- Dependencies: `C-034`
- Flags: `preserve-not-necessarily`, `meaning-not-implications`
- Normalization record status: `human-adopted`

### C-035b — criterion 4

- Evidence locator: `L105-L107`
- Exact evidence:

```text
Thus, RNs must learn to infer the existence and implications of object relations.
```

- Normalized wording: The authors state that RNs must therefore learn to infer the existence and implications of object relations.
- Dependencies: `C-035a`, `C-034`
- Flags: `required-learning-not-guaranteed-success`
- Normalization record status: `human-adopted`

## C-036 — calibration-accept

- Locator: `L108-L109`
- Original criterion: `2`
- Human status: `AUTHORITATIVE_FOR_THIS_NONCANONICAL_CHECKPOINT`
- Reason: The graph properties, node mapping, and edge mapping jointly define one coherent representation.

### Exact original quote

```text
In graph theory parlance, the input can be thought of as a complete and directed graph whose
nodes are objects and whose edges denote the object pairs whose relations should be considered.
```

### C-036 — criterion 2

- Evidence locator: `L108-L109`
- Exact evidence:

```text
In graph theory parlance, the input can be thought of as a complete and directed graph whose
nodes are objects and whose edges denote the object pairs whose relations should be considered.
```

- Normalized wording: In graph-theoretic terms, the RN input can be viewed as a complete directed graph in which objects are nodes and edges denote the object pairs whose relations should be considered.
- Dependencies: `C-029`, `C-034`
- Flags: `interpretive-not-mandatory-storage`
- Normalization record status: `human-adopted`

## C-037 — too-broad

- Locator: `L110-L111`
- Original criterion: `7`
- Human status: `AUTHORITATIVE_FOR_THIS_NONCANONICAL_CHECKPOINT`
- Reason: The paper-wide scope boundary and the selected-pair design alternative are independently adjudicable.

### Exact original quote

```text
Although we focus on this “all-to-all” version of the RN throughout this paper, this RN deﬁnition
can be adjusted to consider only some object pairs.
```

### C-037a — criterion 6

- Evidence locator: `L110-L111`
- Exact evidence:

```text
Although we focus on this “all-to-all” version of the RN throughout this paper
```

- Normalized wording: The authors focus on the all-to-all version of the RN throughout this paper.
- Flags: `preserve-throughout-this-paper`
- Normalization record status: `human-adopted`

### C-037b — criterion 7

- Evidence locator: `L110-L111`
- Exact evidence:

```text
this RN deﬁnition
can be adjusted to consider only some object pairs.
```

- Normalized wording: The RN definition can be adjusted to consider only some object pairs.
- Dependencies: `C-029`, `C-034`, `C-036`, `C-037a`
- Flags: `possibility-not-use-or-preference`
- Normalization record status: `human-adopted`

## C-038 — edit

- Locator: `L111-L113`
- Original criterion: `7`
- Human status: `AUTHORITATIVE_FOR_THIS_NONCANONICAL_CHECKPOINT`
- Reason: Criterion 2 more precisely captures the selected-pair input interface; retain intact.

### Exact original quote

```text
Similar to Interaction Networks [ 2], to which
RNs are related, RNs can take as input a list of only those pairs that should be considered, if this
information is available.
```

### C-038 — criterion 2

- Evidence locator: `L111-L113`
- Exact evidence:

```text
Similar to Interaction Networks [ 2], to which
RNs are related, RNs can take as input a list of only those pairs that should be considered, if this
information is available.
```

- Normalized wording: The authors state that RNs are related to Interaction Networks and, similarly, can take as input a list containing only the object pairs whose relations should be considered, when that pair-selection information is available.
- Dependencies: `C-037b`, `C-036`
- Citation scope: [2] attached to Interaction Networks comparison
- Flags: `can-not-must`, `availability-condition`
- Normalization record status: `human-adopted`

## C-039 — too-narrow-repaired-by-dependency

- Locator: `L113-L114`
- Original criterion: `7`
- Human status: `AUTHORITATIVE_FOR_THIS_NONCANONICAL_CHECKPOINT`
- Reason: The pronoun referent is absent; restore it through C-038 without duplicative widening.

### Exact original quote

```text
This information could be explicit in the input data, or could perhaps be
extracted by some upstream mechanism.
```

### C-039 — criterion 7

- Evidence locator: `L113-L114`
- Exact evidence:

```text
This information could be explicit in the input data, or could perhaps be
extracted by some upstream mechanism.
```

- Normalized wording: Information specifying which object pairs should be considered could be explicit in the input data or could perhaps be extracted by an upstream mechanism.
- Dependencies: `C-038`
- Flags: `preserve-could-perhaps`
- Normalization record status: `human-adopted`

## C-040 — edit

- Locator: `L115-L117`
- Original criterion: `2`
- Human status: `AUTHORITATIVE_FOR_THIS_NONCANONICAL_CHECKPOINT`
- Reason: Remove the flattened subsection heading as repetition; retain the shared-function mechanism and batch interpretation together.

### Exact original quote

```text
RNs are data eﬃcient RNs use a single function gθ to compute each relation. This can be
thought of as a single function operating on a batch of object pairs, where each member of the
batch is a particular object-object pair from the same object set.
```

### Duplicate fragment

```text
RNs are data eﬃcient
```
- Duplicate of: `C-033b`

### C-040 — criterion 2

- Evidence locator: `L115-L117`
- Exact evidence:

```text
RNs use a single function gθ to compute each relation. This can be
thought of as a single function operating on a batch of object pairs, where each member of the
batch is a particular object-object pair from the same object set.
```

- Normalized wording: RNs use a single function \(g_\theta\) to compute each relation; this can be understood as one function operating on a batch of object pairs, each of which is a particular object-object pair from the same object set.
- Dependencies: `C-029`
- Flags: `operational-interpretation-not-software-batching-claim`
- Normalization record status: `human-adopted`

## C-041 — calibration-accept

- Locator: `L117-L119`
- Original criterion: `4`
- Human status: `AUTHORITATIVE_FOR_THIS_NONCANONICAL_CHECKPOINT`
- Reason: Retain the shared-function mechanism-to-generalization explanation intact.

### Exact original quote

```text
This mode of operation encourages
greater generalization for computing relations, since gθ is encouraged not to over-ﬁt to the features
of any particular object pair.
```

### C-041 — criterion 4

- Evidence locator: `L117-L119`
- Exact evidence:

```text
This mode of operation encourages
greater generalization for computing relations, since gθ is encouraged not to over-ﬁt to the features
of any particular object pair.
```

- Normalized wording: The shared \(g_\theta\) mode of operation encourages greater generalization in computing relations because \(g_\theta\) is encouraged not to overfit the features of any particular object pair.
- Dependencies: `C-040`
- Flags: `qualitative-encourages-not-guarantees`
- Normalization record status: `human-adopted`

## C-042 — too-broad

- Locator: `L119-L122`
- Original criterion: `6`
- Human status: `AUTHORITATIVE_FOR_THIS_NONCANONICAL_CHECKPOINT`
- Reason: The simultaneous input, replicated-function requirement, and growth-related intractability are independently adjudicable.

### Exact original quote

```text
Consider how an MLP would learn the same function. An MLP would
receive all objects from the object set simultaneously as its input. It must then learn and embed n2
(where n is the number of objects) identical functions within its weight parameters to account for all
possible object pairings. This quickly becomes intractable as the number of objects grows.
```

### C-042a — criterion 2

- Evidence locator: `L119-L122`
- Exact evidence:

```text
Consider how an MLP would learn the same function. An MLP would
receive all objects from the object set simultaneously as its input.
```

- Normalized wording: To learn the same relation function, an MLP would receive all objects from the object set simultaneously as its input.
- Dependencies: `C-040`
- Normalization record status: `human-adopted`

### C-042b — criterion 6

- Evidence locator: `L119-L122`
- Exact evidence:

```text
It must then learn and embed n2
(where n is the number of objects) identical functions within its weight parameters to account for all
possible object pairings.
```

- Normalized wording: The MLP must then learn and embed \(n^2\), where \(n\) is the number of objects, identical functions within its weight parameters to account for all possible object pairings.
- Dependencies: `C-042a`, `C-040`
- Flags: `exact-frozen-n2`, `pdf-readable-n-squared-metadata`
- Normalization record status: `human-adopted`

### C-042c — criterion 6

- Evidence locator: `L119-L122`
- Exact evidence:

```text
This quickly becomes intractable as the number of objects grows.
```

- Normalized wording: Embedding \(n^2\) identical functions within the MLP’s weight parameters quickly becomes intractable as the number of objects grows.
- Dependencies: `C-042b`
- Flags: `preserve-quickly`, `no-numeric-threshold-or-formal-proof`
- Normalization record status: `human-adopted`

## C-043 — edit

- Locator: `L122-L125`
- Original criterion: `4`
- Human status: `AUTHORITATIVE_FOR_THIS_NONCANONICAL_CHECKPOINT`
- Reason: Criterion 6 more precisely captures the explicit computational cost tradeoff; retain intact.

### Exact original quote

```text
Therefore,
the cost of learning a relation function n2 times using a single feedforward pass per sample, as in an
MLP, is replaced by the cost of n2 feedforward passes per object set (i.e., for each possible object
pair in the set) and learning a relation function just once, as in an RN.
```

### C-043 — criterion 6

- Evidence locator: `L122-L125`
- Exact evidence:

```text
Therefore,
the cost of learning a relation function n2 times using a single feedforward pass per sample, as in an
MLP, is replaced by the cost of n2 feedforward passes per object set (i.e., for each possible object
pair in the set) and learning a relation function just once, as in an RN.
```

- Normalized wording: For an MLP, the cost of learning a relation function \(n^2\) times while using one feedforward pass per sample is replaced in an RN by the cost of \(n^2\) feedforward passes per object set—one for each possible object pair—and learning the relation function once.
- Dependencies: `C-040`, `C-042a`, `C-042b`, `C-042c`
- Flags: `exact-frozen-n2`, `pdf-readable-n-squared-metadata`, `not-an-empirical-timing-benchmark`
- Normalization record status: `human-adopted`

## C-044 — edit

- Locator: `L126-L128`
- Original criterion: `4`
- Human status: `AUTHORITATIVE_FOR_THIS_NONCANONICAL_CHECKPOINT`
- Reason: Remove the flattened subsection heading as repetition; retain the summation-to-order-invariance explanation.

### Exact original quote

```text
RNs operate on a set of objects The summation in Equation 1 ensures that the RN is invariant
to the order of objects in the input. This invariance ensures that the RN’s input respects the property
that sets are order invariant, and it ensures that the output is order invariant.
```

### Duplicate fragment

```text
RNs operate on a set of objects
```
- Duplicate of: `C-033c`

### C-044 — criterion 4

- Evidence locator: `L126-L128`
- Exact evidence:

```text
The summation in Equation 1 ensures that the RN is invariant
to the order of objects in the input. This invariance ensures that the RN’s input respects the property
that sets are order invariant, and it ensures that the output is order invariant.
```

- Normalized wording: The summation in Equation 1 ensures that the RN is invariant to the order of objects in the input; this makes the input respect the order-invariance property of sets and ensures that the output is order invariant.
- Dependencies: `C-029`
- Flags: `order-invariance-only`
- Normalization record status: `human-adopted`

## C-045 — too-narrow-repaired-by-dependency

- Locator: `L128-L130`
- Original criterion: `4`
- Human status: `AUTHORITATIVE_FOR_THIS_NONCANONICAL_CHECKPOINT`
- Reason: The invariance referent is absent; restore it through C-044 without widening.

### Exact original quote

```text
Ultimately, this
invariance ensures that the RN’s output contains information that is generally representative of the
relations that exist in the object set.
```

### C-045 — criterion 4

- Evidence locator: `L128-L130`
- Exact evidence:

```text
Ultimately, this
invariance ensures that the RN’s output contains information that is generally representative of the
relations that exist in the object set.
```

- Normalized wording: Ultimately, the RN’s order invariance ensures that its output contains information that is generally representative of the relations that exist in the object set.
- Dependencies: `C-044`
- Flags: `preserve-generally-representative`, `not-complete-exact-or-interpretable`
- Normalization record status: `human-adopted`

## C-046 — edit

- Locator: `L132-L134`
- Original criterion: `3`
- Human status: `AUTHORITATIVE_FOR_THIS_NONCANONICAL_CHECKPOINT`
- Reason: The first sentence repeats cross-task application; retain the distinct evaluation-selection rationale.

### Exact original quote

```text
We applied RN-augmented networks to a variety of tasks that hinge on relational reasoning. To
demonstrate the versatility of these networks we chose tasks from a number of diﬀerent domains,
including visual QA, text-based QA, and dynamic physical systems.
```

### Duplicate fragment

```text
We applied RN-augmented networks to a variety of tasks that hinge on relational reasoning.
```
- Duplicate of: `C-004`
- Note: semantic duplicate; relational-reasoning scope retained

### C-046 — criterion 3

- Evidence locator: `L132-L134`
- Exact evidence:

```text
To
demonstrate the versatility of these networks we chose tasks from a number of diﬀerent domains,
including visual QA, text-based QA, and dynamic physical systems.
```

- Normalized wording: To demonstrate the versatility of RN-augmented networks, the authors chose tasks from a number of different domains, including visual QA, text-based QA, and dynamic physical systems.
- Dependencies: `C-004`
- Flags: `purpose-not-proof`
- Normalization record status: `human-adopted`

## C-047 — too-broad

- Locator: `L136-L139`
- Original criterion: `2`
- Human status: `AUTHORITATIVE_FOR_THIS_NONCANONICAL_CHECKPOINT`
- Reason: Task behavior, challenge explanation, and architecture requirement have different claim roles and citation scopes.

### Exact original quote

```text
In visual QA a model must learn to answer questions about an image (Figure 1). This is a challenging
problem domain because it requires high-level scene understanding [1, 29]. Architectures must perform
complex relational reasoning – spatial and otherwise – over the features in the visual inputs, language
inputs, and their conjunction.
```

### C-047a — criterion 1

- Evidence locator: `L136-L139`
- Exact evidence:

```text
In visual QA a model must learn to answer questions about an image (Figure 1).
```

- Normalized wording: In visual question answering, a model must learn to answer questions about an image.
- Flags: `figure-1-illustrative-context`
- Normalization record status: `human-adopted`

### C-047b — criterion 6

- Evidence locator: `L136-L139`
- Exact evidence:

```text
This is a challenging
problem domain because it requires high-level scene understanding [1, 29].
```

- Normalized wording: Visual question answering is a challenging problem domain because it requires high-level scene understanding.
- Dependencies: `C-047a`
- Citation scope: [1, 29]
- Flags: `preserve-causal-because`, `preserve-requires`
- Normalization record status: `human-adopted`

### C-047c — criterion 2

- Evidence locator: `L136-L139`
- Exact evidence:

```text
Architectures must perform
complex relational reasoning – spatial and otherwise – over the features in the visual inputs, language
inputs, and their conjunction.
```

- Normalized wording: Visual-question-answering architectures must perform complex relational reasoning—spatial and otherwise—over features in the visual inputs, language inputs, and their conjunction.
- Dependencies: `C-047a`
- Flags: `preserve-multimodal-conjunction`
- Normalization record status: `human-adopted`

## C-048 — too-broad

- Locator: `L139-L141`
- Original criterion: `6`
- Human status: `AUTHORITATIVE_FOR_THIS_NONCANONICAL_CHECKPOINT`
- Reason: Incomplete vocabularies and unavailable world knowledge are independently adjudicable constraints.

### Exact original quote

```text
However, the majority of visual QA datasets require reasoning in the
absence of fully speciﬁed word vocabularies, and perhaps more perniciously, a vast and complicated
knowledge of the world that is not available in the training data.
```

### C-048a — criterion 6

- Evidence locator: `L139-L141`
- Exact evidence:

```text
However, the majority of visual QA datasets require reasoning in the
absence of fully speciﬁed word vocabularies
```

- Normalized wording: However, the majority of visual-question-answering datasets require reasoning in the absence of fully specified word vocabularies.
- Dependencies: `C-047a`, `C-047b`, `C-047c`
- Flags: `preserve-majority`
- Normalization record status: `human-adopted`

### C-048b — criterion 6

- Evidence locator: `L139-L141`
- Exact evidence:

```text
and perhaps more perniciously, a vast and complicated
knowledge of the world that is not available in the training data.
```

- Normalized wording: The majority of visual-question-answering datasets perhaps more perniciously require vast and complicated knowledge of the world that is not available in the training data.
- Dependencies: `C-048a`
- Flags: `preserve-perhaps-more-perniciously`
- Normalization record status: `human-adopted`

## C-049 — too-broad-and-referent-dependent

- Locator: `L141-L143`
- Original criterion: `6`
- Human status: `AUTHORITATIVE_FOR_THIS_NONCANONICAL_CHECKPOINT`
- Reason: Dataset ambiguity and the linguistic-bias shortcut mechanism are independently adjudicable.

### Exact original quote

```text
They also contain ambiguities and
exhibit strong linguistic biases that allow a model to learn answering strategies that exploit those
biases, without reasoning about the visual input [1, 31, 36].
```

### C-049a — criterion 6

- Evidence locator: `L141-L143`
- Exact evidence:

```text
They also contain ambiguities
```

- Normalized wording: The majority of visual-question-answering datasets also contain ambiguities.
- Dependencies: `C-048a`
- Citation scope: [1, 31, 36] shared context across original sentence
- Normalization record status: `human-adopted`

### C-049b — criterion 4

- Evidence locator: `L141-L143`
- Exact evidence:

```text
and
exhibit strong linguistic biases that allow a model to learn answering strategies that exploit those
biases, without reasoning about the visual input [1, 31, 36].
```

- Normalized wording: The majority of visual-question-answering datasets exhibit strong linguistic biases that allow a model to learn answering strategies that exploit those biases without reasoning about the visual input.
- Dependencies: `C-048a`
- Citation scope: [1, 31, 36]
- Flags: `allow-not-guarantee`
- Normalization record status: `human-adopted`

## C-050 — too-broad

- Locator: `L146-L148`
- Original criterion: `3`
- Human status: `AUTHORITATIVE_FOR_THIS_NONCANONICAL_CHECKPOINT`
- Reason: Dataset development purpose and image content are independently adjudicable construction claims.

### Exact original quote

```text
To control for these issues, and to distill the core challenges of visual QA, the CLEVR visual QA
dataset was developed [ 15]. CLEVR contains images of 3D-rendered objects, such as spheres and
cylinders (Figure 2).
```

### C-050a — criterion 3

- Evidence locator: `L146-L148`
- Exact evidence:

```text
To control for these issues, and to distill the core challenges of visual QA, the CLEVR visual QA
dataset was developed [ 15].
```

- Normalized wording: The CLEVR visual-question-answering dataset was developed to control for the preceding dataset issues and to distill the core challenges of visual question answering.
- Dependencies: `C-047a`, `C-047b`, `C-047c`, `C-048a`, `C-048b`, `C-049a`, `C-049b`
- Citation scope: [15]
- Flags: `does-not-claim-complete-elimination`
- Normalization record status: `human-adopted`

### C-050b — criterion 3

- Evidence locator: `L146-L148`
- Exact evidence:

```text
CLEVR contains images of 3D-rendered objects, such as spheres and
cylinders (Figure 2).
```

- Normalized wording: CLEVR contains images of three-dimensionally rendered objects, such as spheres and cylinders.
- Flags: `such-as-nonexhaustive`, `figure-2-visual-context`
- Normalization record status: `human-adopted`

## C-051 — calibration-accept

- Locator: `L148-L150`
- Original criterion: `3`
- Human status: `AUTHORITATIVE_FOR_THIS_NONCANONICAL_CHECKPOINT`
- Reason: The general question-category construction and two examples form one coherent dataset description.

### Exact original quote

```text
Each image is associated with a number of questions that fall into diﬀerent
categories. For example, query attribute questions may ask “ What is the color of the sphere? ”,
while compare attribute questions may ask “ Is the cube the same material as the cylinder? ”.
```

### C-051 — criterion 3

- Evidence locator: `L148-L150`
- Exact evidence:

```text
Each image is associated with a number of questions that fall into diﬀerent
categories. For example, query attribute questions may ask “ What is the color of the sphere? ”,
while compare attribute questions may ask “ Is the cube the same material as the cylinder? ”.
```

- Normalized wording: Each CLEVR image is associated with multiple questions from different categories; for example, a query-attribute question may ask, “What is the color of the sphere?”, while a compare-attribute question may ask, “Is the cube the same material as the cylinder?”
- Dependencies: `C-050b`
- Normalization record status: `human-adopted`

## C-052 — too-broad

- Locator: `L151-L153`
- Original criterion: `5`
- Human status: `AUTHORITATIVE_FOR_THIS_NONCANONICAL_CHECKPOINT`
- Reason: The relational-question property, reported architecture result, and hedged causal explanation have different evidence roles.

### Exact original quote

```text
For our purposes, an important feature of CLEVR is that many questions are explicitly relational
in nature. Remarkably, powerful QA architectures [ 46] are unable to solve CLEVR, presumably
because they cannot handle core relational aspects of the task.
```

### C-052a — criterion 1

- Evidence locator: `L151-L153`
- Exact evidence:

```text
For our purposes, an important feature of CLEVR is that many questions are explicitly relational
in nature.
```

- Normalized wording: For the authors’ purposes, an important feature of CLEVR is that many of its questions are explicitly relational in nature.
- Flags: `many-not-all`, `author-relative-importance`
- Normalization record status: `human-adopted`

### C-052b — criterion 5

- Evidence locator: `L151-L153`
- Exact evidence:

```text
Remarkably, powerful QA architectures [ 46] are unable to solve CLEVR
```

- Normalized wording: The authors remark that powerful question-answering architectures are unable to solve CLEVR.
- Citation scope: [46]
- Flags: `preserve-remarkably-framing`, `clevr-condition`
- Normalization record status: `human-adopted`

### C-052c — criterion 4

- Evidence locator: `L151-L153`
- Exact evidence:

```text
presumably
because they cannot handle core relational aspects of the task.
```

- Normalized wording: The authors presume that these architectures are unable to solve CLEVR because they cannot handle core relational aspects of the task.
- Dependencies: `C-052a`, `C-052b`
- Flags: `presumably-not-established`
- Normalization record status: `human-adopted`

## C-053 — too-narrow-repaired-by-dependency

- Locator: `L153-L156`
- Original criterion: `5`
- Human status: `AUTHORITATIVE_FOR_THIS_NONCANONICAL_CHECKPOINT`
- Reason: The exact quote omits the CLEVR task condition and “For example” antecedent; restore them through C-052b.

### Exact original quote

```text
For example, as reported in the
original paper a model comprised of ResNet-101 image embeddings with LSTM question processing
and augmented with stacked attention modules vastly outperformed other models at an overall
performance of 68.5% (compared to 52.3% for the next best, and 92 .6% human performance) [ 15].
```

### C-053 — criterion 5

- Evidence locator: `L153-L156`
- Exact evidence:

```text
For example, as reported in the
original paper a model comprised of ResNet-101 image embeddings with LSTM question processing
and augmented with stacked attention modules vastly outperformed other models at an overall
performance of 68.5% (compared to 52.3% for the next best, and 92 .6% human performance) [ 15].
```

- Normalized wording: As an example reported in the original CLEVR paper, a model using ResNet-101 image embeddings, LSTM question processing, and stacked attention modules achieved 68.5% overall performance on CLEVR, vastly outperforming the next-best model at 52.3%, while human performance was 92.6%.
- Dependencies: `C-052b`
- Citation scope: [15]
- Flags: `exact-frozen-92-space-dot-6-percent`, `pdf-readable-92.6-percent-metadata`, `do-not-imply-human-outperformance`
- Normalization record status: `human-adopted`
