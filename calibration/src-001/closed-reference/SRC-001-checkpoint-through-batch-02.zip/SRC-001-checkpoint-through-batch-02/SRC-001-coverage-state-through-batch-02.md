# SRC-001 Coverage State Through Batch 02

> NONCANONICAL HUMAN-REVIEWED DEVELOPMENT-CALIBRATION RECORD

## Summary

- Accounted source range: `L1-L156`
- Original candidates adjudicated: `C-001-C-053`
- Gap rows adjudicated: `G-001-G-009`
- Missing units added: `M-001a`, `M-001b`
- Criteria changes: `none`
- SRC-001 state: `OPEN`

## G-001 — no-candidate

- Locator: `L1-L15`
- Exclusion/accounting: L1-L5 extraction-wrapper; L6 blank; L7-L15 title/authors/contact/affiliation/heading document administration.
- Missing-packet decision: none

## G-002 — no-candidate

- Locator: `L27`
- Exclusion/accounting: “1 Introduction” heading; document administration.
- Missing-packet decision: none

## G-003 — partitioned-gap-correction

- Locator: `L42-L55`
- Exclusion/accounting: L43-L46 document administration; L47-L55 figure/example labels and questions without an independent assertion; substantive interpretation retained in C-015.
- Missing-packet decision: M-001 uses L41-L42 plus L61-L62; L42 is substantive continuation.

## G-004 — reject-no-candidate

- Locator: `L61-L62`
- Exclusion/accounting: none for L61-L62; these lines are substantive continuation evidence.
- Missing-packet decision: M-001 uses L41-L42 plus L61-L62.

## G-005 — no-candidate

- Locator: `L79`
- Exclusion/accounting: “2 Relation Networks” section heading; document administration.
- Missing-packet decision: none

## G-006 — no-candidate

- Locator: `L96-L97`
- Exclusion/accounting: page number 2 and blank line; document administration.
- Missing-packet decision: none; page interruption recorded; C-030 and C-031 remain separate human-adopted units.

## G-007 — no-candidate

- Locator: `L131`
- Exclusion/accounting: “3 Tasks” section heading; document administration.
- Missing-packet decision: none

## G-008 — no-candidate

- Locator: `L135`
- Exclusion/accounting: “3.1 CLEVR” section heading; document administration.
- Missing-packet decision: none

## G-009 — no-candidate

- Locator: `L144-L145`
- Exclusion/accounting: page number and blank line; document administration.
- Missing-packet decision: none

## Missing units

### M-001a — criterion 5

- Fragment `L41-L42`:

```text
Our results corroborate
these claims
```
- Normalized wording: The authors state that their results corroborate the preceding claims.
- Dependencies: preceding claims; exact claim set remains unresolved
- Flags: `referent-dependent`, `discontiguous-source-representation-context`

### M-001b — criterion 5

- Fragment `L41-L42`:

```text
and further demonstrate that seemingly simple relational inferences are remarkably
```
- Fragment `L61-L62`:

```text
diﬃcult for powerful neural network architectures such as convolutional neural networks (CNNs) and
multi-layer perceptrons (MLPs).
```
- Normalized wording: The authors report that their results further demonstrate that seemingly simple relational inferences are remarkably difficult for powerful neural network architectures such as convolutional neural networks and multi-layer perceptrons.
- Dependencies: inherits “Our results” from M-001a/source sentence
- Flags: `ordered-discontiguous-fragments`, `pdf-contiguous-sentence`, `no-silent-reconstruction`

## Coverage conclusion

Every line in `L1-L156` is accounted for through an adjudicated candidate, an adjudicated exclusion/administrative span, or the ordered-fragment missing units `M-001a`/`M-001b`. This is a checkpoint conclusion for the reviewed prefix only; it is not whole-source completeness or SRC-001 closure.
