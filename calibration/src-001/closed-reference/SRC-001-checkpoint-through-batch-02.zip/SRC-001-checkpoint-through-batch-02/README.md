# SRC-001 Checkpoint Through Batch 02

> **NONCANONICAL HUMAN-REVIEWED DEVELOPMENT-CALIBRATION CHECKPOINT**
>
> This is not a run ledger, worker return, packet ledger, replay, validation,
> sanction, audit, acceptance record, or v1 evidence.

## State

- Source: `SRC-001` — *A simple neural network module for relational reasoning*
- Human-adjudicated source coverage: `L1-L156`
- Human-adjudicated original candidate IDs: `C-001-C-053`
- Human-adjudicated gap IDs: `G-001-G-009`
- Added missing units: `M-001a`, `M-001b`
- Last adjudicated item: `C-053`
- SRC-001 close state: `OPEN`
- SRC-002 authorization: `NOT AUTHORIZED`
- Criteria changes applied: `none`

## Pinned identities

| input | SHA-256 |
|---|---|
| frozen source | `5aef61988ff0db6f2ecc2b7980f370583a317e2427c85a6f78adc3ccc8a1d22a` |
| normalized criteria | `1df51f9872895a3a87a9face2bafe50db34cdfbfd73826e2a31f531c4c538df8` |
| source PDF | `c115123a511418ab46f04c4f9f78b6a569712960dbe9ca596d4edd6f0686d521` |
| adjudication handoff | `81764a109ce30e92b4661506d8f18a96a17ed81b309fcf614da993461f2783ca` |
| consolidated proposal index | `d92a0f5b768df885ad31db6f7cc17c4c64a3849cac65ebb34c68628cd52919f5` |
| Batch 01 proposal | `c1d088e0bd1dda89da04533a628bdca4b4dd610db694e9198361939fa7a8b868` |
| Batch 02 proposal | `11ec5faf437ae50b973b409baa62d3a64a6402935cf0b071d0a9435da199bfc3` |

## Contents

- `SRC-001-human-decisions-through-batch-02.md` — human-readable decision ledger.
- `SRC-001-human-decisions-through-batch-02.json` — structured decision ledger.
- `SRC-001-coverage-state-through-batch-02.md` — source accounting and gap dispositions.
- `SRC-001-provisional-criteria-observations.md` — observations kept separate from criteria changes.
- `SRC-001-resume-state.json` — exact continuation boundary and next expected proposal identity.
- `checkpoint-manifest.json` — generated-file identities and hashes.
- `CHECKSUMS.sha256` — hashes for package files except itself.

## Authority boundary

The immutable handoff and proposal files are unchanged and continue to show
open human fields. This checkpoint is a separate persistence layer for the
explicit human decisions made in the continuation conversation through Batch
02. It does not alter the source, criteria, PDF, proposals, handoff, historical
run evidence, or consolidated proposal index.

## Next verified boundary

- Next candidate: `C-054`
- Locator: `L157-L160`
- Expected proposal: `SRC-001-adjudication-batch-03-proposals.md`
- Expected SHA-256: `7fa12aa984252250e82d3ba3ca7cedb9374d53db3bcd42d99056347b342f8cc8`
- Source range: `L157-L234`
- Candidate range: `C-054-C-086`
- Gap range: `G-010-G-014`

The Batch 03 file was not present in `/mnt/data` when this checkpoint was
created. Its exact bytes must be supplied and verified before review continues.
