# SRC-001 File Inventory Through Batch 06

- created: `2026-08-05T18:43:00+02:00`
- all files: `133`
- top-level files: `75`
- embedded or expanded files: `58`
- minimum transfer files: `73`

## Scope

This is a filesystem inventory of SRC-001 artifacts currently present in the active runtime through Batch 06. It does not claim that every artifact was first created in this single UI thread; some were carried forward from the Batch 1-6 project work.

## Minimum transfer set for the Batch 7–12 chat

> This excludes expanded directories and the convenience archive because
> their contents are derivative or duplicated elsewhere.

| file | bytes | SHA-256 | category |
|---|---:|---|---|
| `SRC-001-adjudication-batch-03-proposals.md` | 8,440 | `7fa12aa984252250e82d3ba3ca7cedb9374d53db3bcd42d99056347b342f8cc8` | proposal input |
| `SRC-001-adjudication-batch-04-proposals.md` | 7,380 | `eaf54c5689e2f86330d1f5b9b4f56198ee558e9492491f06a8d5df88c30cd38a` | proposal input |
| `SRC-001-adjudication-batch-05-proposals.md` | 7,782 | `b751820457447d58405865bc8b953148c2a24c911f063f6c1f07ac5ce9560e5e` | proposal input |
| `SRC-001-adjudication-batch-06-proposals.md` | 8,558 | `aa4e5c94d4e540eb85c558ac5497c68e8799783dff633d0bd253016389bfd315` | proposal input |
| `SRC-001-batch-04-authority-receipt-20260804T1229+0200.json` | 1,255 | `fb33866e1a4ca84f9da8c92d436f792fab3eb9096d8ee34b08098fdfd60bcc66` | human authority receipt |
| `SRC-001-batch-04-authority-receipt-20260804T1229+0200.md` | 984 | `8fe5f1a7dbe76458c5b31be22b7c37b67aeddcddc99e730bc7dc409fcd4716ea` | human authority receipt |
| `SRC-001-checkpoint-through-batch-02-v2.zip` | 45,064 | `280231bef8b9e740a6959ac9e9b517ed067b3fc3882ebe5d94488b0006cd9041` | checkpoint ZIP |
| `SRC-001-checkpoint-through-batch-03-postbuild-verification.json` | 638 | `1d8a374c500b8c940d03c1e726a6003ba7715d083dffdd433aa3777b62049be0` | checkpoint verification |
| `SRC-001-checkpoint-through-batch-03.zip` | 108,173 | `84f50e8f697c382dfc436e2cbb6f22d8b999e8207de22ff29db7d51d39b45d32` | checkpoint ZIP |
| `SRC-001-checkpoint-through-batch-03.zip.sha256` | 106 | `3e491f01549467b0ec1e3a6f3a8322070527d498fe4492cfdb5cab625c4720e9` | checkpoint sidecar |
| `SRC-001-checkpoint-through-batch-04-postbuild-verification.json` | 2,704 | `1085dbc8ed3e83c4928c47cdd20118f07eb914d3ff4ca4fec869c772dfa2a3bd` | checkpoint verification |
| `SRC-001-checkpoint-through-batch-04.zip` | 150,046 | `f980cf6e48001022bc2f8bfe716a7c385363e7adb4d5c967dd04a3c9e24fceac` | checkpoint ZIP |
| `SRC-001-checkpoint-through-batch-04.zip.sha256` | 106 | `b1c88059d25eca9ab9f0e90073f73b6153bd757a1dc1fcd34319dcf1e9f05674` | checkpoint sidecar |
| `SRC-001-checkpoint-through-batch-05-postbuild-verification.json` | 1,275 | `09d2512958fc24e1a9b87c7d41b96261f96d66f07075f77429435760709824ba` | checkpoint verification |
| `SRC-001-checkpoint-through-batch-05.zip` | 188,953 | `18bee5212a11efb5f9b8482d796a74dc2a1a9ab35069ad6eab88856e5b5a10b5` | checkpoint ZIP |
| `SRC-001-checkpoint-through-batch-05.zip.sha256` | 106 | `1709fd45abb0bdf1b02582ee88471ec42035bb808e53f9efcf077c977138dfa8` | checkpoint sidecar |
| `SRC-001-checkpoint-through-batch-06-postbuild-verification.json` | 1,325 | `2181158fa46ab3ae2cbbf332bd93eae4dccec366511912dfb30ef61f0ae1c6d8` | checkpoint verification |
| `SRC-001-checkpoint-through-batch-06.zip` | 235,071 | `b34de5331c4c968416f1d6b2459d40351ffab7417ef1bcb13c713dcba5feb6ec` | checkpoint ZIP |
| `SRC-001-checkpoint-through-batch-06.zip.sha256` | 106 | `be38b6d26e2a9e87e19191940fcfa360c73eb02fe13b845873080f3bdee1510e` | checkpoint sidecar |
| `SRC-001-exact-evidence-correction-and-audit-receipt-20260805T1821+0200.sha256` | 602 | `7d97d626c96c0d92e33a23b8c406c5146251df25bd9d8c9d6b679cabf52e175f` | correction/audit checksum sidecar |
| `SRC-001-human-attestation-receipt-through-batch-03-20260803T2327+0200.json` | 3,080 | `0ca51db282de08d677e4884e157b6de0a989b58f8153c0250337f973542b0afd` | human exact-byte attestation receipt |
| `SRC-001-human-attestation-receipt-through-batch-03-20260803T2327+0200.md` | 2,116 | `d20ac5b2b60363d998d5621c7b4d8fe4e08f1a3baa669e3831f880dd64be4484` | human exact-byte attestation receipt |
| `SRC-001-human-attestation-receipt-through-batch-04-20260804T1842+0200.json` | 3,069 | `6f1f8804e08960ad1533955df381705226139f494c7c7400dab5875d30db1590` | human exact-byte attestation receipt |
| `SRC-001-human-attestation-receipt-through-batch-04-20260804T1842+0200.md` | 1,912 | `b1e0e103dd28d2cb8975e86f1afba9f6832552c3fe1f124c612a051337c6dd36` | human exact-byte attestation receipt |
| `SRC-001-human-attestation-receipt-through-batch-05-20260805T1455+0200.json` | 3,064 | `710c688f0bce740f31072e79e5ed640023a46892ca54e917fe8df7de83ab940b` | human exact-byte attestation receipt |
| `SRC-001-human-attestation-receipt-through-batch-05-20260805T1455+0200.md` | 1,884 | `9cfbbed249d9449fbc1d4a958f671caad8bbb373246957df26b2d73301cbf65f` | human exact-byte attestation receipt |
| `SRC-001-human-attestation-receipt-through-batch-06-20260805T1733+0200.json` | 2,904 | `85a6e1411e140fad14cac69dd38fd38f1737152f288dcf0e9ee5421325c41141` | human exact-byte attestation receipt |
| `SRC-001-human-attestation-receipt-through-batch-06-20260805T1733+0200.md` | 1,802 | `4ac759426646d76d8b80d6b41c64c145a7c404d02082bf5eee345c1fc4b915a2` | human exact-byte attestation receipt |
| `SRC-001-human-decision-event-B03A-20260803T2055+0200.json` | 14,093 | `ea67944af32e2c0a194b03905f9b0f29fc1b10f7bf097f57219f335abb5c5eb3` | human decision event |
| `SRC-001-human-decision-event-B03A-20260803T2055+0200.md` | 6,190 | `814d168d75ad8377f8fe85b3206db9abc0272f0087122c470f5d03224a961ed0` | human decision event |
| `SRC-001-human-decision-event-B03B-20260803T2116+0200.json` | 14,017 | `2cbc973f23c8cfb32eeb09339fd63745178aa31c16f98ff97c534e71214a01f1` | human decision event |
| `SRC-001-human-decision-event-B03B-20260803T2116+0200.md` | 6,423 | `a50ffc8fd2090522f8b4214721765f1af05e4aaf9a2fbe69e292000cca795df2` | human decision event |
| `SRC-001-human-decision-event-B03C-20260803T2155+0200.json` | 3,940 | `37d6af47ea7f8fc311564d3579e376b56902162040ba12a9bb4fc37bdf07282f` | human decision event |
| `SRC-001-human-decision-event-B03C-20260803T2155+0200.md` | 3,842 | `d27991b6fab93b3e6758acc52da19d3f3dd186bf14d4e1458d2d4cf73304ccc0` | human decision event |
| `SRC-001-human-decision-event-B03D-20260803T2235+0200.json` | 4,827 | `276ef4b6d396641a954eb2ae9c524c8ea53fdc158c94ca288abb35013195787f` | human decision event |
| `SRC-001-human-decision-event-B03D-20260803T2235+0200.md` | 4,709 | `726b399681c4bbbd0b80ba89e3ce8e198fc77fe2e2f8d0698c14f611398ff06d` | human decision event |
| `SRC-001-human-decision-event-B03E-20260803T2240+0200.json` | 4,680 | `8f5ac4ea20464b7391f2a5e23efe6a3326fab9ce4be0a19154d3557ff624acd4` | human decision event |
| `SRC-001-human-decision-event-B03E-20260803T2240+0200.md` | 4,582 | `b9093f5fec2644652ba44755d902e4274364441cdc65b2def4a905da9263ae84` | human decision event |
| `SRC-001-human-decision-event-B03F-20260803T2309+0200.json` | 4,326 | `99ee5b3cb2c93614dc049427931a22ee64a313d69930b868a1fe5140989ea9a0` | human decision event |
| `SRC-001-human-decision-event-B03F-20260803T2309+0200.md` | 3,524 | `4ad3de295103ea62487ae9dc4770436bef041ebd309ca99cbd580b285a85dd89` | human decision event |
| `SRC-001-human-decision-event-B04A-20260804T1617+0200.json` | 5,319 | `ebae4342c8544ad3fb0774272d5908326225b34c71b543e799639047a1dbad08` | human decision event |
| `SRC-001-human-decision-event-B04A-20260804T1617+0200.md` | 5,201 | `4ca66971fa7ae7ca16c904b2a176b4aca6e767117fc7ec398fc385cf8ee71afc` | human decision event |
| `SRC-001-human-decision-event-B04B-20260804T1628+0200.json` | 5,767 | `bdfe4b01aa999ca45a56da654e6c0796815a3ad753b8dce8a065b9ece608a212` | human decision event |
| `SRC-001-human-decision-event-B04B-20260804T1628+0200.md` | 5,645 | `16bdda16c0036c2bacae39a126e15282292355952b059f4dfb0bf03b3191181e` | human decision event |
| `SRC-001-human-decision-event-B04C-20260804T1638+0200.json` | 5,272 | `35b3b1e30e219a751a20aabbe8fc8ec5c9fd5fca82dd419ae62b7991150a6159` | human decision event |
| `SRC-001-human-decision-event-B04C-20260804T1638+0200.md` | 5,151 | `b1383ecf1d5a294b8a138b9f5bc0f599799f17a2c737ff0b5339e809d522f3cf` | human decision event |
| `SRC-001-human-decision-event-B04D-20260804T1733+0200.json` | 3,466 | `71d765a91d269e93cb74c02bf074a9583c0b9565da477e7318a124f2fb5f852a` | human decision event |
| `SRC-001-human-decision-event-B04D-20260804T1733+0200.md` | 3,340 | `9fdd9e06c096b802672609c1da62807661b5bf8660ac1111fc5d92a1ad8e8f61` | human decision event |
| `SRC-001-human-decision-event-B05A-20260804T2206+0200.json` | 5,582 | `7afeff6cf3939fe60e7e4c5f2ac436b862fcfdc0937949b1e152b126ea548a9d` | human decision event |
| `SRC-001-human-decision-event-B05A-20260804T2206+0200.md` | 5,151 | `8f0723dccf3c31597853e9661031e38ce13fd4e9837658b12f03b8688f03146e` | human decision event |
| `SRC-001-human-decision-event-B05B-20260805T1334+0200.json` | 7,090 | `cb5571cc61bab7f861c2158963095241c7a99e0f3cd388233542dd7181e6dce9` | human decision event |
| `SRC-001-human-decision-event-B05B-20260805T1334+0200.md` | 6,152 | `f3e546f92076d3892f58bb3e23555173f6b18e445789e3f99f2c563d0b401e1d` | human decision event |
| `SRC-001-human-decision-event-B05C-20260805T1428+0200.json` | 5,663 | `114f9aa353b2aba0f96c2f66b96a64090f3a6fa75be4e3eeea0936473b777088` | human decision event |
| `SRC-001-human-decision-event-B05C-20260805T1428+0200.md` | 4,774 | `6fdc02dc2b355856bd62cdf53ae16e20600fdf6028110c406dd7d3e51b6d8b8a` | human decision event |
| `SRC-001-human-decision-event-B05D-20260805T1446+0200.json` | 4,571 | `e157b78434a12ea13d6166109e5194aef7c4ea1ce935c1d08302fe0aa8bbdeb3` | human decision event |
| `SRC-001-human-decision-event-B05D-20260805T1446+0200.md` | 4,161 | `b6344d2b3ccc69499935690af9dbc203126940d0337a790554fc7fd34563c8cd` | human decision event |
| `SRC-001-human-decision-event-B06A-20260805T1505+0200.json` | 5,893 | `9618cc6b7a1b45539e154527763241dae16f7e677155aa814feeb7de17588819` | human decision event |
| `SRC-001-human-decision-event-B06A-20260805T1505+0200.md` | 5,179 | `0940a646e0baddea78a98aa5355edc0957bd5f3aefa2b7d12fd2d713c1e7ab7f` | human decision event |
| `SRC-001-human-decision-event-B06B-20260805T1708+0200.json` | 7,072 | `5f1b1fae31b26dd763b12532f4509b329b659bd9d9c770f6d622ff00bf22e5e1` | human decision event |
| `SRC-001-human-decision-event-B06B-20260805T1708+0200.md` | 6,137 | `a86a578e269d5c7cbfa4acbdd0967a91e23b58009ea8063439625acf2cb78d15` | human decision event |
| `SRC-001-human-decision-event-B06C-20260805T1711+0200.json` | 5,835 | `6bcb03a3a5ae6e4fb6e66e97b96c471f6d84fe289dcb18ea1c4fb64f6fe04d5c` | human decision event |
| `SRC-001-human-decision-event-B06C-20260805T1711+0200.md` | 5,048 | `52b7306139cdb9ef0eb714bcefc382ae2d007f5aee0ced053dd369c994109bc5` | human decision event |
| `SRC-001-human-decision-event-B06D-20260805T1714+0200.json` | 5,750 | `58eae490e88d0fde87543325a8e6f96fb7215bae8c6977473383f5da89f12677` | human decision event |
| `SRC-001-human-decision-event-B06D-20260805T1714+0200.md` | 4,944 | `5b6eb791a0c7c8b0553115a7526d5a9341746b71298223ff4b02215d6f2fe478` | human decision event |
| `SRC-001-human-decision-event-B06E-20260805T1716+0200.json` | 3,042 | `cfa3e1166dbfebdc77058321a20a1c91ad19390d40cd492d4aa864623b3d5aaf` | human decision event |
| `SRC-001-human-decision-event-B06E-20260805T1716+0200.md` | 2,351 | `4c4a9e32751f7825e7e68b51398d022ca2bd9c14623909d0b864047ff301de50` | human decision event |
| `SRC-001-human-exact-evidence-correction-through-batch-06-20260805T1821+0200.json` | 4,504 | `dadd9a3c66c63b565b5bb7cd412f553e4bbf2e6e45c671057e56af0be30d77b6` | append-only exact-evidence correction |
| `SRC-001-human-exact-evidence-correction-through-batch-06-20260805T1821+0200.md` | 3,470 | `e32058ae3fe019f94dba3768db0b83b1d71357a4b2d4a747abd07aba92f1654f` | append-only exact-evidence correction |
| `SRC-001-internal-audit-corrective-action-receipt-through-batch-06-20260805T1821+0200.json` | 2,140 | `bfdbe17e6fb1d1a61c92a8145b0faad546c8110856cec1b207e3b27d7a92300e` | audit corrective-action receipt |
| `SRC-001-internal-audit-corrective-action-receipt-through-batch-06-20260805T1821+0200.md` | 1,485 | `38cad23d7ddf4d22b429cba8fff26960a43f1a901475cc24a9849b3bf433844b` | audit corrective-action receipt |
| `SRC-001-internal-audit-through-batch-06-20260805T1756+0200.json` | 10,070 | `b9ade4687a7a39f64608c3553f969be4f1efe492027282f126cd45ad0476a9fa` | internal audit artifact |
| `SRC-001-internal-audit-through-batch-06-20260805T1756+0200.md` | 5,577 | `a9721b1bb9e718c2c3973b300ae635ba81708c3d72d6339ea3d4bfbabdf8a29b` | internal audit artifact |
| `SRC-001-internal-audit-through-batch-06-20260805T1756+0200.sha256` | 258 | `e1c5d9215131d8aaf2032fd6208869b9323e3078cc8d26944c288230bb07f5ce` | internal audit artifact |

## Other top-level derivative or convenience files

| file | bytes | SHA-256 | category |
|---|---:|---|---|
| `SRC-001-calibration-files-through-B05A-20260804.zip` | 368,068 | `eea06cd6249a08baca50096666c6f9d743e52e019a00013ea41c3db2debd0781` | convenience package |
| `SRC-001-calibration-files-through-B05A-20260804.zip.sha256` | 118 | `97fd1143e24e981414a48ec30e363f14ec2bae49fb94cf6adc37581fb25b8529` | convenience package |

## Expanded and embedded files

These files are deliberate copies or package contents. The JSON inventory
contains the full path, size, digest, and category for each one.

Count: `58`

## Notes

- The proposal files are inputs used by the calibration process. This inventory does not assert who originally authored each proposal.
- Expanded checkpoint and convenience-package directories contain deliberate copies of files also present in ZIP packages. They are listed for completeness but are not all required for transfer.
- The minimum transfer set keeps top-level proposals, checkpoint ZIPs and verification records, human events and receipts, and the audit/correction trail. It excludes expanded directories and the convenience archive because those are derivative.
