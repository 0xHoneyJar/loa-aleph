# SRC-001 Human Exact-Byte Attestation Receipt — Through Batch 05

> NONCANONICAL HUMAN-SUPERVISED DEVELOPMENT-CALIBRATION RECORD
>
> This receipt records explicit human attestation only. It is not a live Aleph
> run, canonical ledger, accepted fixture, replay, validation, sanction,
> independent audit, acceptance, or v1 evidence.

- recorded at: `2026-08-05T14:55:00+02:00`
- source: `SRC-001`
- authority: human
- checkpoint through Batch 05 attestation: `CLOSED`
- SRC-001: `OPEN`
- SRC-002: `NOT AUTHORIZED`

## Exact Human Attestation

I attest the exact bytes of the SRC-001 checkpoint through Batch 05 with SHA-256 18bee5212a11efb5f9b8482d796a74dc2a1a9ab35069ad6eab88856e5b5a10b5. Preserve the checkpoint through Batch 04, its attestation receipt, the exact Batch 05 proposal, all Batch 05 human decision events, this checkpoint, and all immutable inputs unchanged.

## Reverified Digests

- checkpoint through Batch 05 ZIP:
  `18bee5212a11efb5f9b8482d796a74dc2a1a9ab35069ad6eab88856e5b5a10b5` — PASS
- checkpoint through Batch 04 ZIP:
  `f980cf6e48001022bc2f8bfe716a7c385363e7adb4d5c967dd04a3c9e24fceac` — PASS
- Batch 05 proposal:
  `b751820457447d58405865bc8b953148c2a24c911f063f6c1f07ac5ce9560e5e` — PASS

## Remaining Open Findings

1. Exact Batch 02 proposal-byte audit finding.
2. Dedicated review of the 19 mechanical-only normalizations.
3. `B5-001`: Figure 3 formal-material reconciliation with C-120.
4. Whole-source consistency review after all SRC-001 batches.

## Resume Boundary

- next source-order item: `G-021 at L391-L392`
- next original candidate: `C-120 at L393-L395`
- pending repair: `B5-001`
- next proposal: `SRC-001-adjudication-batch-06-proposals.md`
- expected Batch 06 SHA-256:
  `aa4e5c94d4e540eb85c558ac5497c68e8799783dff633d0bd253016389bfd315`
- expected size: `8,558 bytes`
- expected coverage: `L391-L468; C-120-C-145; G-021-G-026`
