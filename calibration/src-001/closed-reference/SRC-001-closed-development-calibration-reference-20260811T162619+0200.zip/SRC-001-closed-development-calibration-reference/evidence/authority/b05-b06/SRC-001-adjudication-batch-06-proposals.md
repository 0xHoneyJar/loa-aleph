# SRC-001 Adjudication: Batch 06 Proposals

> NONCANONICAL MODEL-ASSISTED DEVELOPMENT-CALIBRATION EVIDENCE
>
> These recommendations do not replace open human dispositions and are not
> Loa-Aleph run evidence.

## Batch Identity

| field | exact value |
|---|---|
| review block | `L391-L468` |
| candidate rows | `C-120` through `C-145` |
| no-candidate rows | `G-021` through `G-026` |
| frozen source SHA-256 | `5aef61988ff0db6f2ecc2b7980f370583a317e2427c85a6f78adc3ccc8a1d22a` |
| criteria SHA-256 | `1df51f9872895a3a87a9face2bafe50db34cdfbfd73826e2a31f531c4c538df8` |
| source reopened | frozen text `L391-L468`; exact PDF pages 8-9 |
| criteria changes applied | none |

Each handoff locator and quote was reopened. Figure 3, the dynamic-system page
break, and the discussion/conclusion structure were checked in the exact PDF.

## Candidate Recommendations

| ID | stated criterion satisfied | proposed disposition | reason | replacement, split, or dependency |
|---|---|---|---|---|
| C-120 | yes, criterion 5 | `calibration-accept` | The PDF confirms the caption's comparison, overall super-human result, compare-attribute result, and stated relational-reasoning explanation. | none |
| C-121 | yes, criterion 4 | `calibration-accept` | It preserves the results-derived hypothesis and its explicit contrast with the prior question-parsing explanation. | none |
| C-122 | yes, criterion 6 | `calibration-accept` | It states the CLEVR categorization limitation and the Sort-of-CLEVR design response. | none |
| C-123 | yes, criterion 5 | `calibration-accept` | It preserves both architectures, relational/non-relational conditions, above-94% result, and 63% plateau. | none |
| C-124 | yes, criterion 4 | `edit` | The interpretation and sufficiency claim are valid, but `This` and `these models` must stay tied to C-123's comparison. | Retain the quote and record a dependency on C-123. |
| C-125 | yes, criterion 5 | `calibration-accept` | It records the relation types, CNN+MLP condition, and exact 52.3% result. | none |
| C-126 | yes, criterion 4 | `calibration-accept` | It explains the required distance computation/comparison and preserves the image-dependent magnitude condition and combinatoric difficulty. | none |
| C-127 | yes, criterion 5 | `calibration-accept` | It preserves the 18/20 aggregate, induction-task error, and three model comparators with exact errors. | none |
| C-128 | yes, criterion 5 | `calibration-accept` | It names both failed tasks and their exact margins below the 95% threshold. | none |
| C-129 | yes, criterion 6 | `calibration-accept` | It states the validation-selection procedure and single-seed limitation. | none |
| C-130 | yes, criterion 6 | `edit` | `That is` elaborates C-129's single-seed limitation; isolated, it loses the evaluated-model selection context. | Retain the quote and record a dependency on C-129. |
| C-131 | yes, criterion 5 | `too-narrow` | It begins with the result value after the page break and omits the task, model, and metric subject. | Replace with E-002 below. |
| C-132 | yes, criterion 5 | `edit` | The comparable-parameter MLP result is valid, but `both tasks` must refer to the connection-inference and counting tasks in E-002. | Retain the quote and record a dependency on E-002. |
| C-133 | yes, criterion 5 | `edit` | The transfer result is valid, but `this task` and the learned relation-inference behavior depend on the dynamic-system setup/results in E-002 and C-132. | Retain the quote and record dependencies on E-002 and C-132. |
| C-134 | yes, criterion 4 | `calibration-accept` | It links the plug-in inter-entity relation module to improved performance on rich relational tasks. | none |
| C-135 | yes, criterion 5 | `calibration-accept` | It is a coherent cross-task summary preserving CLEVR 95.5%, bAbI 18/20, and no-catastrophic-failure scope. | none |
| C-136 | yes, criterion 4 | `edit` | `these results` must remain tied to the two-domain evidence summarized in C-135. | Retain the quote and record a dependency on C-135. |
| C-137 | yes, criterion 5 | `calibration-accept` | It reports the RN-inclusion condition, simple CNN/LSTM architecture scope, 68.5%-to-95.5% change, and resulting comparison. | none |
| C-138 | yes, criterion 4 | `calibration-accept` | It preserves the authors' speculative modality and the proposed division between RN reasoning and CNN local-spatial processing. | none |
| C-139 | yes, criterion 4 | `calibration-accept` | It states the processing/reasoning distinction and the qualified limitation of ResNet-like visual processors for arbitrary relations. | none |
| C-140 | yes, criterion 4 | `duplicate` | It repeats C-082's source-attributed conclusion that RN learning induces upstream useful object-like representations. C-082 is the earlier, more explicit evidence-bearing occurrence. | Retain C-082 as the representative. |
| C-141 | yes, criterion 4 | `calibration-accept` | It preserves the absence of specified representation form/semantics and links that condition to structured reasoning with unstructured inputs/outputs. | none |
| C-142 | yes, criterion 7 | `too-broad` | It combines an application agenda with a separate computational-efficiency agenda. | Split into S-142a `L454-L456`: application to RL scene understanding, social networks, and abstract problem solving; and S-142b `L456`: `"Future work could also improve the eﬃciency of RN computations."`, both criterion 7. |
| C-143 | yes, criterion 7 | `calibration-accept` | It preserves the no-required-relation-knowledge result, the conditional ability to exploit such knowledge, and the concrete omission option. | none |
| C-144 | yes, criterion 7 | `calibration-accept` | It preserves strict computational constraints, attentional filtering, and the purpose of bounding otherwise quadratic pairwise-relation complexity. | none |
| C-145 | yes, criterion 4 | `calibration-accept` | It is a complete source conclusion scoped to rich structured reasoning in complex real-world domains. | none |

Proposed disposition counts: `calibration-accept=18`, `edit=5`,
`too-narrow=1`, `duplicate=1`, `too-broad=1`, and
`reject=exclude=uncertain=0`.

## Candidate Repair E-002

C-131's connection result is split by page administration in frozen extraction
order:

- fragment 1, `L425-L426`: `"Finally, we trained our model on two tasks requiring reasoning about the dynamics of balls moving\nalong a surface. In the connection inference task, our model correctly classiﬁed all the connections in"`
- fragment 2, `L429-L430`: `"93% of the sample scenes in the test set. In the counting task, the RN achieved similar performance,\nreporting the correct number of connected systems for 95% of the test scene samples."`
- proposed criterion: `5`
- preserved conditions and metrics: dynamic balls; connection inference; all
  connections correct in 93% of test scenes; connected-system count correct in
  95% of test scenes.
- unresolved representation: retain paired exact fragments until the
  extraction-order policy is human-resolved.

## No-Candidate Recommendations

| review ID | proposed decision | exclusion reason or defect | missing-packet decision |
|---|---|---|---|
| G-021 (`L391-L392`) | no packet appropriate | Final Figure 3 category labels; the exact PDF's assertions are carried by C-120 and result prose. | Exclude as figure labels without an independent assertion. |
| G-022 (`L396`) | no packet appropriate | `5.3 Sort-of-CLEVR from pixels` is a section heading (`document-administration`). | none |
| G-023 (`L414`) | no packet appropriate | `5.4 bAbI` is a section heading (`document-administration`). | none |
| G-024 (`L424-L428`) | no-candidate status is not fully appropriate | `L424` is a heading; `L425-L426` begins the substantive E-002 result; `L427-L428` is page administration. | Add E-002; exclude only L424 and L427-L428 as document-administration. |
| G-025 (`L435`) | no packet appropriate | `6 Discussion and Conclusions` is a section heading (`document-administration`). | none |
| G-026 (`L465-L468`) | no packet appropriate | Acknowledgments heading, names/thanks, and page number assert no independent subject-matter claim. | Exclude as document-administration/acknowledgment. |

## Provisional Criteria Observations

No new criteria change is proposed. E-002 is another instance of the already
recorded page-administration interruption problem.

## Human Gate

No handoff row has been changed. A human must explicitly adopt, revise, or
reject these recommendations. SRC-001 remains open, and SRC-002 must not begin.
