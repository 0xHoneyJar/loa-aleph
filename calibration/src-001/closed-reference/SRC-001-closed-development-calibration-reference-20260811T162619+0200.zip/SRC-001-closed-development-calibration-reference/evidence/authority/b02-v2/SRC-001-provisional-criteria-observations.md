# SRC-001 Provisional Criteria Observations Through Batch 02

> These observations are separate from candidate decisions. No criteria text, digest, supersession, prompt, contract, fixture, or verifier was changed.

## PO-001

- Status: `human-accepted-as-provisional-observation`
- Observation: Formal-material handling should support equation blocks plus symbol definitions, preserve exact degraded frozen evidence, and permit PDF-confirmed readable rendering as non-authoritative metadata.
- Supporting examples: `C-029`, `C-042`, `C-043`, `C-053`
- Accepted criteria change: `NONE`

## PO-002

- Status: `provisional-derived-from-accepted-decisions`
- Observation: A PDF-contiguous sentence can be split into discontiguous frozen-text fragments by figure or page administration; the criteria do not define a canonical locator/quote shape for this case.
- Supporting examples: `M-001a`, `M-001b`, `C-030`, `G-006`, `C-031`
- Accepted criteria change: `NONE`

## PO-003

- Status: `provisional-derived-from-accepted-decisions`
- Observation: Mechanically split or pronoun-led candidates often need explicit dependencies rather than duplicative widening.
- Supporting examples: `C-021`, `C-039`, `C-045`, `C-053`
- Accepted criteria change: `NONE`

## PO-004

- Status: `provisional-derived-from-accepted-decisions`
- Observation: Citation scope across split compound sentences must remain explicit and should not be silently reassigned to only one child unit.
- Supporting examples: `C-012a-b`, `C-013a-b`, `C-049a-b`
- Accepted criteria change: `NONE`

## PO-005

- Status: `provisional-derived-from-accepted-decisions`
- Observation: Flattened subsection headings must be distinguished from body prose; repeated heading assertions should be disposed as duplicates rather than counted as independent evidence.
- Supporting examples: `C-034`, `C-040`, `C-044`
- Accepted criteria change: `NONE`

## Boundary

These observations may inform later cross-source criteria analysis. They are not canonical changes and must not be silently applied to the remainder of SRC-001.
