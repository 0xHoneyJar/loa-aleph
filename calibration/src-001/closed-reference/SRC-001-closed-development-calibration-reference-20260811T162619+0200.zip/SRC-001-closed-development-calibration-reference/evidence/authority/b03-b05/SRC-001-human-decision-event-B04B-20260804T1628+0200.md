# SRC-001 Human Decision Event — Batch 04B

> NONCANONICAL HUMAN-SUPERVISED EXTRACTION-CALIBRATION RECORD
>
> This event is not a live Aleph run, canonical ledger, accepted fixture,
> replay, validation, sanction, independent audit, acceptance, or v1 evidence.

- recorded at: `2026-08-04T16:28:00+02:00`
- source: `SRC-001`
- authority: human
- scope: decisions named in the exact block below only
- immutable inputs mutated: `false`
- SRC-001 closed: `false`
- SRC-002 started: `false`
- next candidate: `C-099`
- next locator: `L290-L292`

## Exact Human Decision Block

Adopt every decision in this block exactly as written

C-093 — too-broad. Classify the inline “Dealing with state descriptions” text as subsection scope rather than an independent assertion. Replace C-093 for calibration purposes with C-093a and C-093b.

C-093a — retain the exact evidence “We can provide state descriptions directly into the RN, since
state descriptions are pre-factored object representations.” at L276-L277 under criterion 3. Use the normalized wording: “The authors provide state descriptions directly to the RN because state descriptions are pre-factored object representations.” Record no dependency or citation. Preserve the source’s stated link between the pre-factored representation and direct RN input.

C-093b — retain the exact evidence “Question processing can proceed as before:
questions pass through an LSTM using a learnable lookup embedding for individual words, and the
final state of the LSTM is concatenated to each object-pair.” at L277-L279 under criterion 3. Use the normalized wording: “For the state-description RN setup in C-093a, questions pass through an LSTM using a learnable lookup embedding for individual words, and the LSTM’s final state is concatenated to each object pair.” Record a dependency on C-093a to preserve the state-description task scope. Record no citation. Record partial semantic overlap with C-089 and C-090 and do not treat the repeated lookup-embedding and LSTM-processing content as independent evidence.

C-094 — calibration-accept. Retain the exact evidence at L280-L282 under criterion 2, including the inline “Dealing with natural language” heading. Use the normalized wording: “For the bAbI task suite, natural-language inputs must be transformed into a set of objects. This requirement is distinctly different from visual QA, where objects were defined as spatially distinct regions in convolved feature maps.” Record no dependency or citation. Classify “Dealing with natural language” as subsection scope rather than an independent assertion. Preserve “must” and “distinctly different.” Record partial semantic overlap with C-085 and C-091 and do not treat the repeated visual-QA object-construction proposition as independent evidence.

C-095 — edit. Retain the exact evidence at L282-L285 under criterion 3. Use the normalized wording: “To perform the bAbI natural-language transformation described in C-094, the authors first identified up to 20 support-set sentences immediately preceding the probe question, tagged the sentences with labels indicating their relative positions in the support set, and processed each sentence word by word using the same LSTM applied independently to each sentence.” Record a dependency on C-094 to preserve the design requirement expressed by “So.” Record no citation. Preserve “up to 20,” “immediately prior,” relative-position labels, word-wise processing, reuse of the same LSTM, and independent per-sentence application.

C-096 — edit. Retain the exact evidence at L286-L287 under criterion 6. Use the normalized wording: “The authors note that the setup in C-095 invokes minimal prior knowledge because it delineates objects as sentences, whereas previous bAbI models processed all word tokens from all support sentences sequentially.” Record a dependency on C-095 to resolve “this setup.” Record no citation. Preserve “minimal prior knowledge,” not zero prior knowledge, and preserve “previous” as relative to the source’s publication context.

C-097 — edit. Retain the exact evidence at L288-L289 under criterion 6. Use the normalized wording: “The authors state that it is unclear how much advantage the sentence-delineation prior described in C-096 provides, because period punctuation also unambiguously delineates sentences for token-by-token processing models.” Record a dependency on C-096 to resolve “this prior knowledge.” Record no citation. Preserve the uncertainty; do not convert it into a conclusion that the prior provides no advantage or that punctuation eliminates the advantage.

C-098 — edit. Retain the exact evidence at L289-L290 under criterion 2. Use the normalized wording: “In the bAbI sentence-processing pipeline described in C-095, the final state of the sentence-processing LSTM is considered an object.” Record a dependency on C-095 to resolve the sentence-processing-LSTM referent. Record no citation. Preserve “is considered” as representational language rather than asserting that the state intrinsically is an object. Record partial semantic overlap with future C-163 and reconcile that repetition when C-163 is adjudicated without treating it as independent evidence.


## Pinned Inputs

- corrected checkpoint v2 ZIP SHA-256: `280231bef8b9e740a6959ac9e9b517ed067b3fc3882ebe5d94488b0006cd9041`
- checkpoint through Batch 03 ZIP SHA-256: `84f50e8f697c382dfc436e2cbb6f22d8b999e8207de22ff29db7d51d39b45d32`
- Batch 04 proposal SHA-256: `eaf54c5689e2f86330d1f5b9b4f56198ee558e9492491f06a8d5df88c30cd38a`
