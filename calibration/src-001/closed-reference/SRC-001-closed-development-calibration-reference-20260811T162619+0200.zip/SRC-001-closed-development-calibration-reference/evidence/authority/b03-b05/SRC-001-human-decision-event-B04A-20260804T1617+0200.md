# SRC-001 Human Decision Event — Batch 04A

> NONCANONICAL HUMAN-SUPERVISED EXTRACTION-CALIBRATION RECORD
>
> This event is not a live Aleph run, canonical ledger, accepted fixture,
> replay, validation, sanction, independent audit, acceptance, or v1 evidence.

- recorded at: `2026-08-04T16:17:00+02:00`
- source: `SRC-001`
- authority: human
- scope: decisions named in the exact block below only
- immutable inputs mutated: `false`
- SRC-001 closed: `false`
- SRC-002 started: `false`
- closed repair: `B3-001`
- next candidate: `C-093`
- next locator: `L276-L279`

## Exact Human Decision Block

Adopt every decision in this block exactly as written

C-087 — too-narrow. Replace the original L235-L236 evidence with the complete evidence at L234-L236: “The existence and meaning of an object-object
relation should be question dependent. For example, if a question asks about a large sphere, then
the relations between small cubes are probably irrelevant.” Retain criterion 4. Use the normalized wording: “The authors state that the existence and meaning of an object-object relation should be question dependent; for example, when a question asks about a large sphere, relations between small cubes are probably irrelevant.” Record no dependency or citation. Continue to exclude only the subsection heading “Conditioning RNs with question embeddings” as document-administration. Record cross-batch repair B3-001 as resolved through the widened C-087.

C-088 — edit. Retain the exact evidence at L236-L238 under criterion 3. Use the normalized wording: “To implement the question dependence described in C-087, the authors modified the RN defined in C-029 so that gθ conditions its processing on the question embedding q defined in C-089: a=fφ(∑i,j gθ(oi,oj,q)).” Record dependencies on C-087 for the rationale, C-029 for the base RN function and symbol definitions, and C-089 for the definition of q. Record no citation. Preserve the exact frozen equation and record the PDF-readable rendering a=fφ(∑i,j gθ(oi,oj,q)) as formal-material clarification without changing the exact quote.

C-089 — edit. Retain the exact evidence at L238-L241 under criterion 3. Use the normalized wording: “For the question-conditioned RN in C-088, the authors formed the question embedding q from the final state of an LSTM that processed question words; each word was assigned a unique integer used to index a learnable lookup table that supplied embeddings to the LSTM.” Record a dependency on C-088 for the architectural role of q. Record no citation. Treat the integer lookup, word embeddings, LSTM processing, and final-state output as one coherent encoding pipeline.

C-090 — edit. Retain the exact evidence at L241-L242 under criterion 3. Use the normalized wording: “At each time step, the question-processing LSTM described in C-089 received a single word embedding as input, according to the syntax of the English-encoded question.” Record a dependency on C-089 to resolve “the LSTM.” Record no citation. Preserve “according to the syntax” without reducing it to an unsupported narrower description.

G-015 — no packet appropriate. Record L243-L244 as page administration and L245-L270 as Figure 2 diagram labels, operators, example question material, example objects, and illustrated output without a separate prose assertion. Record no missing packet. Preserve Figure 2’s claim-bearing content through C-091 and C-092 and its composite function through C-088; do not create fragmented packets from individual diagram labels.

C-091 — calibration-accept. Retain the exact evidence at L271-L274 under criterion 2. Use the normalized wording: “Figure 2 presents the visual-QA architecture: an LSTM processes questions to produce a question embedding, while a CNN processes images to produce RN objects constructed from feature-map vectors in the convolved image; three example objects are illustrated in yellow, red, and blue.” Record no dependency or citation. Record partial semantic overlap with C-089, C-083, and C-085 and do not treat the repeated component descriptions as independent evidence. Record that the colored examples illustrate object construction and are not separate empirical results.

C-092 — edit. Retain the exact evidence at L274-L275 under criterion 2. Use the normalized wording: “In the Figure 2 visual-QA architecture described in C-091, the RN considers relations across all object pairs conditioned on the question embedding, integrates those relations, and uses the result to answer the question.” Record a dependency on C-091 to preserve the Figure 2 visual-QA, object, and question-embedding scope. Record no citation. Record partial semantic overlap with C-034 and C-088 and do not treat the repeated all-pairs or question-conditioning propositions as independent evidence.


## Pinned Inputs

- corrected checkpoint v2 ZIP SHA-256: `280231bef8b9e740a6959ac9e9b517ed067b3fc3882ebe5d94488b0006cd9041`
- checkpoint through Batch 03 ZIP SHA-256: `84f50e8f697c382dfc436e2cbb6f22d8b999e8207de22ff29db7d51d39b45d32`
- Batch 04 proposal SHA-256: `eaf54c5689e2f86330d1f5b9b4f56198ee558e9492491f06a8d5df88c30cd38a`
