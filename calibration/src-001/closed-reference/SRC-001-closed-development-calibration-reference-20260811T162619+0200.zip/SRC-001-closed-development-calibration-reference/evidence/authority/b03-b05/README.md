# SRC-001 Calibration Files Through Batch 05A

This download bundle contains the SRC-001 files currently available in the
active workspace through the Batch 05A human decision event.

Included:
- immutable proposal files for Batches 03, 04, and 05;
- checkpoint ZIPs through Batches 02 v2, 03, and 04;
- checkpoint sidecars and post-build verification records;
- Batch 03, Batch 04, and Batch 05A human decision events;
- Batch 03 and Batch 04 exact-byte attestation receipts;
- the Batch 04 proposal authority receipt.

The expanded Batch 04 checkpoint directory is not duplicated here because its
exact files are already contained in SRC-001-checkpoint-through-batch-04.zip.

This bundle is a download convenience package. It is not a new checkpoint,
canonical ledger, independent audit, replay, validation, sanction, acceptance,
or v1 evidence. The files listed in CHECKSUMS.sha256 are copied byte-for-byte
from the active workspace.
