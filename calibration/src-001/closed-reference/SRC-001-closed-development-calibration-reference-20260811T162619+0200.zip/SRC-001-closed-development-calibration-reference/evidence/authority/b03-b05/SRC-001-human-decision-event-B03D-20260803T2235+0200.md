# SRC-001 Human Decision Event — Batch 03D

> NONCANONICAL HUMAN-SUPERVISED EXTRACTION-CALIBRATION RECORD
>
> This event is not a live Aleph run, canonical ledger, accepted fixture,
> replay, validation, sanction, independent audit, acceptance, or v1 evidence.

- recorded at: `2026-08-03T22:35:00+02:00`
- source: `SRC-001`
- authority: human
- scope: decisions named in the exact block below only
- immutable inputs mutated: `false`
- SRC-001 closed: `false`
- SRC-002 started: `false`
- next candidate: `C-078`
- next locator: `L214-L216`

## Exact Human Decision Block

Adopt every decision in this block exactly as written

C-072 — edit. Retain the exact evidence at L199-L201 under criterion 3. Use the normalized wording: “In the simulated physical-system scenes described in C-071, other randomly selected ball pairs were connected by invisible springs or a rigid constraint. Forces imposed through those connections prevented the connected balls from moving independently.” Record a dependency on C-071 to preserve the scene scope and contrast with independently moving balls. Record no citation.

C-073 — edit. Retain the exact evidence at L201-L204 under criterion 3. Use the normalized wording: “For the simulated physical-system dataset described in C-071, input data consisted of state-description matrices in which each ball was represented by one row containing its RGB color values and spatial coordinates (x, y) across 16 sequential time steps.” Record a dependency on C-071 to preserve the dataset scope. Record no citation. Record partial semantic overlap with C-197; reconcile the repeated state-description, feature, and 16-time-step content when C-197 is adjudicated, without treating repetition as independent evidence.

C-074 — calibration-accept. Retain the exact evidence at L205-L207 under criterion 3, including the frozen phrase “a variable number ‘systems’.” Use the normalized wording: “Introducing random links between balls created an evolving physical system with a variable number of connected-ball ‘systems,’ where a system is a connected graph with balls as nodes and connections as edges.” Record no dependency or citation. Treat the graph definition as a necessary qualifier within the same unit, not as an independent split.

C-075 — too-broad. Replace it for calibration purposes with C-075a and C-075b.

C-075a — retain the exact evidence “1) infer the
existence or absence of connections between balls when only observing their color and coordinate
positions across multiple sequential frames” at L207-L209 under criterion 3. Use the normalized wording: “The authors defined a connection-inference task: infer the existence or absence of connections between balls using only their color and coordinate positions observed across multiple sequential frames.” Record no dependency or citation.

C-075b — retain the exact evidence “2) count the number of systems on the table-top,
again when only observing each ball’s color and coordinate position across multiple sequential frames.” at L209-L210 under criterion 3. Use the normalized wording: “The authors defined a system-counting task: count the number of connected-ball systems on the tabletop using only each ball’s color and coordinate position observed across multiple sequential frames.” Record a dependency on C-074 for the connected-graph definition of “system.” Record no citation.

C-076 — edit. Retain the exact evidence at L211-L213 under criterion 4. Use the normalized wording: “Both dynamic-system tasks defined in C-075a and C-075b involve reasoning about the balls’ relative positions and velocities to infer whether the balls move independently or whether their movement is somehow dependent on other balls through invisible connections.” Record dependencies on C-075a and C-075b to resolve “Both of these tasks.” Preserve “somehow dependent” without strengthening the mechanism. Record no citation.

C-077 — edit. Retain the exact evidence at L213-L214 under criterion 4. Use the normalized wording: “As an example of the reasoning described in C-076, the authors state that if the distance between two balls remains similar across frames, a connection between them can be inferred.” Record a dependency on C-076. Preserve “remains similar” rather than replacing it with exact equality, and preserve “can be inferred” rather than treating the condition as proof. Record no citation.


## Pinned Inputs

- corrected checkpoint v2 ZIP SHA-256: `280231bef8b9e740a6959ac9e9b517ed067b3fc3882ebe5d94488b0006cd9041`
- Batch 03 proposal SHA-256: `7fa12aa984252250e82d3ba3ca7cedb9374d53db3bcd42d99056347b342f8cc8`
