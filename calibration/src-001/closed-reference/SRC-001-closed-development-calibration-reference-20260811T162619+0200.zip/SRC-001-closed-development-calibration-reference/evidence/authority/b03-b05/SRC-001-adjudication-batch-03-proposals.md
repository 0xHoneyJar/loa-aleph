# SRC-001 Adjudication: Batch 03 Proposals

> NONCANONICAL MODEL-ASSISTED DEVELOPMENT-CALIBRATION EVIDENCE
>
> These recommendations do not replace open human dispositions and are not
> Loa-Aleph run evidence.

## Batch Identity

| field | exact value |
|---|---|
| review block | `L157-L234` |
| candidate rows | `C-054` through `C-086` |
| no-candidate rows | `G-010` through `G-014` |
| frozen source SHA-256 | `5aef61988ff0db6f2ecc2b7980f370583a317e2427c85a6f78adc3ccc8a1d22a` |
| criteria SHA-256 | `1df51f9872895a3a87a9face2bafe50db34cdfbfd73826e2a31f531c4c538df8` |
| source reopened | frozen text `L157-L234`; exact PDF pages 4-5 |
| criteria changes applied | none |

Each handoff locator and exact quote was reopened in the frozen text. The PDF
was checked for dataset layout, footnote placement, and the degraded `d²`
notation.

## Candidate Recommendations

| ID | stated criterion satisfied | proposed disposition | reason | replacement or split |
|---|---|---|---|---|
| C-054 | yes, criterion 5 | `calibration-accept` | It preserves the relational question types, model result, simplest-baseline comparison, and baseline definition. | none |
| C-055 | yes, criterion 3 | `calibration-accept` | It identifies both CLEVR input versions and their exact representation forms. | none |
| C-056 | yes, criterion 3 | `calibration-accept` | It records the per-object row structure and all listed state-description features. | none |
| C-057 | yes, criterion 3 | `calibration-accept` | It preserves the per-experiment either/or input choice and the condition that the two versions were not combined. | none |
| C-058 | yes, criterion 3 | `calibration-accept` | It records the comparative hypothesis, construction purpose, CLEVR similarity, and separation of relational from non-relational questions. | none |
| C-059 | yes, criterion 3 | `calibration-accept` | It preserves image dimensionality, object count, random shape choice, color count, and the identification purpose. | none |
| C-060 | yes, criterion 4 | `calibration-accept` | It links fixed-length binary question encoding to removing natural-language parsing as a confound. | none |
| C-061 | yes, criterion 3 | `calibration-accept` | It records the exact per-image balance of relational and non-relational questions. | none |
| C-062 | yes, criterion 3 | `calibration-accept` | It gives the source's two concrete relational-question constructions. | none |
| C-063 | yes, criterion 3 | `calibration-accept` | It gives the source's two concrete non-relational-question constructions. | none |
| C-064 | yes, criterion 4 | `calibration-accept` | It links visual simplicity to reducing image-processing complexity. | none |
| C-065 | yes, criterion 1 | `calibration-accept` | It defines bAbI as text QA and states its 20 task types with reasoning examples. | none |
| C-066 | yes, criterion 1 | `calibration-accept` | It defines the supporting-fact structure and preserves the complete example and answer. | none |
| C-067 | yes, criterion 5 | `calibration-accept` | It defines the exact bAbI task-success threshold of greater than 95%. | none |
| C-068 | yes, criterion 5 | `duplicate` | Its qualitative assertion that memory-augmented networks have impressive bAbI results is immediately specified by C-069 with models, training conditions, and metrics. | Retain C-069 as the evidence-bearing representative. |
| C-069 | yes, criterion 5 | `calibration-accept` | It preserves joint-training conditions, examples per task, four model results, and the EntNet non-joint-training caveat. | none |
| C-070 | no | `exclude` | The footnote promises future public availability of a dataset. It is an availability notice, not a claim about representation, organization, training, evaluation, or design under the unchanged definition. | none |
| C-071 | yes, criterion 3 | `calibration-accept` | It records simulator, scene size, surface, independent motion, and collision conditions. | none |
| C-072 | yes, criterion 3 | `calibration-accept` | It records random pair selection, spring/rigid constraints, and their effect on independent motion. | none |
| C-073 | yes, criterion 3 | `calibration-accept` | It preserves matrix rows, RGB and spatial features, and the 16-step temporal condition. | none |
| C-074 | yes, criterion 3 | `calibration-accept` | It records random-link construction and defines a system as a connected graph with balls as nodes and connections as edges. | none |
| C-075 | yes, criterion 3 | `calibration-accept` | It preserves both task definitions and the color/coordinate-only, multi-frame observation condition. | none |
| C-076 | yes, criterion 4 | `calibration-accept` | It links relative position/velocity reasoning to inferring independent versus connection-dependent motion. | none |
| C-077 | yes, criterion 4 | `calibration-accept` | It states the exact cross-frame distance condition used to infer a connection. | none |
| C-078 | yes, criterion 6 | `calibration-accept` | It distinguishes explicit from implicit inference and preserves the source's relative-difficulty claim. | none |
| C-079 | yes, criterion 2 | `calibration-accept` | It states the simplest-form RN input boundary: objects rather than images or natural language. | none |
| C-080 | yes, criterion 2 | `calibration-accept` | It states that relatively unstructured CNN/LSTM embeddings can be treated as RN object sets. | none |
| C-081 | yes, criterion 6 | `calibration-accept` | It preserves the object-representation input requirement and the absence of a required object semantics specification. | none |
| C-082 | yes, criterion 4 | `calibration-accept` | It attributes to the reported results the claim that learning induces upstream conventional modules to produce useful objects from distributed representations. | none |
| C-083 | yes, criterion 3 | `calibration-accept` | It records the CNN parsing method, image size, layer count, feature-map count, feature-map size, and definition of `k`. | none |
| C-084 | yes, criterion 6 | `calibration-accept` | It preserves the deliberate agnosticism about which image features constitute an object. | none |
| C-085 | yes, criterion 3 | `calibration-accept` | It records how each spatially tagged `d²`, `k`-dimensional feature-map cell becomes an RN object. The PDF confirms the degraded superscript. | none |
| C-086 | yes, criterion 4 | `calibration-accept` | It preserves the possible object contents and links that semantic flexibility to learning flexibility. | none |

Proposed disposition counts: `calibration-accept=31`, `duplicate=1`,
`exclude=1`, and `edit=reject=too-broad=too-narrow=uncertain=0`.

## No-Candidate Recommendations

| review ID | proposed decision | exclusion reason or defect | missing-packet decision |
|---|---|---|---|
| G-010 (`L168`) | no packet appropriate | `3.2 Sort-of-CLEVR` is a section heading (`document-administration`). | none |
| G-011 (`L183`) | no packet appropriate | `3.3 bAbI` is a section heading (`document-administration`). | none |
| G-012 (`L194-L196`) | no packet appropriate | Page number, blank line, and `3.4 Dynamic physical systems` heading (`document-administration`). | none |
| G-013 (`L217-L218`) | no packet appropriate | Supplementary-information pointer plus `4 Models` heading (`document-administration`); neither independently asserts subject matter. | none |
| G-014 (`L234`) | no-candidate status is not appropriate | After the subsection heading, `L234` begins the subject of a substantive assertion whose predicate is at `L235`. | Reconcile with C-087 in batch 04. At minimum, preserve `L234-L235`: `"The existence and meaning of an object-object\nrelation should be question dependent."` |

## Cross-Batch Repair B3-001

- affected source: `L234-L235`
- exact claim: `"The existence and meaning of an object-object\nrelation should be question dependent."`
- proposed criterion: `2`
- status: claim-bearing content is missing from G-014 and must be included in
  the batch-04 decision for C-087; the `Conditioning RNs with question
  embeddings` text at the start of L234 remains a subsection heading.

## Provisional Criteria Observations

No new criteria observation arose in this batch. The earlier unresolved
extraction-order observation remains provisional and unchanged.

## Human Gate

No handoff row has been changed. A human must explicitly adopt, revise, or
reject these recommendations. SRC-001 remains open, and SRC-002 must not begin.
