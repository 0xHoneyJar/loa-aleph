# SRC-001 Human Decision Event — Batch 03A

> NONCANONICAL APPEND-ONLY HUMAN DECISION EVENT
>
> This is not a live Aleph run, worker return, canonical packet ledger, accepted fixture, production execution, replay, validation, sanction, independent audit, acceptance, or v1.

- event ID: `SRC-001-HUMAN-DECISION-EVENT-B03A-20260803T2055+0200`
- authority: Eileen (human operator)
- authorization time: `2026-08-03T20:55+02:00`
- parent checkpoint preserved unchanged: `280231bef8b9e740a6959ac9e9b517ed067b3fc3882ebe5d94488b0006cd9041`
- Batch 03 proposal preserved unchanged: `7fa12aa984252250e82d3ba3ca7cedb9374d53db3bcd42d99056347b342f8cc8`
- authoritative decisions: `C-054` through `C-059`, plus `G-010`
- next unreviewed candidate: `C-060` at `L175-L177`

## Verbatim Human Authorization

```text
Adopt every decision in this block exactly as written

C-054 — edit. Retain the exact evidence at L157-L160 under criterion 5. Use the normalized wording: “For CLEVR compare-attribute and count questions—questions heavily involving relations across objects—the ResNet-101/LSTM/stacked-attention model described in C-053 performed little better than the simplest baseline, the Q-type baseline, which answered from training-set answer probabilities for each question category.” Record a dependency on C-053 for the model antecedent, original-paper attribution, and contrast. Citation [15] remains scoped through C-053 and is not inserted into C-054’s exact evidence.

C-055 — calibration-accept. Retain the exact evidence at L161-L163 under criterion 3. Use the normalized wording: “The authors used two versions of CLEVR: a pixel version, with images represented in standard 2D pixel form, and a state-description version, with images explicitly represented as state-description matrices containing factored object descriptions.” Record no dependency.

C-056 — edit. Retain the exact evidence at L163-L165 under criterion 3. Use the normalized wording: “In the CLEVR state-description matrices defined in C-055, each row contained one object’s 3D coordinates (x, y, z), color (r, g, b), shape, material, and size.” Record a dependency on C-055 to resolve “the matrix” and preserve CLEVR scope.

C-057 — edit. Retain the exact evidence at L165-L167 under criterion 3. Use the normalized wording: “When training their models, the authors used either the CLEVR pixel version or the CLEVR state-description version defined in C-055, depending on the experiment, but did not use both together.” Record a dependency on C-055 to resolve the two version referents.

G-010 — no packet appropriate. L168 is solely the “3.2 Sort-of-CLEVR” section heading and is excluded as document-administration. Record no missing packet.

C-058 — calibration-accept. Retain the exact evidence at L169-L171, including the footnote marker, under criterion 3. Use the normalized wording: “To explore their hypothesis that RN architecture is better suited than more standard neural architectures to general relational reasoning, the authors constructed a CLEVR-like dataset called Sort-of-CLEVR that separates relational and non-relational questions.” Record no dependency. Record that the footnote marker refers only to the separate future-availability notice handled at C-070.

C-059 — calibration-accept. Retain the exact evidence at L172-L175 under criterion 3. Use the normalized wording: “Sort-of-CLEVR consists of images of 2D colored shapes with associated questions and answers. Each image contains six objects, each randomly chosen as a square or circle; six colors—red, blue, green, orange, yellow, and gray—identify the objects unambiguously.” Record no dependency.
```

## Structured Decision Summary

### C-054 — `edit`

- locator: `L157-L160`
- criterion: `5`
- dependencies: `C-053`
- normalized wording: For CLEVR compare-attribute and count questions—questions heavily involving relations across objects—the ResNet-101/LSTM/stacked-attention model described in C-053 performed little better than the simplest baseline, the Q-type baseline, which answered from training-set answer probabilities for each question category.

### C-055 — `calibration-accept`

- locator: `L161-L163`
- criterion: `3`
- dependencies: `none`
- normalized wording: The authors used two versions of CLEVR: a pixel version, with images represented in standard 2D pixel form, and a state-description version, with images explicitly represented as state-description matrices containing factored object descriptions.

### C-056 — `edit`

- locator: `L163-L165`
- criterion: `3`
- dependencies: `C-055`
- normalized wording: In the CLEVR state-description matrices defined in C-055, each row contained one object’s 3D coordinates (x, y, z), color (r, g, b), shape, material, and size.

### C-057 — `edit`

- locator: `L165-L167`
- criterion: `3`
- dependencies: `C-055`
- normalized wording: When training their models, the authors used either the CLEVR pixel version or the CLEVR state-description version defined in C-055, depending on the experiment, but did not use both together.

### C-058 — `calibration-accept`

- locator: `L169-L171`
- criterion: `3`
- dependencies: `none`
- normalized wording: To explore their hypothesis that RN architecture is better suited than more standard neural architectures to general relational reasoning, the authors constructed a CLEVR-like dataset called Sort-of-CLEVR that separates relational and non-relational questions.

### C-059 — `calibration-accept`

- locator: `L172-L175`
- criterion: `3`
- dependencies: `none`
- normalized wording: Sort-of-CLEVR consists of images of 2D colored shapes with associated questions and answers. Each image contains six objects, each randomly chosen as a square or circle; six colors—red, blue, green, orange, yellow, and gray—identify the objects unambiguously.

### G-010 — `no packet appropriate`

- locator: `L168`
- exclusion: section heading; document administration
- missing packet: `none`

## Status

- SRC-001: `OPEN_FOR_HUMAN_ADJUDICATION`
- SRC-002: `NOT AUTHORIZED`
- corrected checkpoint v2 exact-byte attestation: `PENDING HUMAN HASH ATTESTATION`
