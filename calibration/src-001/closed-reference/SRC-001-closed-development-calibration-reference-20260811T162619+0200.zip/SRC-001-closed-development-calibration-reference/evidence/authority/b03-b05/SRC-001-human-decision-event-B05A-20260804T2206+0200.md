# SRC-001 Human Decision Event — Batch 05A

> NONCANONICAL HUMAN-SUPERVISED EXTRACTION-CALIBRATION RECORD

- recorded at: `2026-08-04T22:06:00+02:00`
- source: `SRC-001`
- authority: human
- adopted packets: `T1-001` through `T1-006`
- immutable inputs mutated: `false`
- SRC-001 closed: `false`
- SRC-002 started: `false`
- G-017: `OPEN_PENDING_T1-007_AND_C-108`
- B4-002: `OPEN_PENDING_COMPLETE_TABLE_1_RECONCILIATION`
- next source-order item: `T1-007 at L319`
- next original candidate: `C-107 at L320`

## Exact Human Decision Block

Adopt every decision in this block exactly as written

T1-001 — add missing packet. Retain the exact evidence “Human 92.6 86.7 96.6 86.5 95.0 96.0” at L313 under criterion 5. Use the normalized wording: “On the CLEVR-from-pixels test set, the Human row in Table 1 reports accuracy values of 92.6 overall, 86.7 for Count, 96.6 for Exist, 86.5 for Compare Numbers, 95.0 for Query Attribute, and 96.0 for Compare Attribute.” Record a formal-material dependency on the Table 1 header at L307-L312 and a forward claim dependency on C-108 for the test-set, CLEVR-from-pixels, and accuracy scope. Record no direct citation. Record partial overlap with C-053’s 92.6 overall human-performance value and do not treat that repeated value as independent evidence.

T1-002 — add missing packet. Retain the exact evidence “Q-type baseline 41.8 34.6 50.2 51.0 36.0 51.3” at L314 under criterion 5. Use the normalized wording: “On the CLEVR-from-pixels test set, the Q-type baseline defined in C-054 reports Table 1 accuracy values of 41.8 overall, 34.6 for Count, 50.2 for Exist, 51.0 for Compare Numbers, 36.0 for Query Attribute, and 51.3 for Compare Attribute.” Record a formal-material dependency on the Table 1 header at L307-L312 and dependencies on C-108 for the table scope and C-054 for the baseline definition. Record no direct citation. Preserve the distinction between C-054’s definition and qualitative comparison and T1-002’s quantitative breakdown.

T1-003 — add missing packet. Retain the exact evidence “LSTM 46.8 41.7 61.1 69.8 36.8 51.8” at L315 under criterion 5. Use the normalized wording: “On the CLEVR-from-pixels test set, the LSTM row in Table 1 reports accuracy values of 46.8 overall, 41.7 for Count, 61.1 for Exist, 69.8 for Compare Numbers, 36.8 for Query Attribute, and 51.8 for Compare Attribute.” Record a formal-material dependency on the Table 1 header at L307-L312 and a forward claim dependency on C-108. Record no direct citation.

T1-004 — add missing packet. Retain the exact evidence “CNN+LSTM 52.3 43.7 65.2 67.1 49.3 53.0” at L316 under criterion 5. Use the normalized wording: “On the CLEVR-from-pixels test set, the CNN+LSTM row in Table 1 reports accuracy values of 52.3 overall, 43.7 for Count, 65.2 for Exist, 67.1 for Compare Numbers, 49.3 for Query Attribute, and 53.0 for Compare Attribute.” Record a formal-material dependency on the Table 1 header at L307-L312 and a forward claim dependency on C-108. Record no direct citation. Record partial overlap with C-053’s unnamed 52.3 next-best comparator and do not treat the repeated overall value as independent evidence.

T1-005 — add missing packet. Retain the exact evidence “CNN+LSTM+SA 68.5 52.2 71.1 73.5 85.3 52.3” at L317 under criterion 5. Use the normalized wording: “On the CLEVR-from-pixels test set, the CNN+LSTM+SA row in Table 1 reports accuracy values of 68.5 overall, 52.2 for Count, 71.1 for Exist, 73.5 for Compare Numbers, 85.3 for Query Attribute, and 52.3 for Compare Attribute.” Record a formal-material dependency on the Table 1 header at L307-L312 and a forward claim dependency on C-108. Record no direct citation. Record partial semantic and numeric overlap with C-053 and C-054, retain the row for its complete metric breakdown, and do not treat repeated values or comparisons as independent evidence. Do not import or merge C-053’s citation [15] into this row.

T1-006 — add missing packet. Retain the exact evidence “CNN+LSTM+SA* 76.6 64.4 82.7 77.4 82.6 75.4” at L318 under criterion 5, including the asterisk. Use the normalized wording: “On the CLEVR-from-pixels test set, the starred CNN+LSTM+SA implementation whose qualifying condition is recorded in C-107 reports Table 1 accuracy values of 76.6 overall, 64.4 for Count, 82.7 for Exist, 77.4 for Compare Numbers, 82.6 for Query Attribute, and 75.4 for Compare Attribute.” Record a formal-material dependency on the Table 1 header at L307-L312 and forward dependencies on C-108 for the table scope and C-107 for the starred implementation and training condition. Record no direct citation. Preserve T1-006 separately from T1-005 because the star marks a differently conditioned implementation. Do not pre-decide C-107’s final disposition.


## Pinned Inputs

- checkpoint through Batch 04 SHA-256: `f980cf6e48001022bc2f8bfe716a7c385363e7adb4d5c967dd04a3c9e24fceac`
- Batch 05 proposal SHA-256: `b751820457447d58405865bc8b953148c2a24c911f063f6c1f07ac5ce9560e5e`
- Batch 04 attestation receipt SHA-256: `6f1f8804e08960ad1533955df381705226139f494c7c7400dab5875d30db1590`
