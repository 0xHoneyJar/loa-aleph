# SRC-001 Batch 04 Proposal Authority Receipt

> NONCANONICAL HUMAN-SUPERVISED DEVELOPMENT-CALIBRATION RECORD
>
> This receipt establishes the immutable Batch 04 proposal identity only. It
> is not a live Aleph run, canonical ledger, accepted fixture, replay,
> validation, sanction, independent audit, acceptance, or v1 evidence.

- recorded at: `2026-08-04T12:29:00+02:00`
- source: `SRC-001`
- batch: `04`
- authority: human
- proposal bytes: `7380`
- proposal SHA-256: `eaf54c5689e2f86330d1f5b9b4f56198ee558e9492491f06a8d5df88c30cd38a`
- digest verification: `PASS`
- SRC-001: `OPEN`
- SRC-002: `NOT AUTHORIZED`
- next candidate: `C-087`
- pending repair: `B3-001`

## Exact Human Statement

I identify the exact bytes of SRC-001-adjudication-batch-04-proposals.md with SHA-256 eaf54c5689e2f86330d1f5b9b4f56198ee558e9492491f06a8d5df88c30cd38a as the authoritative immutable Batch 04 proposal for this noncanonical SRC-001 calibration continuation. Preserve these bytes unchanged.
