# SRC-001 Human Decision Event — Batch 04D

> NONCANONICAL HUMAN-SUPERVISED EXTRACTION-CALIBRATION RECORD
>
> This event is not a live Aleph run, canonical ledger, accepted fixture,
> replay, validation, sanction, independent audit, acceptance, or v1 evidence.

- recorded at: `2026-08-04T17:33:00+02:00`
- source: `SRC-001`
- authority: human
- immutable inputs mutated: `false`
- SRC-001 closed: `false`
- SRC-002 started: `false`
- last original candidate adjudicated: `C-106`
- last fully dispositioned line: `L302`
- reviewed through: `L312`
- next source-order unresolved item: `G-017 / B4-002 at L313-L319`
- next original candidate: `C-107`
- open repairs: `B4-001`, `B4-002`

## Exact Human Decision Block

Adopt every decision in this block exactly as written

C-105 — edit. Retain the exact evidence at L300-L301 under criterion 3. Use the normalized wording: “For the CLEVR-from-pixels configuration introduced in C-101, the authors used mini-batches of size 64 and distributed training with 10 workers synchronously updating a central parameter server.” Record a dependency on C-101 for the task and model-configuration scope. Record no citation. Treat the batch size and distributed-training topology as one coherent training-regime unit. Record partial semantic overlap with future C-165 and reconcile the repeated batch-size and distributed-training details when C-165 is adjudicated without treating them as independent evidence.

C-106 — edit. Retain the exact evidence at L301-L302 under criterion 3. Use the normalized wording: “The authors state that the configurations for the other tasks are similar to the CLEVR-from-pixels configuration introduced in C-101.” Record a dependency on C-101 to supply the comparator for “similar.” Record no citation. Preserve “similar” without strengthening it to “the same,” “identical,” or similarity in every configuration detail. Retain “and can be found in the supplementary information” in the exact evidence but classify that clause as document navigation rather than part of the normalized technical claim.

G-016 — no-candidate status is not appropriate. Record L303-L304 as the first claim-bearing fragment of an architecture-simplicity comparison whose continuation follows Table 1. Record L305-L306 only as page-number and blank-line document administration. Record L307-L312 as the claim-bearing Table 1 header required to interpret the model rows, numeric values, and question-category metrics that continue in Batch 05. Preserve cross-batch repair B4-001 for reconciliation of L303-L304 with C-107 and cross-batch repair B4-002 for reconciliation of the Table 1 header with G-017 and C-108. Do not create standalone missing packets or assign final criteria, locators, normalized wording, table-packet granularity, or dispositions until the complete prose and table are reopened in Batch 05. Do not reconstruct a false contiguous frozen-text quote across the intervening page and table material.


## Pinned Inputs

- corrected checkpoint v2 ZIP SHA-256:
  `280231bef8b9e740a6959ac9e9b517ed067b3fc3882ebe5d94488b0006cd9041`
- checkpoint through Batch 03 ZIP SHA-256:
  `84f50e8f697c382dfc436e2cbb6f22d8b999e8207de22ff29db7d51d39b45d32`
- Batch 04 proposal SHA-256:
  `eaf54c5689e2f86330d1f5b9b4f56198ee558e9492491f06a8d5df88c30cd38a`
