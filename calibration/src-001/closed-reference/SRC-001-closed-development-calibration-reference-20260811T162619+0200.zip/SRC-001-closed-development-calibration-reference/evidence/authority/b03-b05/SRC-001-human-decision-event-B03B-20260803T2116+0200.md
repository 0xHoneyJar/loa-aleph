# SRC-001 Human Decision Event — Batch 03B

> NONCANONICAL APPEND-ONLY HUMAN DECISION EVENT
>
> This is not a live Aleph run, worker return, canonical packet ledger, accepted fixture, production execution, replay, validation, sanction, independent audit, acceptance, or v1.

- event ID: `SRC-001-HUMAN-DECISION-EVENT-B03B-20260803T2116+0200`
- authority: Eileen (human operator)
- authorization time: `2026-08-03T21:16+02:00`
- parent checkpoint preserved unchanged: `280231bef8b9e740a6959ac9e9b517ed067b3fc3882ebe5d94488b0006cd9041`
- predecessor decision event preserved unchanged: `ea67944af32e2c0a194b03905f9b0f29fc1b10f7bf097f57219f335abb5c5eb3`
- Batch 03 proposal preserved unchanged: `7fa12aa984252250e82d3ba3ca7cedb9374d53db3bcd42d99056347b342f8cc8`
- authoritative original-candidate decisions: `C-060` through `C-065`, plus `G-011`
- authoritative retained split units added: `C-065a`, `C-065b`
- next unreviewed candidate: `C-066` at `L185-L187`

## Verbatim Human Authorization

```text
Adopt every decision in this block exactly as written

C-060 — edit. Retain the exact evidence at L175-L177 under criterion 4. Use the normalized wording: “For Sort-of-CLEVR, the authors hard-coded questions as fixed-length binary strings to reduce the difficulty involved in natural-language question-word processing and thereby remove any confounding difficulty with language parsing.” Record a dependency on C-059 to preserve Sort-of-CLEVR scope. Record no citation. C-181 later provides the exact 11-bit encoding structure and is not a duplicate of this design-rationale claim.

C-061 — edit. Retain the exact evidence at L177-L178 under criterion 3. Use the normalized wording: “For each Sort-of-CLEVR image, the authors generated 10 relational questions and 10 non-relational questions.” Record a dependency on C-059 to resolve “each image.” Record no citation. Record that the same 10/10 balance recurs inside C-176; retain C-061 as the current atomic representative and reconcile the repeated C-176 fragment when C-176 is adjudicated, without treating the repetition as independent evidence.

C-062 — edit. Retain the exact evidence at L178-L179 under criterion 3. Use the normalized wording: “Examples of Sort-of-CLEVR relational questions are: ‘What is the shape of the object that is farthest from the gray object?’ and ‘How many objects have the same shape as the green object?’” Record a dependency on C-058 to preserve the Sort-of-CLEVR and relational-question scope. Record no citation. Record partial semantic overlap with C-179; C-179 contains a broader three-category taxonomy and is not wholly duplicative.

C-063 — edit. Retain the exact evidence at L179-L181 under criterion 3. Use the normalized wording: “Examples of Sort-of-CLEVR non-relational questions are: ‘What is the shape of the gray object?’ and ‘Is the blue object on the top or bottom of the scene?’” Record a dependency on C-058 to preserve the Sort-of-CLEVR and non-relational-question scope. Record no citation. Record partial semantic overlap with C-177; C-177 contains the broader three-category taxonomy and is not wholly duplicative.

C-064 — edit. Retain the exact evidence at L181-L182 under criterion 4. Use the normalized wording: “Sort-of-CLEVR is visually simple, reducing the complexities involved in image processing.” Record a dependency on C-059 to resolve “The dataset.” Record no citation.

G-011 — no packet appropriate. L183 is solely the “3.3 bAbI” section heading and is excluded as document-administration. Record no missing packet.

C-065 — too-broad. Replace it for calibration purposes with C-065a and C-065b.

C-065a — retain the exact evidence “bAbI is a pure text-based QA dataset [ 41].” at L184 under criterion 1. Use the normalized wording: “bAbI is a pure text-based question-answering dataset.” Record no dependency. Record citation [41] as scoped to C-065a.

C-065b — retain the exact evidence “There are 20 tasks, each corresponding to a particular
type of reasoning, such as deduction, induction, or counting.” at L184-L185 under criterion 1. Use the normalized wording: “bAbI contains 20 tasks, each corresponding to a particular type of reasoning, such as deduction, induction, or counting.” Record a dependency on C-065a to resolve the bAbI subject. Record no citation for C-065b.
```

## Structured Decision Summary

### C-060 — `edit`

- locator: `L175-L177`
- criterion: `4`
- dependencies: `C-059`
- normalized wording: For Sort-of-CLEVR, the authors hard-coded questions as fixed-length binary strings to reduce the difficulty involved in natural-language question-word processing and thereby remove any confounding difficulty with language parsing.

### C-061 — `edit`

- locator: `L177-L178`
- criterion: `3`
- dependencies: `C-059`
- normalized wording: For each Sort-of-CLEVR image, the authors generated 10 relational questions and 10 non-relational questions.

### C-062 — `edit`

- locator: `L178-L179`
- criterion: `3`
- dependencies: `C-058`
- normalized wording: Examples of Sort-of-CLEVR relational questions are: ‘What is the shape of the object that is farthest from the gray object?’ and ‘How many objects have the same shape as the green object?’

### C-063 — `edit`

- locator: `L179-L181`
- criterion: `3`
- dependencies: `C-058`
- normalized wording: Examples of Sort-of-CLEVR non-relational questions are: ‘What is the shape of the gray object?’ and ‘Is the blue object on the top or bottom of the scene?’

### C-064 — `edit`

- locator: `L181-L182`
- criterion: `4`
- dependencies: `C-059`
- normalized wording: Sort-of-CLEVR is visually simple, reducing the complexities involved in image processing.

### C-065 — `too-broad`

- locator: `L184-L185`
- C-065a: criterion `1`; dependencies `none`; normalized wording: bAbI is a pure text-based question-answering dataset.
- C-065b: criterion `1`; dependencies `C-065a`; normalized wording: bAbI contains 20 tasks, each corresponding to a particular type of reasoning, such as deduction, induction, or counting.

### G-011 — `no packet appropriate`

- locator: `L183`
- exclusion: section heading; document administration
- missing packet: `none`

## Status

- SRC-001: `OPEN_FOR_HUMAN_ADJUDICATION`
- SRC-002: `NOT AUTHORIZED`
- corrected checkpoint v2 exact-byte attestation: `PENDING HUMAN HASH ATTESTATION`
