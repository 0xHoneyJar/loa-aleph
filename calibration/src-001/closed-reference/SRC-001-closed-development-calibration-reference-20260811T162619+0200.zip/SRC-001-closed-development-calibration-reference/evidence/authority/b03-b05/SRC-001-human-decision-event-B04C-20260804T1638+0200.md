# SRC-001 Human Decision Event — Batch 04C

> NONCANONICAL HUMAN-SUPERVISED EXTRACTION-CALIBRATION RECORD
>
> This event is not a live Aleph run, canonical ledger, accepted fixture,
> replay, validation, sanction, independent audit, acceptance, or v1 evidence.

- recorded at: `2026-08-04T16:38:00+02:00`
- source: `SRC-001`
- authority: human
- scope: decisions named in the exact block below only
- immutable inputs mutated: `false`
- SRC-001 closed: `false`
- SRC-002 started: `false`
- next candidate: `C-105`
- next locator: `L300-L302`

## Exact Human Decision Block

Adopt every decision in this block exactly as written

C-099 — edit. Retain the exact evidence at L290-L291 under criterion 3, including the frozen degraded spelling “appened.” Use the normalized wording: “For the bAbI setup introduced in C-094, and similarly to the visual-QA question path described in C-091, an LSTM separate from the sentence-processing LSTM in C-098 produced a question embedding, which was appended to each object pair as input to the RN.” Record dependencies on C-094 for bAbI scope, C-098 to resolve what the LSTM is separate from, and C-091 for the visual-QA comparison. Record no citation. Record a degradation flag that the frozen evidence reads “appened” while the exact PDF reads “appended”; do not alter the exact evidence.

C-100 — edit. Retain the exact evidence at L291-L293 under criterion 3. Use the normalized wording: “The bAbI RN model described through C-095 and C-099 was trained on the joint version of bAbI—all 20 tasks simultaneously—using the full dataset of 10K examples per task.” Record dependencies on C-095 and C-099 to resolve “Our model.” Record no citation. Record partial semantic overlap with C-069’s joint-training and 10K-examples-per-task condition, but retain C-100 as the authors’ model-training specification and do not count the repeated condition as independent empirical evidence.

C-101 — calibration-accept. Retain the exact evidence at L294-L296 under criterion 3, including the inline “Model configuration details” text. Use the normalized wording: “For the CLEVR-from-pixels task, the authors used four convolutional layers, each with 24 kernels, ReLU nonlinearities, and batch normalization; a 128-unit LSTM for question processing; and 32-unit word-lookup embeddings.” Record no dependency or citation. Classify “Model configuration details” as subsection scope rather than an independent assertion. Record C-101 as the explicit CLEVR-from-pixels configuration anchor for C-102 through C-105.

C-102 — edit. Retain the exact evidence at L296-L297 under criterion 3. Use the normalized wording: “For the CLEVR-from-pixels configuration introduced in C-101, gθ, as defined in C-029, was a four-layer MLP with 256 units per layer and ReLU nonlinearities.” Record dependencies on C-101 for task scope and C-029 for the architectural meaning of gθ. Record no citation. Preserve the four-layer count, 256 units per layer, and ReLU nonlinearities.

C-103 — edit. Retain the exact evidence at L297-L298 under criterion 3. Use the normalized wording: “For the CLEVR-from-pixels configuration introduced in C-101, fφ, as defined in C-029, was a three-layer MLP with layers of 256 units, 256 units with 50% dropout, and 29 units, using ReLU nonlinearities.” Record dependencies on C-101 for task scope and C-029 for the architectural meaning of fφ. Record no citation. Preserve the ordered layer dimensions and record the 50% dropout as attached to the second 256-unit layer.

C-104 — too-broad. Replace it for calibration purposes with C-104a and C-104b.

C-104a — retain the exact evidence “The final layer was a linear layer that produced logits
for a softmax over the answer vocabulary.” at L298-L299 under criterion 3. Use the normalized wording: “In the CLEVR-from-pixels configuration introduced in C-101 and continued through C-103, the final layer was linear and produced logits for a softmax over the answer vocabulary.” Record dependencies on C-101 for task scope and C-103 for the preceding configuration context. Record no citation.

C-104b — retain the exact evidence “The softmax output was optimized with a cross-entropy
loss function using the Adam optimizer with a learning rate of 2 .5e−4.” at L299-L300 under criterion 3. Use the normalized wording: “The softmax output defined in C-104a was optimized with a cross-entropy loss function using the Adam optimizer with a learning rate of 2.5e−4.” Record dependencies on C-101 for CLEVR-from-pixels scope and C-104a to resolve “The softmax output.” Record no citation. Record a formal-material flag that the frozen evidence reads “2 .5e−4” while the exact PDF reads “2.5e−4”; do not alter the exact evidence.


## Pinned Inputs

- corrected checkpoint v2 ZIP SHA-256: `280231bef8b9e740a6959ac9e9b517ed067b3fc3882ebe5d94488b0006cd9041`
- checkpoint through Batch 03 ZIP SHA-256: `84f50e8f697c382dfc436e2cbb6f22d8b999e8207de22ff29db7d51d39b45d32`
- Batch 04 proposal SHA-256: `eaf54c5689e2f86330d1f5b9b4f56198ee558e9492491f06a8d5df88c30cd38a`
