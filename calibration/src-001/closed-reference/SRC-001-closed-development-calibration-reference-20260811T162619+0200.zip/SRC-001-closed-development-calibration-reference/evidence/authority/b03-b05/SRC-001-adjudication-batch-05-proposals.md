# SRC-001 Adjudication: Batch 05 Proposals

> NONCANONICAL MODEL-ASSISTED DEVELOPMENT-CALIBRATION EVIDENCE
>
> These recommendations do not replace open human dispositions and are not
> Loa-Aleph run evidence.

## Batch Identity

| field | exact value |
|---|---|
| review block | `L313-L390` |
| candidate rows | `C-107` through `C-119` |
| no-candidate rows | `G-017` through `G-020` |
| frozen source SHA-256 | `5aef61988ff0db6f2ecc2b7980f370583a317e2427c85a6f78adc3ccc8a1d22a` |
| criteria SHA-256 | `1df51f9872895a3a87a9face2bafe50db34cdfbfd73826e2a31f531c4c538df8` |
| source reopened | frozen text `L313-L390`; exact PDF pages 7-8 |
| criteria changes applied | none |

The complete Table 1 and Figure 3 were checked in the hash-matched PDF. Each
candidate locator and quote was reopened in the frozen text.

## Candidate Recommendations

| ID | stated criterion satisfied | proposed disposition | reason | replacement, split, or dependency |
|---|---|---|---|---|
| C-107 | yes, criterion 3 | `edit` | The footnote states a substantive implementation/training condition, but `Our implementation` is uninterpretable without the starred CNN+LSTM+SA row at L318. | Retain the quote and record a dependency on missing table packet T1-006. |
| C-108 | yes, criterion 5 | `calibration-accept` | It supplies the comparison scope, test-set accuracy metric, and per-question-category breakdown needed to interpret Table 1. | Treat it as shared context for T1-001 through T1-007. |
| C-109 | yes, criterion 5 | `calibration-accept` | It preserves the 95.5% result, pixel-and-question-only condition, 27% comparison, human comparison, and table/figure evidence basis. | none |
| C-110 | yes, criterion 4 | `calibration-accept` | It links the compare-attribute and count results to the claimed relational-reasoning ability. | none |
| C-111 | yes, criterion 5 | `too-narrow` | `these categories` has no referent inside the quote; it means compare attribute and count from C-110. | `L330-L332`, criterion 5: `"These results – in particular, those obtained in the compare attribute and count categories –\nare a testament to the ability of our model to do relational reasoning. In fact, it is in these categories\nthat state-of-the-art models struggle most."` |
| C-112 | yes, criterion 4 | `calibration-accept` | It links relative component simplicity to the hypothesis that CLEVR difficulty comes from relational demands rather than language or visual processing. | none |
| C-113 | yes, criterion 5 | `calibration-accept` | It preserves the 96.9% result and the additional functional-program supervision condition. | none |
| C-114 | yes, criterion 6 | `edit` | The direct-comparison limitation is valid, but `this` refers to C-113's privileged-supervision result. | Retain the quote and record a dependency on C-113. |
| C-115 | yes, criterion 5 | `edit` | The comparison is valid, but `their model` and `extra signals` depend on the study and supervision described in C-113. | Retain the quote and record a dependency on C-113. |
| C-116 | yes, criterion 5 | `edit` | The conclusion preserves weaker assumptions and unavailable-program conditions, but its evidence basis is the comparisons in C-113 through C-115. | Retain the quote and record dependencies on C-113 through C-115. |
| C-117 | yes, criterion 5 | `calibration-accept` | It preserves the state-description input condition, robustness purpose, and 96.4% result. | none |
| C-118 | yes, criterion 4 | `edit` | The interpretation is valid, but `This result` must remain tied to C-117's state-description experiment and metric. | Retain the quote and record a dependency on C-117. |
| C-119 | yes, criterion 4 | `edit` | The cross-context conclusion is valid, but `Therefore` depends on C-117 and C-118. | Retain the quote and record dependencies on C-117 and C-118. |

Proposed disposition counts: `calibration-accept=6`, `edit=6`,
`too-narrow=1`, and `reject=too-broad=duplicate=exclude=uncertain=0`.

## No-Candidate Recommendations

| review ID | proposed decision | exclusion reason or defect | missing-packet decision |
|---|---|---|---|
| G-017 (`L313-L319`) | no-candidate status is not appropriate | These are seven complete numeric rows in Table 1. The extracted header at L307-L312 and C-108 caption make every row interpretable. | Add T1-001 through T1-007 below. |
| G-018 (`L323-L326`) | no-candidate status is not fully appropriate | `L323-L324` completes the architecture-simplicity comparison begun at L303-L304. `L325-L326` is section administration. | Add M-002 below; exclude only `L325-L326` as headings. |
| G-019 (`L343`) | no packet appropriate | `5.2 CLEVR from state descriptions` is a section heading (`document-administration`). | none |
| G-020 (`L351-L390`) | no standalone packet appropriate | `L351-L352` is page administration. `L353-L390` contains Figure 3 axes, category labels, model legend, and tick labels, but no exact result values or independent prose assertion. The PDF-confirmed claims are carried by C-109 through C-112 and the claim-bearing Figure 3 caption at C-120. | Exclude `L351-L352` as document-administration and `L353-L390` as figure labels without an independent assertion; do not infer numeric bar values. |

## Missing Table 1 Packets

Shared context from `L307-L312` and C-108:

`Model | Overall | Count | Exist | Compare Numbers | Query Attribute | Compare Attribute`;
accuracy on the CLEVR-from-pixels test set.

| proposal ID | exact source row | proposed criterion | required dependency |
|---|---|---:|---|
| T1-001 | `L313`: `"Human 92.6 86.7 96.6 86.5 95.0 96.0"` | 5 | header plus C-108 |
| T1-002 | `L314`: `"Q-type baseline 41.8 34.6 50.2 51.0 36.0 51.3"` | 5 | header plus C-108 |
| T1-003 | `L315`: `"LSTM 46.8 41.7 61.1 69.8 36.8 51.8"` | 5 | header plus C-108 |
| T1-004 | `L316`: `"CNN+LSTM 52.3 43.7 65.2 67.1 49.3 53.0"` | 5 | header plus C-108 |
| T1-005 | `L317`: `"CNN+LSTM+SA 68.5 52.2 71.1 73.5 85.3 52.3"` | 5 | header plus C-108 |
| T1-006 | `L318`: `"CNN+LSTM+SA* 76.6 64.4 82.7 77.4 82.6 75.4"` | 5 | header, C-108, and C-107 footnote |
| T1-007 | `L319`: `"CNN+LSTM+RN 95.5 90.1 97.8 93.6 97.9 97.1"` | 5 | header plus C-108 |

The rows remain separate because each model reports an independent empirical
result. Importance is judged later under the unchanged criteria.

## Missing Prose Packet M-002

The exact PDF shows one sentence interrupted in frozen extraction order by
Table 1:

- fragment 1, `L303-L304`: `"We’d like to emphasize the simplicity of our overall model architecture compared to the visual\nQA architectures used on CLEVR thus far, which use ResNet or VGG embeddings, sometimes with"`
- fragment 2, `L323-L324`: `"ﬁne-tuning, very large LSTMs for language encoding, and further processing modules, such as stacked\nor iterative attention, or large fully connected layers (upwards of 4000 units, often) [15]."`
- proposed criterion: `6`
- preserved comparison: the authors' overall model versus prior CLEVR visual-QA
  architectures; ResNet/VGG embeddings, fine-tuning, large language LSTMs,
  stacked/iterative attention, and often-4000-plus-unit fully connected layers.
- unresolved representation: use the same formal-material interruption rule
  eventually chosen for M-001 and E-001; do not fabricate a contiguous frozen
  quote.

## Provisional Criteria Observations

1. Table rows become interpretable through shared headers and captions, but the
   unchanged criteria do not specify whether those dependencies must be copied
   into every packet or represented as explicit links.
2. No criteria change or supersession was applied.

## Human Gate

No handoff row has been changed. A human must explicitly adopt, revise, or
reject these recommendations. SRC-001 remains open, and SRC-002 must not begin.
