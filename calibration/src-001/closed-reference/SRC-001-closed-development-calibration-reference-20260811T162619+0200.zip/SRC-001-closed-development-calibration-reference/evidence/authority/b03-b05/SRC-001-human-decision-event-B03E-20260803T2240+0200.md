# SRC-001 Human Decision Event — Batch 03E

> NONCANONICAL HUMAN-SUPERVISED EXTRACTION-CALIBRATION RECORD
>
> This event is not a live Aleph run, canonical ledger, accepted fixture,
> replay, validation, sanction, independent audit, acceptance, or v1 evidence.

- recorded at: `2026-08-03T22:40:00+02:00`
- source: `SRC-001`
- authority: human
- scope: decisions named in the exact block below only
- immutable inputs mutated: `false`
- SRC-001 closed: `false`
- SRC-002 started: `false`
- next candidate: `C-084`
- next locator: `L228-L229`

## Exact Human Decision Block

Adopt every decision in this block exactly as written

C-078 — edit. Retain the exact evidence at L215-L216 under criterion 6. Use the normalized wording: “The connection-inference task defined in C-075a makes the inferences described in C-076 explicit, whereas the system-counting task defined in C-075b requires that reasoning to occur implicitly, which the authors state is much more difficult.” Record dependencies on C-075a, C-075b, and C-076. Preserve “much more difficult” as a relative comparison between implicit and explicit reasoning. Record no citation.

G-013 — no packet appropriate. L217-L218 contains only a supplementary-information navigation sentence and the “4 Models” section heading. Exclude both as document-administration and record no missing packet.

C-079 — calibration-accept. Retain the exact evidence at L219-L220 under criterion 2. Use the normalized wording: “In their simplest form, RNs operate on objects and therefore do not explicitly operate on images or natural language.” Record no dependency or citation. Record partial overlap with C-029’s formal object-set input definition, but retain C-079 as distinct because it states the image-and-language input boundary. Do not treat the repeated object-input proposition as independent evidence.

C-080 — calibration-accept. Retain the exact evidence at L220-L222 under criterion 2. Use the normalized wording: “The authors identify as a central contribution the demonstrated flexibility with which relatively unstructured inputs, such as CNN or LSTM embeddings, can be considered a set of objects for an RN.” Record no dependency or citation. Preserve “central contribution,” “relatively unstructured,” and “can be considered.” Record partial semantic overlap with future C-149 and reconcile that overlap when C-149 is adjudicated without treating repetition as independent evidence.

C-081 — calibration-accept. Retain the exact evidence at L222-L223 under criterion 6. Use the normalized wording: “Although an RN expects object representations as input, the semantics of what constitutes an object need not be specified.” Record no dependency or citation. Preserve “need not be specified” without strengthening it into a prohibition or a claim that object semantics do not exist.

C-082 — calibration-accept. Retain the exact evidence at L223-L225 under criterion 4. Use the normalized wording: “The authors state that their subsequent results demonstrate that learning induces upstream processing by conventional neural-network modules to produce a set of useful ‘objects’ from distributed representations.” Record no claim dependency or citation at this stage. Preserve the forward evidence attribution to subsequent results and require mapping to exact retained result units during the later whole-source evidence consistency pass. Record partial semantic overlap with authoritative C-019. Record C-082 as the prospective representative for future C-140, subject to C-140’s separate human adjudication; do not treat overlapping repetitions as independent evidence.

C-083 — calibration-accept. Retain the exact evidence at L226-L228 under criterion 3, including the inline “Dealing with pixels” subsection heading. Use the normalized wording: “For pixel inputs, the authors used a CNN to parse the inputs into a set of objects. The CNN took 128×128 images and convolved them through four convolutional layers into k feature maps of size d×d, where k is the number of kernels in the final convolutional layer.” Record no dependency or citation. Classify “Dealing with pixels” as subsection scope rather than an independent assertion. Keep C-083 separate from C-085’s later feature-map-cell-to-object construction.


## Pinned Inputs

- corrected checkpoint v2 ZIP SHA-256: `280231bef8b9e740a6959ac9e9b517ed067b3fc3882ebe5d94488b0006cd9041`
- Batch 03 proposal SHA-256: `7fa12aa984252250e82d3ba3ca7cedb9374d53db3bcd42d99056347b342f8cc8`
