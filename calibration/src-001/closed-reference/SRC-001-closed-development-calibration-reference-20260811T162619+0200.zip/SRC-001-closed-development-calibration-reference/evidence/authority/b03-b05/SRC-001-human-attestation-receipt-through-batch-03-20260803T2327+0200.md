# SRC-001 Human Exact-Byte Attestation Receipt — Through Batch 03

> NONCANONICAL HUMAN-SUPERVISED DEVELOPMENT-CALIBRATION RECORD
>
> This receipt records explicit human attestation only. It is not a live Aleph
> run, canonical ledger, accepted fixture, replay, validation, sanction,
> independent audit, acceptance, or v1 evidence.

- recorded at: `2026-08-03T23:27:00+02:00`
- source: `SRC-001`
- authority: human
- corrected checkpoint v2 attestation: `CLOSED`
- checkpoint through Batch 03 attestation: `CLOSED`
- SRC-001: `OPEN`
- SRC-002: `NOT AUTHORIZED`

## Exact Human Attestation

I attest the exact bytes of corrected checkpoint v2 with SHA-256 280231bef8b9e740a6959ac9e9b517ed067b3fc3882ebe5d94488b0006cd9041. Preserve checkpoint v1, the internal audit, v2, and all immutable inputs unchanged.

I attest the exact bytes of the SRC-001 checkpoint through Batch 03 with SHA-256 84f50e8f697c382dfc436e2cbb6f22d8b999e8207de22ff29db7d51d39b45d32. Preserve corrected checkpoint v2, the exact Batch 03 proposal, all Batch 03 human decision events, this checkpoint, and all immutable inputs unchanged.


## Reverified Digests

- corrected checkpoint v2 ZIP:
  `280231bef8b9e740a6959ac9e9b517ed067b3fc3882ebe5d94488b0006cd9041` — PASS
- checkpoint through Batch 03 ZIP:
  `84f50e8f697c382dfc436e2cbb6f22d8b999e8207de22ff29db7d51d39b45d32` — PASS
- Batch 03 proposal:
  `7fa12aa984252250e82d3ba3ca7cedb9374d53db3bcd42d99056347b342f8cc8` — PASS

## Remaining Open Findings

1. The exact Batch 02 proposal bytes still require independent hashing against
   `11ec5faf437ae50b973b409baa62d3a64a6402935cf0b071d0a9435da199bfc3`
   before that audit finding can be closed additively.
2. The 19 mechanical-only normalizations still require dedicated human review
   before becoming golden examples.
3. Cross-batch repair `B3-001` remains pending reconciliation with `C-087`.

## Resume Boundary

- next candidate: `C-087`
- required reopened source: `L234-L236`
- next proposal file: `SRC-001-adjudication-batch-04-proposals.md`
- expected Batch 04 SHA-256: not present in active authoritative files; do not guess
