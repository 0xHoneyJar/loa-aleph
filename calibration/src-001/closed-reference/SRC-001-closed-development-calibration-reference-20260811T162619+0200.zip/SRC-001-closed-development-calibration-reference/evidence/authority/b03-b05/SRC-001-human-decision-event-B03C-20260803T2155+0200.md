# SRC-001 Human Decision Event — Batch 03C

> NONCANONICAL HUMAN-SUPERVISED EXTRACTION-CALIBRATION RECORD
>
> This event is not a live Aleph run, canonical ledger, accepted fixture,
> replay, validation, sanction, independent audit, acceptance, or v1 evidence.

- recorded at: `2026-08-03T21:55:00+02:00`
- source: `SRC-001`
- authority: human
- scope: decisions named in the exact block below only
- immutable inputs mutated: `false`
- SRC-001 closed: `false`
- SRC-002 started: `false`
- next candidate: `C-072`
- next locator: `L199-L200`

## Exact Human Decision Block

Adopt every decision in this block exactly as written

C-066 — edit. Retain the exact evidence at L185-L187 under criterion 1. Use the normalized wording: “In bAbI, each question is associated with a set of supporting facts. For example, ‘Sandra picked up the football’ and ‘Sandra went to the office’ support the question ‘Where is the football?’ with the answer ‘office.’” Record a dependency on C-065a to resolve the bAbI referent. Record no citation; citation [41] remains scoped to C-065a.

C-067 — edit. Retain the exact evidence at L187-L188 under criterion 5. Use the normalized wording: “On bAbI, a model succeeds on a task if its performance surpasses 95%.” Record a dependency on C-065b to preserve the bAbI 20-task-suite scope. Preserve “surpasses 95%” as a strict greater-than threshold. Record no citation.

C-068 — duplicate. Preserve the exact evidence at L188-L189 in the decision record under criterion 5, but do not retain it as independent evidence. Record C-069 as the evidence-bearing representative. Record that this is a semantic summary duplicate rather than an exact-quote duplicate, and do not import C-068’s evaluative word “impressive” into C-069.

C-069 — edit. Retain the exact evidence at L189-L192 under criterion 5. Use the normalized wording: “On bAbI, when trained jointly on all 20 tasks using 10K examples per task, Memory Networks passed 14/20 tasks, DNC 18/20, Sparse DNC 19/20, and EntNet 16/20. The EntNet authors reported state-of-the-art performance at 20/20, but unlike the preceding results, that result did not use joint training on all tasks; with joint training, EntNet achieved 16/20 [42, 9, 34, 13].” Record dependencies on C-065b for the bAbI 20-task-suite scope and C-067 for the task-pass threshold. Record citations [42, 9, 34, 13] as scoped to the complete comparison. Preserve the EntNet non-joint-training caveat as load-bearing.

C-070 — exclude. Preserve the exact evidence at L193 in the exclusion record. Record no criterion, dependency, or citation. Classify it as a future dataset-availability notice outside candidacy, not as a criterion-7 research direction. Record no missing packet. Preserve its footnote relationship to the Sort-of-CLEVR name handled at C-058.

G-012 — no packet appropriate. L194-L196 contains only page number 4, a blank line, and the “3.4 Dynamic physical systems” section heading. Exclude the range as document-administration and record no missing packet.

C-071 — calibration-accept. Retain the exact evidence at L197-L199 under criterion 3. Use the normalized wording: “The authors developed a dataset of simulated physical mass-spring systems using the MuJoCo physics engine. Each scene contained 10 colored balls moving on a tabletop surface; some balls moved independently and could collide with other balls and the barrier walls.” Record no dependency. Record citation [40] as scoped to the MuJoCo physics-engine reference. Keep the unit separate from C-072’s connected-ball mechanism.


## Pinned Inputs

- corrected checkpoint v2 ZIP SHA-256: `280231bef8b9e740a6959ac9e9b517ed067b3fc3882ebe5d94488b0006cd9041`
- Batch 03 proposal SHA-256: `7fa12aa984252250e82d3ba3ca7cedb9374d53db3bcd42d99056347b342f8cc8`
