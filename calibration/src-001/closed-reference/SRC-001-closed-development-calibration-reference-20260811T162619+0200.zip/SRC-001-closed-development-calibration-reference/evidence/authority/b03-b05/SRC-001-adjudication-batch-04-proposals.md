# SRC-001 Adjudication: Batch 04 Proposals

> NONCANONICAL MODEL-ASSISTED DEVELOPMENT-CALIBRATION EVIDENCE
>
> These recommendations do not replace open human dispositions and are not
> Loa-Aleph run evidence.

## Batch Identity

| field | exact value |
|---|---|
| review block | `L235-L312` |
| candidate rows | `C-087` through `C-106` |
| no-candidate rows | `G-015` and `G-016` |
| frozen source SHA-256 | `5aef61988ff0db6f2ecc2b7980f370583a317e2427c85a6f78adc3ccc8a1d22a` |
| criteria SHA-256 | `1df51f9872895a3a87a9face2bafe50db34cdfbfd73826e2a31f531c4c538df8` |
| source reopened | frozen text `L235-L312`; exact PDF pages 5-7 |
| criteria changes applied | none |

Each handoff locator and quote was reopened in the frozen text. Figure 2,
Equation 2, the model-configuration paragraph, and the start of Table 1 were
checked in the hash-matched PDF.

## Candidate Recommendations

| ID | stated criterion satisfied | proposed disposition | reason | replacement, split, or dependency |
|---|---|---|---|---|
| C-087 | yes, criterion 4 | `too-narrow` | The quote starts with `relation` and omits the subject begun at L234, so it loses what should be question dependent. | `L234-L236`, criterion 4: `"The existence and meaning of an object-object\nrelation should be question dependent. For example, if a question asks about a large sphere, then\nthe relations between small cubes are probably irrelevant."` This resolves batch 03 repair B3-001. |
| C-088 | yes, criterion 3 | `calibration-accept` | It records the question-conditioned RN modification and its exact composite function. The PDF confirms the equation. | none |
| C-089 | yes, criterion 3 | `calibration-accept` | It records the LSTM final-state question embedding, integer word identifiers, and learnable lookup embeddings. | none |
| C-090 | yes, criterion 3 | `calibration-accept` | It records the per-time-step word-embedding input and English-question sequence condition. | none |
| C-091 | yes, criterion 2 | `calibration-accept` | The PDF confirms the caption's LSTM question path, CNN object path, and feature-map-vector object construction. | none |
| C-092 | yes, criterion 2 | `calibration-accept` | It preserves all-pairs relation processing, question conditioning, relation integration, and answer purpose. | none |
| C-093 | yes, criterion 3 | `calibration-accept` | It records direct state-description input and the complete LSTM/lookup/object-pair conditioning path. | none |
| C-094 | yes, criterion 2 | `calibration-accept` | It states the bAbI transformation requirement and contrasts sentence objects with spatial feature-map objects in visual QA. | none |
| C-095 | yes, criterion 3 | `calibration-accept` | It preserves the 20-sentence limit, temporal selection, relative-position tags, word-wise processing, and shared independent LSTM. | none |
| C-096 | yes, criterion 6 | `calibration-accept` | It states the sentence-delineation prior and the exact contrast with prior token-sequential bAbI models. | none |
| C-097 | yes, criterion 6 | `calibration-accept` | It preserves the authors' uncertainty and the reason that punctuation may erase the purported advantage. | none |
| C-098 | yes, criterion 2 | `calibration-accept` | It defines the sentence-processing LSTM final state as an object. | none |
| C-099 | yes, criterion 3 | `calibration-accept` | It records the separate question LSTM and object-pair conditioning. Preserve the frozen-source spelling `appened`; the PDF reads `appended`, so this is flagged as degraded extraction rather than silently repaired. | none |
| C-100 | yes, criterion 3 | `calibration-accept` | It preserves joint training over all 20 bAbI tasks and 10K examples per task. | none |
| C-101 | yes, criterion 3 | `calibration-accept` | It anchors the configuration to CLEVR-from-pixels and records convolutional, LSTM, and word-embedding dimensions and activations. | none |
| C-102 | yes, criterion 3 | `edit` | The component detail is valid, but its CLEVR-from-pixels scope exists only in C-101's list introduction. | Retain the quote and record an explicit dependency on C-101 for task scope. |
| C-103 | yes, criterion 3 | `edit` | The `fφ` dimensions, dropout, and activation are valid, but the task scope exists only in C-101. | Retain the quote and record an explicit dependency on C-101 for task scope. |
| C-104 | yes, criterion 3 | `edit` | The output, loss, optimizer, and learning-rate details are valid, but the task scope exists only in C-101. | Retain the quote and record an explicit dependency on C-101 for task scope. |
| C-105 | yes, criterion 3 | `edit` | The batch size and distributed-training topology are valid, but the task scope exists only in C-101. | Retain the quote and record an explicit dependency on C-101 for task scope. |
| C-106 | yes, criterion 3 | `calibration-accept` | It asserts that other-task configurations are similar and identifies where their details reside; the similarity claim is substantive even though the pointer is administrative. | none |

Proposed disposition counts: `calibration-accept=15`, `edit=4`,
`too-narrow=1`, and `reject=too-broad=duplicate=exclude=uncertain=0`.

## No-Candidate Recommendations

| review ID | proposed decision | exclusion reason or defect | missing-packet decision |
|---|---|---|---|
| G-015 (`L243-L270`) | no packet appropriate | `L243-L244` is page administration. `L245-L270` is Figure 2's diagram labels, example question, and operators. The exact PDF shows no independent assertion beyond C-088's equation and C-091/C-092's claim-bearing caption. | none |
| G-016 (`L303-L312`) | no-candidate status is not appropriate | `L303-L304` begins a substantive model-simplicity comparison that resumes after the page/table interruption. `L305-L306` is page administration. `L307-L312` is the header of the substantive Table 1. | Reconcile the prose with C-107 and the table header with G-017/C-108 in batch 05. |

## Cross-Batch Repairs

### B4-001: model-simplicity comparison

- fragment 1, `L303-L304`: `"We’d like to emphasize the simplicity of our overall model architecture compared to the visual\nQA architectures used on CLEVR thus far, which use ResNet or VGG embeddings, sometimes with"`
- continuation: begins at `L320` after Table 1.
- status: substantive claim; no-candidate exclusion is invalid. Resolve against
  C-107 in batch 05 without reconstructing a false contiguous frozen-text quote.

### B4-002: Table 1

- `L307-L312` supplies the table header; model rows, numeric results, footnote,
  and caption continue at `L313-L322`.
- PDF check: the table reports accuracy for Human, Q-type baseline, LSTM,
  CNN+LSTM, two CNN+LSTM+SA variants, and CNN+LSTM+RN across Overall, Count,
  Exist, Compare Numbers, Query Attribute, and Compare Attribute.
- status: formal material is claim-bearing when paired with its rows and
  caption. Resolve exact packet granularity in batch 05; do not exclude the
  header as an uninterpreted fragment.

## Provisional Criteria Observations

1. The unchanged criteria do not prescribe a canonical representation for a
   prose sentence interrupted in extraction order by a page-spanning table.
2. No criteria change or supersession was applied.

## Human Gate

No handoff row has been changed. A human must explicitly adopt, revise, or
reject these recommendations. SRC-001 remains open, and SRC-002 must not begin.
