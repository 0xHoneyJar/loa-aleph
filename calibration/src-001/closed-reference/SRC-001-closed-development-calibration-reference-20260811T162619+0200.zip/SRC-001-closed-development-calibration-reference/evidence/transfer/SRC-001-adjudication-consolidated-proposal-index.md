# SRC-001 Adjudication: Consolidated Proposal Index

> NONCANONICAL MODEL-ASSISTED DEVELOPMENT-CALIBRATION EVIDENCE
>
> This index and the twelve referenced batches are recommendations only. They
> are not a Loa-Aleph run, worker return, packet ledger, validation, sanction,
> acceptance record, human disposition, or SRC-001 close decision.

## Authority State

- source: `SRC-001` only
- source SHA-256:
  `5aef61988ff0db6f2ecc2b7980f370583a317e2427c85a6f78adc3ccc8a1d22a`
- source extent: `54207` bytes; `L1-L792`
- criteria SHA-256:
  `1df51f9872895a3a87a9face2bafe50db34cdfbfd73826e2a31f531c4c538df8`
- review-index SHA-256:
  `81764a109ce30e92b4661506d8f18a96a17ed81b309fcf614da993461f2783ca`
- PDF SHA-256:
  `c115123a511418ab46f04c4f9f78b6a569712960dbe9ca596d4edd6f0686d521`
- criteria changes applied: none
- handoff human fields: all remain `OPEN`
- SRC-001 human close decision: `OPEN`
- SRC-002: not begun

## Batch Index

| batch | source block | candidates | gap rows | file SHA-256 |
|---|---|---|---|---|
| 01 | `L1-L78` | `C-001`-`C-025` | `G-001`-`G-004` | `c1d088e0bd1dda89da04533a628bdca4b4dd610db694e9198361939fa7a8b868` |
| 02 | `L79-L156` | `C-026`-`C-053` | `G-005`-`G-009` | `11ec5faf437ae50b973b409baa62d3a64a6402935cf0b071d0a9435da199bfc3` |
| 03 | `L157-L234` | `C-054`-`C-086` | `G-010`-`G-014` | `7fa12aa984252250e82d3ba3ca7cedb9374d53db3bcd42d99056347b342f8cc8` |
| 04 | `L235-L312` | `C-087`-`C-106` | `G-015`-`G-016` | `eaf54c5689e2f86330d1f5b9b4f56198ee558e9492491f06a8d5df88c30cd38a` |
| 05 | `L313-L390` | `C-107`-`C-119` | `G-017`-`G-020` | `b751820457447d58405865bc8b953148c2a24c911f063f6c1f07ac5ce9560e5e` |
| 06 | `L391-L468` | `C-120`-`C-145` | `G-021`-`G-026` | `aa4e5c94d4e540eb85c558ac5497c68e8799783dff633d0bd253016389bfd315` |
| 07 | `L469-L518` | `C-146`-`C-162` | `G-027`-`G-032` | `23e23b089c032bd1269b248fefb9663799d4d0792762db83caa8b7ccb3f490d6` |
| 08 | `L519-L568` | `C-163`-`C-183` | `G-033`-`G-036` | `420934551436cbf1956f88937b91deb80960355dd6a9ffd8c81a3434ce2b54c7` |
| 09 | `L569-L618` | `C-184`-`C-204` | `G-037`-`G-039` | `15f7870a120aebacbbe696ec11553cf522feaee3f9e1f96014001949dd3f0754` |
| 10 | `L619-L668` | `C-205`-`C-206` | `G-040`-`G-041` | `b7551e6d65f8a881f0fa6b0192ebae7b7df03fc188451195c4c75e4a46acd282` |
| 11 | `L669-L688` | none | `G-042` | `59edbbb65d55bc1779b1943c2170a10ef64a3156f63bc5f3e55a4832f875cc37` |
| 12 | `L689-L792` | none | `G-043` | `4d9a2004026edb465b3c748822959b1cffb93c118459ed5f5ff4e3f55b1cafe7` |

Every batch records that its source lines and corresponding handoff entries
were reopened and that no criteria change was applied. Candidate-level reasons
and exact repairs are in each batch's `Candidate Recommendations` table.

## Candidate Proposal Index

The following sets explicitly partition `C-001` through `C-206`. These are
model recommendations, not human dispositions.

| proposed disposition | count | candidate IDs |
|---|---:|---|
| `edit` | 42 | `C-026`, `C-049`, `C-102`-`C-105`, `C-107`, `C-114`-`C-116`, `C-118`-`C-119`, `C-124`, `C-130`, `C-132`-`C-133`, `C-136`, `C-146`, `C-162`, `C-164`-`C-166`, `C-168`-`C-169`, `C-173`-`C-175`, `C-178`, `C-180`, `C-182`-`C-185`, `C-187`-`C-188`, `C-193`, `C-195`-`C-196`, `C-201`-`C-204` |
| `too-narrow` | 10 | `C-002`, `C-021`, `C-030`, `C-031`, `C-039`, `C-045`, `C-087`, `C-111`, `C-131`, `C-191` |
| `too-broad` | 4 | `C-142`, `C-167`, `C-190`, `C-192` |
| `duplicate` | 3 | `C-001`, `C-068`, `C-140` |
| `exclude` | 1 | `C-070` |
| `reject` | 1 | `C-161` |
| `uncertain` | 0 | none |
| `calibration-accept` | 145 | every candidate in `C-001`-`C-206` not listed in the preceding seven rows |

The duplicate representatives proposed for retention are `C-007` instead of
`C-001`, `C-069` instead of `C-068`, and `C-082` instead of `C-140`.
`C-070` is an availability notice outside candidacy. `C-161` reports field
longevity/research interest but satisfies none of the unchanged admission
criteria.

## Gap Proposal Index

All `43` no-candidate rows were reopened. The recommendation is to retain no
packet status, with the line-specific exclusion recorded in the relevant
batch, for every gap except:

| gap rows | proposed correction |
|---|---|
| `G-003`, `G-004` | Add missing empirical claim `M-001`; retain only administration/figure-label exclusions. |
| `G-014` | Widen `C-087` through `L234` so the question-dependent relation claim has its subject. |
| `G-016`, `G-018` | Add missing architecture-simplicity claim `M-002`; retain only page/heading exclusions. |
| `G-017` | Add the seven numeric Table 1 result packets `T1-001`-`T1-007`. |
| `G-024` | Repair `C-131` as `E-002`; retain heading/page exclusions only. |
| `G-041`, `G-042` | Add Table 2 caption and failure examples `T2-000`-`T2-012`; exclude only `L663-L664` and `L687-L688`. |

`G-043` is appropriate as no-candidate: `L689` is the References heading,
`L690-L739` and `L742-L791` are bibliography entries `[1]` through `[48]`,
and `L740-L741`/`L792` are page or blank administration. The PDF confirms no
non-bibliographic content on pages 15-16.

## Missing Packets

The batches propose `22` omitted claim units:

| proposal IDs | count | source/evidence |
|---|---:|---|
| `M-001` | 1 | Empirical difficulty sentence split between `L41-L42` and `L61-L62` by Figure 1/page material. |
| `M-002` | 1 | Architecture-simplicity comparison split between `L303-L304` and `L323-L324` by Table 1/page material. |
| `T1-001`-`T1-007` | 7 | Seven numeric Table 1 model-result rows at `L313-L319`, interpreted through its header and `C-108`. |
| `T2-000`-`T2-012` | 13 | Table 2 caption plus 12 PDF-aligned RN/GT failure examples at `L665-L686`. |

The full exact fragments, criteria, conditions, metrics, dependencies, and
PDF checks are recorded in batches 01, 05, and 11.

## Repairs And Splits

- `E-001` replaces fragmentary `C-030`/`C-031`.
- `E-002` replaces fragmentary `C-131`.
- `E-003` removes page administration from `C-162` while retaining its
  comparator dependency.
- `C-142`, `C-167`, and `C-192` each split into two independent assertions.
- `C-190`/`C-191` are reconciled as `S-190a` and `S-190b`.
- `C-146` retains the substantive versatility sentences and drops document
  navigation.
- `C-026` retains its quote but changes criterion `1` to criterion `2`.
- Remaining `edit` rows retain their source claims while recording a missing
  referent, task scope, comparator, evidence basis, or configuration
  dependency. Exact dependency targets are in the batch tables.

## Formal-Material Review

The exact PDF was used where the text layer was degraded or structural meaning
depended on visual layout. This included Equations 1 and 2, Figures 1-4,
Tables 1-2, captions, chart labels, example cells, page breaks, and the two
reference pages. No chart values were inferred from bar heights.

Visible extraction discrepancies remain preserved:

- frozen `appened`; PDF `appended` at `C-099`
- frozen `ftheta`; PDF `fphi` at `C-174`
- frozen `102`; PDF `10` squared at `C-193`
- degraded superscripts at `C-042` and `C-085`
- multi-column Table 2 text whose PDF reading order differs from frozen
  extraction order

## Provisional Criteria Observations

These observations are separate from all candidate decisions. No criteria
change was applied.

1. The criteria do not define a packet locator/quote shape for one PDF
   sentence made discontiguous in frozen extraction order by a figure, table,
   or page marker (`M-001`, `E-001`, `M-002`, `E-002`, `E-003`).
2. The criteria do not define whether shared table headers/captions must be
   copied into each numeric/example packet or represented through explicit
   dependencies.
3. The criteria do not define canonical locators/quotes for multi-column
   tables whose text extraction interleaves columns.
4. Mechanically split configuration lists and pronoun-led claims require an
   explicit dependency representation if their source scope is not repeated.
5. Frozen-text discrepancies against the PDF need visible flags; they must not
   be silently normalized during this review.

## Validation

`/tmp/validate-src001-adjudication.mjs` independently reports `PASS`:

- exact source, criteria, handoff, and PDF digests match;
- handoff candidate IDs are exactly `C-001`-`C-206`;
- handoff gap IDs are exactly `G-001`-`G-043`;
- every candidate quote is exact within its locator and at most 60 words;
- exact duplicate quotes: `0`;
- every candidate and gap appears exactly once in the twelve proposal batches;
- the candidate/gap union accounts for every line `L1-L792`;
- uncovered lines: `0`;
- candidate/gap overlap lines: `0`;
- parsed disposition totals match this index.

## Human Gate

The proposal review is complete, but SRC-001 is not closed. A human still must:

1. adopt, revise, or reject every candidate recommendation;
2. adopt, revise, or reject every gap recommendation and missing packet;
3. decide the unresolved representation questions;
4. explicitly approve or refuse `SRC-001 CLOSED FOR CALIBRATION`.

Until those decisions are explicit, all handoff human fields remain `OPEN` and
SRC-002 remains blocked.
