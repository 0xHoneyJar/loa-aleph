# SRC-001 Adjudication: Batch 02 Proposals

> NONCANONICAL MODEL-ASSISTED DEVELOPMENT-CALIBRATION EVIDENCE
>
> These recommendations do not replace the handoff's open human fields and are
> not Loa-Aleph run evidence.

## Batch Identity

| field | exact value |
|---|---|
| review block | `L79-L156` |
| candidate rows | `C-026` through `C-053` |
| no-candidate rows | `G-005` through `G-009` |
| frozen source SHA-256 | `5aef61988ff0db6f2ecc2b7980f370583a317e2427c85a6f78adc3ccc8a1d22a` |
| criteria SHA-256 | `1df51f9872895a3a87a9face2bafe50db34cdfbfd73826e2a31f531c4c538df8` |
| source reopened | frozen text `L79-L156`; exact PDF pages 2-4 |
| criteria changes applied | none |

Each handoff locator and exact quote was reopened in the frozen text. Equation
1 and its page break were also checked in the hash-matched PDF.

## Candidate Recommendations

| ID | stated criterion satisfied | proposed disposition | reason | replacement, split, or dependency |
|---|---|---|---|---|
| C-026 | no; criterion 2 is the direct match | `edit` | The quote defines an architectural component, not complexity, information, intelligence, representation, or system behavior under criterion 1. | Keep the quote and change only the criterion to `2`. |
| C-027 | yes, criterion 4 | `calibration-accept` | It links constraining a network's functional form to capturing common properties of relational reasoning. | none |
| C-028 | yes, criterion 4 | `calibration-accept` | It explains the built-in relational capacity and preserves the CNN and recurrent-network comparators. | none |
| C-029 | yes, criterion 2 | `calibration-accept` | The PDF confirms Equation 1. The quote includes the composite function, object-set input, object dimensionality, functions, and parameter symbols. | none |
| C-030 | yes, criterion 2 | `too-narrow` | It is the first fragment of a sentence split by the extracted page marker and omits the learnable-parameter and differentiability properties. | Replace C-030 and C-031 with E-001 below. |
| C-031 | yes, criterion 2 | `too-narrow` | It begins with `parameters` but omits which functions have those parameters; it is the second fragment of C-030's sentence. | Replace C-030 and C-031 with E-001 below. |
| C-032 | yes, criterion 1 | `calibration-accept` | It defines the output of `gθ` as a relation and states the function's inferential role, including the possibility of no relation. | none |
| C-033 | yes, criterion 1 | `calibration-accept` | It states three scoped RN properties and preserves the set-input and order-invariance qualifications. | none |
| C-034 | yes, criterion 2 | `calibration-accept` | It links Equation 1's functional form to considering all object pairs. | none |
| C-035 | yes, criterion 2 | `calibration-accept` | It preserves the RN's lack of prior knowledge about relation existence/meaning and the resulting need to infer both existence and implications. | none |
| C-036 | yes, criterion 2 | `calibration-accept` | It gives the complete directed-graph representation: objects as nodes and considered pairs as edges. | none |
| C-037 | yes, criterion 7 | `calibration-accept` | It preserves both the paper's all-to-all choice and the alternative of considering only selected pairs. | none |
| C-038 | yes, criterion 7 | `calibration-accept` | It proposes a selected-pair input list and preserves the condition that pair information is available. | none |
| C-039 | yes, criterion 7 | `too-narrow` | `This information` has no referent inside the quote; the necessary referent is the selected-pair list in C-038. | `L111-L114`, criterion 7: `"Similar to Interaction Networks [ 2], to which\nRNs are related, RNs can take as input a list of only those pairs that should be considered, if this\ninformation is available. This information could be explicit in the input data, or could perhaps be\nextracted by some upstream mechanism."` |
| C-040 | yes, criterion 2 | `calibration-accept` | It states the shared `gθ` mechanism and its batch-of-object-pairs operation. | none |
| C-041 | yes, criterion 4 | `calibration-accept` | It links the shared relation function to generalization and reduced pair-specific overfitting. | none |
| C-042 | yes, criterion 6 | `calibration-accept` | It preserves the MLP input arrangement, the `n²` replicated-function requirement, and the intractability condition as object count grows. The PDF confirms the degraded superscript. | none |
| C-043 | yes, criterion 4 | `calibration-accept` | It states the exact MLP/RN computational tradeoff: repeated learning with one pass versus learning once with `n²` passes per object set. | none |
| C-044 | yes, criterion 4 | `calibration-accept` | It links Equation 1's summation to input and output order invariance and the set-input property. | none |
| C-045 | yes, criterion 4 | `too-narrow` | `this invariance` depends on the immediately preceding definition of input/output order invariance. | `L127-L130`, criterion 4: `"This invariance ensures that the RN’s input respects the property\nthat sets are order invariant, and it ensures that the output is order invariant. Ultimately, this\ninvariance ensures that the RN’s output contains information that is generally representative of the\nrelations that exist in the object set."` |
| C-046 | yes, criterion 3 | `calibration-accept` | It records the evaluation-task selection and preserves all three chosen domains and the stated versatility purpose. | none |
| C-047 | yes, criterion 2 | `calibration-accept` | It describes visual-QA system requirements across visual features, language features, and their conjunction. | none |
| C-048 | yes, criterion 6 | `calibration-accept` | It preserves the incomplete-vocabulary and unavailable-world-knowledge constraints on visual-QA datasets. | none |
| C-049 | yes, criterion 6 | `edit` | The limitations qualify `the majority of visual QA datasets` from C-048, but the pronoun `They` loses that scope when isolated. | Retain the exact quote and record an explicit dependency on C-048 for the pronoun's referent. |
| C-050 | yes, criterion 3 | `calibration-accept` | It links CLEVR's construction to controlling prior dataset issues and states the image content. | none |
| C-051 | yes, criterion 3 | `calibration-accept` | It describes CLEVR's question-category construction and preserves both category examples. | none |
| C-052 | yes, criterion 5 | `calibration-accept` | It preserves the relational nature of CLEVR questions, the inability result for powerful QA architectures, and the source's hedged causal explanation (`presumably`). | none |
| C-053 | yes, criterion 5 | `calibration-accept` | It reports the model components, overall result, next-best comparator, human comparator, and attribution to the original paper. | none |

Proposed disposition counts: `calibration-accept=22`, `too-narrow=4`,
`edit=2`, and `reject=too-broad=duplicate=exclude=uncertain=0`.

## Candidate Repair E-001

C-030 and C-031 are one sentence in the PDF. The frozen text interposes the
page marker at `L96-L97`, so its exact source representation is two fragments:

- `L95`: `"For our purposes, fφ and gθ are MLPs, and the"`
- `L98`: `"parameters are learnable synaptic weights, making RNs end-to-end diﬀerentiable."`
- proposed criterion: `2`
- preserved scope: `fφ` and `gθ`; MLP implementation; learnable synaptic-weight
  parameters; end-to-end differentiability.
- unresolved representation: use the same extraction-order handling eventually
  chosen for batch 01's M-001; do not silently reconstruct a contiguous frozen
  quote.

## No-Candidate Recommendations

| review ID | proposed decision | exclusion reason | missing-packet decision |
|---|---|---|---|
| G-005 (`L79`) | no packet appropriate | `2 Relation Networks` is a section heading (`document-administration`). | none |
| G-006 (`L96-L97`) | no packet appropriate | Extracted page number and blank line (`document-administration`); the surrounding sentence is preserved through repair E-001. | none |
| G-007 (`L131`) | no packet appropriate | `3 Tasks` is a section heading (`document-administration`). | none |
| G-008 (`L135`) | no packet appropriate | `3.1 CLEVR` is a section heading (`document-administration`). | none |
| G-009 (`L144-L145`) | no packet appropriate | Extracted page number and blank line (`document-administration`). | none |

## Provisional Criteria Observations

1. Batch 01's unresolved extraction-order observation also applies to E-001:
   page metadata can divide one PDF-contiguous sentence into discontiguous
   frozen-text fragments.
2. No criteria change or supersession was applied.

## Human Gate

No handoff row has been changed. A human must explicitly adopt, revise, or
reject these recommendations. SRC-001 remains open, and SRC-002 must not begin.
