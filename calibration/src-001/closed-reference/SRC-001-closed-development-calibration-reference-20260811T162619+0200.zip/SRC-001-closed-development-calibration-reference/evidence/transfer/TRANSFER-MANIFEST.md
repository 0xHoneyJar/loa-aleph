# SRC-001 Chat Transfer Manifest

> NONCANONICAL DEVELOPMENT-CALIBRATION TRANSFER
>
> This package is evidence for continuing human semantic adjudication. It is
> not a Loa-Aleph run ledger, worker return, packet admission, validation,
> acceptance, sanction, replay, or SRC-001 close decision.

## Package Identity

- created: `2026-08-01T17:47:52+02:00`
- durable destination:
  `/home/eileenspectremoon/loa-dev/aleph-calibration/SRC-001/chat-transfer/`
- source ID: `SRC-001`
- source title: `A simple neural network module for relational reasoning`
- repository files modified: none
- historical run files modified: none
- source, cache, criteria, and existing adjudication files modified: none
- SRC-002 status: not begun

## Required Identity Checks

| artifact | expected SHA-256 | actual SHA-256 | status |
|---|---|---|---|
| frozen source | `5aef61988ff0db6f2ecc2b7980f370583a317e2427c85a6f78adc3ccc8a1d22a` | `5aef61988ff0db6f2ecc2b7980f370583a317e2427c85a6f78adc3ccc8a1d22a` | PASS |
| normalized criteria | `1df51f9872895a3a87a9face2bafe50db34cdfbfd73826e2a31f531c4c538df8` | `1df51f9872895a3a87a9face2bafe50db34cdfbfd73826e2a31f531c4c538df8` | PASS |
| adjudication handoff | `81764a109ce30e92b4661506d8f18a96a17ed81b309fcf614da993461f2783ca` | `81764a109ce30e92b4661506d8f18a96a17ed81b309fcf614da993461f2783ca` | PASS |
| original PDF | `c115123a511418ab46f04c4f9f78b6a569712960dbe9ca596d4edd6f0686d521` | `c115123a511418ab46f04c4f9f78b6a569712960dbe9ca596d4edd6f0686d521` | PASS; actual matches declared |
| recovered conversation cache | `d3635e0cbddbd9dc051863ffc97b39556ec9f09000dcc0371808e2e85e5eb3dd` | `d3635e0cbddbd9dc051863ffc97b39556ec9f09000dcc0371808e2e85e5eb3dd` | PASS |

The frozen source was verified before package completion as exactly `54,207`
bytes and `792` LF-terminated lines.

## Criteria Provenance

- conversation title: `Writing Detailed Product Specs`
- conversation ID: `69f6127f-26e4-8394-aae6-0f40547db804`
- criteria message ID: `416fac66-9743-41c2-857c-c4ed1127690d`
- cache representation: Brotli-compressed JSON
- original criteria export: exact UTF-8 content substring beginning
  `# Extraction Criteria` in the decoded message, including its original two
  trailing LF bytes
- original criteria export size: `4,298` bytes
- original criteria export SHA-256:
  `f76b5e14ced86a72f955dd130d18b39080cf6a76c200cdfaf7f516446d411369`
- normalized digest procedure: `originalCriteria.trimEnd() + LF`
- normalized criteria size: `4,297` bytes
- normalized criteria SHA-256:
  `1df51f9872895a3a87a9face2bafe50db34cdfbfd73826e2a31f531c4c538df8`
- the normalized bytes exactly equal the criteria block embedded in the
  hash-matched adjudication handoff
- no different run's `extraction-criteria.md` was substituted

The original message content is embedded inside compressed JSON, so the
standalone original criteria file is an exact UTF-8 content export rather than
a direct filesystem copy. The complete original compressed cache is also
preserved byte-for-byte.

## Review Continuation State

- authority for this state: the human transfer instruction
- current review position: the first unreviewed candidate is `C-008`, after
  `C-007` and source line `L29`
- decisions already issued: `G-001`, `G-002`, and `C-001` through `C-007`
- remaining candidates: `199` (`C-008` through `C-206`)
- remaining no-candidate ranges: `41` (`G-003` through `G-043`)
- proposed missing claim units: `22`
- first unreviewed proposal file:
  `SRC-001-adjudication-batch-01-proposals.md`
- `C-008` source locator: `L29-L31`
- Batch 1B decisions persisted into the consolidated proposal index: `NO`
- persistence evidence: the index was copied unchanged at SHA-256
  `d92a0f5b768df885ad31db6f7cc17c4c64a3849cac65ebb34c68628cd52919f5`
  and still states that all handoff human fields remain `OPEN`

The immutable proposal files do not contain human decisions. The exact Batch
1B decision wording is not reconstructed from model recommendations here; it
remains part of the destination conversation's continuation instructions.

## File Inventory

Line counts are LF-byte counts for meaningful text files. Binary line counts
are `n/a`.

| filename | original path | bytes | lines | SHA-256 | purpose | exact byte copy | verification and caveat |
|---|---|---:|---:|---|---|---|---|
| `SRC-001-frozen-numbered.txt` | `/home/eileenspectremoon/loa-dev/loa/grimoires/loa/aleph/sources/ilya-sutskever/A simple neural network module for relational reasoning.txt` | 54,207 | 792 | `5aef61988ff0db6f2ecc2b7980f370583a317e2427c85a6f78adc3ccc8a1d22a` | Frozen line-addressable SRC-001 evidence | yes | PASS; exact expected size, lines, and digest |
| `SRC-001-extraction-criteria.original.md` | recovered cache message `416fac66-9743-41c2-857c-c4ed1127690d`, substring beginning `# Extraction Criteria` | 4,298 | 58 | `f76b5e14ced86a72f955dd130d18b39080cf6a76c200cdfaf7f516446d411369` | Original criteria content with two trailing LFs | no; exact content export | PASS; source is embedded JSON text, with full cache preserved separately |
| `SRC-001-extraction-criteria.normalized.md` | `SRC-001-extraction-criteria.original.md` using `trimEnd() + LF` | 4,297 | 57 | `1df51f9872895a3a87a9face2bafe50db34cdfbfd73826e2a31f531c4c538df8` | Frozen criteria bytes used for the recorded digest | no; documented derivation | PASS; matches expected digest and handoff criteria block |
| `SRC-001-adjudication-handoff.md` | `/tmp/SRC-001-adjudication-handoff.md` | 116,676 | 585 | `81764a109ce30e92b4661506d8f18a96a17ed81b309fcf614da993461f2783ca` | Original candidate, gap, criteria, and coverage handoff | yes | PASS; expected digest |
| `SRC-001-adjudication-consolidated-proposal-index.md` | `/tmp/SRC-001-adjudication-consolidated-proposal-index.md` | 9,119 | 177 | `d92a0f5b768df885ad31db6f7cc17c4c64a3849cac65ebb34c68628cd52919f5` | Consolidated nonhuman proposal index | yes | PASS; contains no persisted human Batch 1B decisions |
| `SRC-001-adjudication-batch-01-proposals.md` | `/tmp/SRC-001-adjudication-batch-01-proposals.md` | 11,187 | 129 | `c1d088e0bd1dda89da04533a628bdca4b4dd610db694e9198361939fa7a8b868` | Proposals for L1-L78, C-001-C-025, G-001-G-004; contains C-008 | yes | PASS |
| `SRC-001-adjudication-batch-02-proposals.md` | `/tmp/SRC-001-adjudication-batch-02-proposals.md` | 8,791 | 93 | `11ec5faf437ae50b973b409baa62d3a64a6402935cf0b071d0a9435da199bfc3` | Proposals for L79-L156, C-026-C-053, G-005-G-009 | yes | PASS |
| `SRC-001-adjudication-batch-03-proposals.md` | `/tmp/SRC-001-adjudication-batch-03-proposals.md` | 8,440 | 92 | `7fa12aa984252250e82d3ba3ca7cedb9374d53db3bcd42d99056347b342f8cc8` | Proposals for L157-L234, C-054-C-086, G-010-G-014 | yes | PASS |
| `SRC-001-adjudication-batch-04-proposals.md` | `/tmp/SRC-001-adjudication-batch-04-proposals.md` | 7,380 | 88 | `eaf54c5689e2f86330d1f5b9b4f56198ee558e9492491f06a8d5df88c30cd38a` | Proposals for L235-L312, C-087-C-106, G-015-G-016 | yes | PASS |
| `SRC-001-adjudication-batch-05-proposals.md` | `/tmp/SRC-001-adjudication-batch-05-proposals.md` | 7,782 | 98 | `b751820457447d58405865bc8b953148c2a24c911f063f6c1f07ac5ce9560e5e` | Proposals for L313-L390, C-107-C-119, G-017-G-020 | yes | PASS |
| `SRC-001-adjudication-batch-06-proposals.md` | `/tmp/SRC-001-adjudication-batch-06-proposals.md` | 8,558 | 91 | `aa4e5c94d4e540eb85c558ac5497c68e8799783dff633d0bd253016389bfd315` | Proposals for L391-L468, C-120-C-145, G-021-G-026 | yes | PASS |
| `SRC-001-adjudication-batch-07-proposals.md` | `/tmp/SRC-001-adjudication-batch-07-proposals.md` | 6,196 | 79 | `23e23b089c032bd1269b248fefb9663799d4d0792762db83caa8b7ccb3f490d6` | Proposals for L469-L518, C-146-C-162, G-027-G-032 | yes | PASS |
| `SRC-001-adjudication-batch-08-proposals.md` | `/tmp/SRC-001-adjudication-batch-08-proposals.md` | 6,620 | 71 | `420934551436cbf1956f88937b91deb80960355dd6a9ffd8c81a3434ce2b54c7` | Proposals for L519-L568, C-163-C-183, G-033-G-036 | yes | PASS |
| `SRC-001-adjudication-batch-09-proposals.md` | `/tmp/SRC-001-adjudication-batch-09-proposals.md` | 6,816 | 70 | `15f7870a120aebacbbe696ec11553cf522feaee3f9e1f96014001949dd3f0754` | Proposals for L569-L618, C-184-C-204, G-037-G-039 | yes | PASS |
| `SRC-001-adjudication-batch-10-proposals.md` | `/tmp/SRC-001-adjudication-batch-10-proposals.md` | 3,325 | 61 | `b7551e6d65f8a881f0fa6b0192ebae7b7df03fc188451195c4c75e4a46acd282` | Proposals for L619-L668, C-205-C-206, G-040-G-041 | yes | PASS |
| `SRC-001-adjudication-batch-11-proposals.md` | `/tmp/SRC-001-adjudication-batch-11-proposals.md` | 4,529 | 78 | `59edbbb65d55bc1779b1943c2170a10ef64a3156f63bc5f3e55a4832f875cc37` | Proposals for L669-L688 and G-042 | yes | PASS |
| `SRC-001-adjudication-batch-12-proposals.md` | `/tmp/SRC-001-adjudication-batch-12-proposals.md` | 1,871 | 44 | `4d9a2004026edb465b3c748822959b1cffb93c118459ed5f5ff4e3f55b1cafe7` | Proposals for L689-L792 and G-043 | yes | PASS |
| `validate-src001-adjudication.mjs` | `/tmp/validate-src001-adjudication.mjs` | 8,244 | 253 | `829b6b408e3fd30fa8416598a8bc0186bfab6577db35dbd43475f9a1335ea3ac` | Original structural validation script | yes | PASS; preserved paths reference the original `/tmp` evidence layout |
| `SRC-001-declared.pdf` | `/tmp/SRC-001-declared.pdf` | 1,438,944 | n/a | `c115123a511418ab46f04c4f9f78b6a569712960dbe9ca596d4edd6f0686d521` | Original PDF for visual/formal-material review | yes | PASS; actual digest equals declared digest |
| `Writing-Detailed-Product-Specs.conversation-cache.br` | `/mnt/c/Users/Eileen/AppData/Local/Packages/OpenAI.ChatGPT-Desktop_2p2nqsd0c76g0/LocalCache/Roaming/ChatGPT/Cache/Cache_Data/f_001f4f` | 420,917 | n/a | `d3635e0cbddbd9dc051863ffc97b39556ec9f09000dcc0371808e2e85e5eb3dd` | Read-only original calibration conversation evidence | yes | PASS; Brotli JSON, title and conversation ID verified |

## Structural Verification

The unchanged validation script reports `PASS` against the original evidence
layout:

- `206` candidate rows
- `43` no-candidate rows
- `12` proposal batches
- `0` uncovered source lines
- `0` candidate/gap overlap lines
- `0` exact duplicate quotes

This is structural evidence only and has no semantic authority.

## Upload Set

For complete continuation through the remaining SRC-001 adjudication, upload:

1. `TRANSFER-MANIFEST.md`
2. `SRC-001-frozen-numbered.txt`
3. `SRC-001-extraction-criteria.normalized.md`
4. `SRC-001-adjudication-handoff.md`
5. `SRC-001-adjudication-consolidated-proposal-index.md`
6. all twelve `SRC-001-adjudication-batch-*-proposals.md` files
7. `validate-src001-adjudication.mjs`
8. `SRC-001-declared.pdf`

The original criteria export and compressed conversation cache are retained
for provenance and dispute resolution but are not required for routine
candidate-by-candidate review.

## Authority Boundary

- Continue at `C-008`; do not repeat or silently replace prior human
  decisions.
- Reopen exact source locators and criteria for every decision.
- Treat every proposal and structural check as non-authoritative.
- Keep final candidate/coverage decisions separate from provisional criteria,
  prompt, extraction, rendering, and verification observations.
- Do not change the frozen criteria during SRC-001 adjudication.
- Do not begin SRC-002.
- Do not close SRC-001 without explicit human authorization.
