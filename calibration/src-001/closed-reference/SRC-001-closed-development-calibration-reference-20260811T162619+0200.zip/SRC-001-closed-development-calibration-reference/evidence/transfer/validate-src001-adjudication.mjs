import { createHash } from "node:crypto";
import { readFileSync, readdirSync } from "node:fs";

const sourcePath =
  "/home/eileenspectremoon/loa-dev/loa/grimoires/loa/aleph/sources/ilya-sutskever/A simple neural network module for relational reasoning.txt";
const handoffPath = "/tmp/SRC-001-adjudication-handoff.md";
const pdfPath = "/tmp/SRC-001-declared.pdf";
const expected = {
  source: "5aef61988ff0db6f2ecc2b7980f370583a317e2427c85a6f78adc3ccc8a1d22a",
  handoff: "81764a109ce30e92b4661506d8f18a96a17ed81b309fcf614da993461f2783ca",
  pdf: "c115123a511418ab46f04c4f9f78b6a569712960dbe9ca596d4edd6f0686d521",
  criteria: "1df51f9872895a3a87a9face2bafe50db34cdfbfd73826e2a31f531c4c538df8",
};

const hash = (value) => createHash("sha256").update(value).digest("hex");
const sourceBytes = readFileSync(sourcePath);
const handoffBytes = readFileSync(handoffPath);
const pdfBytes = readFileSync(pdfPath);
const source = sourceBytes.toString("utf8");
const sourceLines = source.replace(/\n$/, "").split("\n");
const handoff = handoffBytes.toString("utf8");
const handoffLines = handoff.split("\n");
const errors = [];

for (const [name, bytes] of [
  ["source", sourceBytes],
  ["handoff", handoffBytes],
  ["pdf", pdfBytes],
]) {
  const actual = hash(bytes);
  if (actual !== expected[name]) {
    errors.push(`${name} digest ${actual}, expected ${expected[name]}`);
  }
}

if (sourceLines.length !== 792) {
  errors.push(`source has ${sourceLines.length} lines, expected 792`);
}

const criteriaMatch = handoff.match(
  /```markdown\n(# Extraction Criteria[\s\S]*?)\n```/,
);
if (!criteriaMatch) {
  errors.push("exact criteria block not found in handoff");
} else {
  const criteria = `${criteriaMatch[1].trimEnd()}\n`;
  const actual = hash(criteria);
  if (actual !== expected.criteria) {
    errors.push(`criteria digest ${actual}, expected ${expected.criteria}`);
  }
}

const parseLocator = (locator) => {
  const match = locator.match(/^L(\d+)(?:-L(\d+))?$/);
  if (!match) throw new Error(`invalid locator ${locator}`);
  return [Number(match[1]), Number(match[2] ?? match[1])];
};

const candidates = [];
const gaps = [];
for (const line of handoffLines) {
  const candidate = line.match(
    /^\| (C-\d{3}) \| (L\d+(?:-L\d+)?) \| <code>(.+)<\/code> \| ([1-7]) \|/,
  );
  if (candidate) {
    let quote;
    try {
      quote = JSON.parse(candidate[3]);
    } catch (error) {
      errors.push(`${candidate[1]} has invalid JSON quote: ${error.message}`);
      continue;
    }
    const [start, end] = parseLocator(candidate[2]);
    const span = sourceLines.slice(start - 1, end).join("\n");
    if (!span.includes(quote)) {
      errors.push(`${candidate[1]} quote is not exact within ${candidate[2]}`);
    }
    const words = quote.trim().split(/\s+/u).filter(Boolean).length;
    if (words > 60) {
      errors.push(`${candidate[1]} has ${words} words`);
    }
    candidates.push({
      id: candidate[1],
      locator: candidate[2],
      criterion: Number(candidate[4]),
      quote,
      start,
      end,
    });
  }

  const gap = line.match(/^\| (G-\d{3}) \| (L\d+(?:-L\d+)?) \|/);
  if (gap) {
    const [start, end] = parseLocator(gap[2]);
    gaps.push({ id: gap[1], locator: gap[2], start, end });
  }
}

const assertSequence = (rows, prefix, expectedCount) => {
  if (rows.length !== expectedCount) {
    errors.push(`${prefix} rows: ${rows.length}, expected ${expectedCount}`);
  }
  const ids = rows.map(({ id }) => id);
  const unique = new Set(ids);
  if (unique.size !== ids.length) {
    errors.push(`${prefix} IDs are not unique`);
  }
  for (let number = 1; number <= expectedCount; number += 1) {
    const id = `${prefix}-${String(number).padStart(3, "0")}`;
    if (!unique.has(id)) errors.push(`missing ${id}`);
  }
};

assertSequence(candidates, "C", 206);
assertSequence(gaps, "G", 43);

const quoteOwners = new Map();
for (const { id, quote } of candidates) {
  const owners = quoteOwners.get(quote) ?? [];
  owners.push(id);
  quoteOwners.set(quote, owners);
}
const duplicateQuotes = [...quoteOwners.entries()].filter(
  ([, owners]) => owners.length > 1,
);
if (duplicateQuotes.length) {
  errors.push(
    `duplicate exact quotes: ${duplicateQuotes
      .map(([, owners]) => owners.join("/"))
      .join(", ")}`,
  );
}

const candidateCoverage = Array(793).fill(false);
const gapCoverage = Array(793).fill(false);
for (const { start, end } of candidates) {
  for (let line = start; line <= end; line += 1) candidateCoverage[line] = true;
}
for (const { id, start, end } of gaps) {
  for (let line = start; line <= end; line += 1) {
    if (gapCoverage[line]) errors.push(`${id} overlaps another gap at L${line}`);
    gapCoverage[line] = true;
  }
}
const uncovered = [];
const candidateGapOverlap = [];
for (let line = 1; line <= 792; line += 1) {
  if (!candidateCoverage[line] && !gapCoverage[line]) uncovered.push(line);
  if (candidateCoverage[line] && gapCoverage[line]) candidateGapOverlap.push(line);
}
if (uncovered.length) errors.push(`uncovered source lines: ${uncovered.join(",")}`);
if (candidateGapOverlap.length) {
  errors.push(`candidate/gap overlap: ${candidateGapOverlap.join(",")}`);
}

const batchFiles = readdirSync("/tmp")
  .filter((name) => /^SRC-001-adjudication-batch-\d{2}-proposals\.md$/.test(name))
  .sort();
if (batchFiles.length !== 12) {
  errors.push(`proposal batches: ${batchFiles.length}, expected 12`);
}

const proposalCandidates = [];
const proposalGaps = [];
const dispositions = new Map();
const allowedDispositions = new Set([
  "calibration-accept",
  "edit",
  "reject",
  "too-broad",
  "too-narrow",
  "duplicate",
  "exclude",
  "uncertain",
]);

for (const file of batchFiles) {
  const text = readFileSync(`/tmp/${file}`, "utf8");
  if (!text.includes(expected.source)) errors.push(`${file} lacks source digest`);
  if (!text.includes(expected.criteria)) errors.push(`${file} lacks criteria digest`);
  if (!text.includes("criteria changes applied | none")) {
    errors.push(`${file} does not record unchanged criteria`);
  }
  if (!text.includes("## Human Gate")) errors.push(`${file} lacks human gate`);

  for (const line of text.split("\n")) {
    const candidate = line.match(
      /^\| (C-\d{3}) \| [^|]* \| `([a-z-]+)` \|/,
    );
    if (candidate) {
      const [, id, disposition] = candidate;
      proposalCandidates.push({ id, disposition, file });
      dispositions.set(disposition, (dispositions.get(disposition) ?? 0) + 1);
      if (!allowedDispositions.has(disposition)) {
        errors.push(`${id} has invalid disposition ${disposition}`);
      }
    }
    const gap = line.match(/^\| (G-\d{3}) \(`L\d+(?:-L\d+)?`\) \|/);
    if (gap) proposalGaps.push({ id: gap[1], file });
  }
}

assertSequence(proposalCandidates, "C", 206);
assertSequence(proposalGaps, "G", 43);

const handoffCandidateIds = new Set(candidates.map(({ id }) => id));
const handoffGapIds = new Set(gaps.map(({ id }) => id));
for (const { id } of proposalCandidates) {
  if (!handoffCandidateIds.has(id)) errors.push(`${id} is not in handoff`);
}
for (const { id } of proposalGaps) {
  if (!handoffGapIds.has(id)) errors.push(`${id} is not in handoff`);
}

console.log(
  JSON.stringify(
    {
      status: errors.length ? "FAIL" : "PASS",
      source: {
        bytes: sourceBytes.length,
        lines: sourceLines.length,
        sha256: hash(sourceBytes),
      },
      handoff: { sha256: hash(handoffBytes) },
      pdf: { sha256: hash(pdfBytes) },
      criteria: { sha256: criteriaMatch ? hash(`${criteriaMatch[1].trimEnd()}\n`) : null },
      handoffRows: {
        candidates: candidates.length,
        gaps: gaps.length,
        duplicateExactQuotes: duplicateQuotes.length,
      },
      sourceCoverage: {
        firstLine: 1,
        lastLine: 792,
        uncoveredLines: uncovered.length,
        candidateGapOverlaps: candidateGapOverlap.length,
      },
      proposalBatches: batchFiles,
      proposalRows: {
        candidates: proposalCandidates.length,
        gaps: proposalGaps.length,
        dispositions: Object.fromEntries(
          [...dispositions.entries()].sort(([a], [b]) => a.localeCompare(b)),
        ),
      },
      errors,
    },
    null,
    2,
  ),
);

process.exitCode = errors.length ? 1 : 0;
