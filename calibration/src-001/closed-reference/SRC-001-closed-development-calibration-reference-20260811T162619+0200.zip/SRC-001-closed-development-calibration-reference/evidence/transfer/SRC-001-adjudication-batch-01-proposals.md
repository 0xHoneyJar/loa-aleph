# SRC-001 Adjudication: Batch 01 Proposals

> NONCANONICAL MODEL-ASSISTED DEVELOPMENT-CALIBRATION EVIDENCE
>
> These are source-grounded recommendations, not human dispositions, a Loa-Aleph
> run artifact, a worker return, packet admission, validation, sanction, or
> acceptance. The human fields and close decision in the adjudication handoff
> remain open.

## Batch Identity

| field | exact value |
|---|---|
| review block | `L1-L78` |
| candidate rows | `C-001` through `C-025` |
| no-candidate rows | `G-001` through `G-004` |
| frozen source SHA-256 | `5aef61988ff0db6f2ecc2b7980f370583a317e2427c85a6f78adc3ccc8a1d22a` |
| frozen source size | `54207` bytes, `792` lines |
| criteria SHA-256 | `1df51f9872895a3a87a9face2bafe50db34cdfbfd73826e2a31f531c4c538df8` |
| criteria size | `4297` bytes under the recorded procedure |
| review-index SHA-256 | `81764a109ce30e92b4661506d8f18a96a17ed81b309fcf614da993461f2783ca` |
| PDF SHA-256 | `c115123a511418ab46f04c4f9f78b6a569712960dbe9ca596d4edd6f0686d521` |
| source reopened | frozen text `L1-L78`; exact PDF pages 1-2 |
| criteria changes applied | none |

The criteria digest was recomputed from the pinned criteria message using the
recorded substring and newline procedure. The PDF was independently retrieved
and used only after its bytes matched the source wrapper's declared digest.
Each candidate locator and exact quote was reopened in the frozen text before
the recommendation below.

## Candidate Recommendations

| ID | stated criterion satisfied | proposed disposition | reason | replacement or split |
|---|---|---|---|---|
| C-001 | yes, criterion 1 | `duplicate` | It repeats C-007's claim that relational reasoning is central to generally intelligent behavior. C-007 is the more scoped occurrence because it names relations between entities and their properties. | Retain C-007 as the representative; no replacement. |
| C-002 | yes, criterion 6 | `too-narrow` | The quote begins with `but` and omits the subject, so the limitation cannot be reopened independently. | `L16-L17`, criterion 6: `"Relational reasoning is a central component of generally intelligent behavior, but has proven\ndiﬃcult for neural networks to learn."` |
| C-003 | yes, criterion 2 | `calibration-accept` | It identifies the RN as a plug-and-play module and states the class of problems it is intended to solve. | none |
| C-004 | yes, criterion 5 | `calibration-accept` | It records the three evaluation domains and preserves the CLEVR result and its stated performance comparison. | none |
| C-005 | yes, criterion 5 | `calibration-accept` | It reports a conditioned comparison on Sort-of-CLEVR between convolutional networks without and with an RN. | none |
| C-006 | yes, criterion 4 | `calibration-accept` | It links adding an RN module to discovering entities and learning to reason about their relations. | none |
| C-007 | yes, criterion 1 | `calibration-accept` | It states a property of generally intelligent behavior and preserves the entity/property scope and citations. | none |
| C-008 | yes, criterion 4 | `calibration-accept` | The example links pairwise-distance inference and comparison to selecting the two furthest trees. | none |
| C-009 | yes, criterion 4 | `calibration-accept` | The example links contextual integration of clues to constructing a narrative and solving the mystery. | none |
| C-010 | yes, criterion 1 | `calibration-accept` | It states a property of symbolic AI approaches: they are inherently relational. | none |
| C-011 | yes, criterion 2 | `calibration-accept` | It describes how symbolic relations are defined and the mechanisms used to reason over them. | none |
| C-012 | yes, criterion 6 | `calibration-accept` | It preserves two stated limitations of symbolic approaches: grounding and sensitivity to task/input variation. | none |
| C-013 | yes, criterion 4 | `calibration-accept` | It links representation construction from raw data in statistical learning approaches to generalization across diverse, noisy conditions. | none |
| C-014 | yes, criterion 6 | `calibration-accept` | It preserves the data-poor condition and sparse-but-complex relational structure under which deep learning approaches are said to struggle. | none |
| C-015 | yes, criterion 1 | `calibration-accept` | The hash-matched PDF confirms the caption and figure. The caption distinguishes relational reasoning over relations among four objects from non-relational reasoning over one object's attributes. | none |
| C-016 | yes, criterion 7 | `calibration-accept` | It states the paper's proposal to explore RNs as a general solution for relational reasoning in neural networks. | none |
| C-017 | yes, criterion 2 | `calibration-accept` | It defines the architectural focus of RN computation. | none |
| C-018 | yes, criterion 2 | `calibration-accept` | The contrast is one coherent architecture claim: other relation-centric models exist, while RNs are described as simple, plug-and-play, and exclusively focused on flexible relational reasoning. | none |
| C-019 | yes, criterion 4 | `calibration-accept` | It links joint training to shaping upstream CNN/LSTM representations into implicit object-like representations usable for relational reasoning. | none |
| C-020 | yes, criterion 3 | `calibration-accept` | It records application of an RN-augmented architecture to CLEVR and preserves why the dataset is challenging for prior approaches. | none |
| C-021 | yes, criterion 5 | `too-narrow` | The comparison omits the CLEVR evaluation condition supplied by the immediately preceding sentence. | `L70-L73`, criterion 5: `"We applied an RN-augmented architecture to CLEVR [ 15], a recent visual question answering\n(QA) dataset on which state-of-the-art approaches have struggled due to the demand for rich\nrelational reasoning. Our networks vastly outperformed the best generally-applicable visual QA\narchitectures, and achieve state-of-the-art, super-human performance."` |
| C-022 | yes, criterion 5 | `calibration-accept` | It preserves the CLEVR condition, state-description input form, result, and stated versatility implication. | none |
| C-023 | yes, criterion 5 | `calibration-accept` | It records the bAbI evaluation and the exact `18/20` result. | none |
| C-024 | yes, criterion 3 | `calibration-accept` | It records training an RN for relational inferences over complex physical systems and motion-capture data without claiming an unreported metric. | none |
| C-025 | yes, criterion 4 | `calibration-accept` | It explicitly links success across substantially dissimilar task domains to the claimed general utility of RNs for relation-reasoning problems. | none |

Proposed disposition counts: `calibration-accept=22`, `too-narrow=2`,
`duplicate=1`, and `edit=reject=too-broad=exclude=uncertain=0`.

## No-Candidate Recommendations

| review ID | proposed decision | reason | missing-packet or exclusion record |
|---|---|---|---|
| G-001 (`L1-L15`) | no packet appropriate | `L1-L5` is extraction-wrapper metadata; `L6` is blank; `L7-L15` is title, authorship, contact, affiliation, and a section heading without an independent subject-matter assertion. | Exclude `L1-L5` as `extraction-wrapper`; exclude `L6-L15` as blank/document-administration. |
| G-002 (`L27`) | no packet appropriate | The line is the `1 Introduction` heading and asserts no subject-matter claim. | Exclude as `document-administration`. |
| G-003 (`L42-L55`) | no-candidate status is not fully appropriate | `L42` continues an empirical assertion begun at `L41` and completed at `L61-L62`. `L43-L46` is contribution/page/version administration. The exact PDF confirms that `L47-L55` is question and diagram labeling whose substantive interpretation is already stated in C-015's caption. | Propose missing claim M-001 for `L41-L42` plus `L61-L62`. Exclude `L43-L46` as document-administration and `L47-L55` as figure/example labels and questions without an independent assertion. |
| G-004 (`L61-L62`) | no-candidate status is not appropriate | These lines complete the empirical assertion begun at `L41-L42`; excluding them loses the reported limitation and its model scope. | Propose the same missing claim M-001; do not create a second packet for the same sentence. |

## Missing-Packet Proposal

### M-001: empirical difficulty of simple relational inferences

- proposed criterion: `5` (the source explicitly attributes the assertion to
  `Our results`); criterion 6 also describes the limitation.
- exact frozen-text fragment 1, `L41-L42`:
  `"Our results corroborate\nthese claims, and further demonstrate that seemingly simple relational inferences are remarkably"`
- exact frozen-text fragment 2, `L61-L62`:
  `"diﬃcult for powerful neural network architectures such as convolutional neural networks (CNNs) and\nmulti-layer perceptrons (MLPs)."`
- evidence basis and scope: the paper's results; seemingly simple relational
  inferences; powerful CNN and MLP architectures.
- PDF check: the hash-matched PDF shows these fragments as one sentence split
  across PDF pages 1 and 2, with Figure 1 placed before the continuation on
  page 2.
- unresolved representation question: the sentence is contiguous in the PDF
  but discontinuous in frozen extracted-line order because `L43-L60` is
  interposed administration and figure material. The unchanged granularity
  policy requires a contiguous line span but does not state how to quote this
  extraction-order case. Do not silently reconstruct a single exact quote.

## Preliminary-Pass Reconciliation

The superseded 21-row response was reopened only as proposal provenance; all
semantic decisions above derive from the frozen source.

- Its combined `L16-L17` row preserved C-002's subject but failed to split the
  two assertions. The final split is preferable, with C-002 widened as proposed.
- Its combined `L34-L36` row was cleanly split into complete C-010 and C-011
  assertions.
- Its `L39-L42` row joined C-014 to the first half of M-001 and was too broad.
  The final pass removed that fragment but failed to restore the complete
  cross-page assertion.
- Its separate `L61-L62` row contained only M-001's second fragment and was too
  narrow. The final pass then omitted it entirely.
- Its combined `L63-L64` row was cleanly split into the proposal at C-016 and
  architecture definition at C-017.
- Its combined `L70-L74` row was usefully split into method and result rows,
  but C-021 lost the CLEVR evaluation condition and should be widened as above.

## Provisional Criteria Observations

These observations are separate from the candidate decisions and were not
applied as criteria changes:

1. The granularity policy does not specify how to represent a source sentence
   that is contiguous in the hash-matched PDF but discontinuous in the frozen
   text's extraction order because figure material is interposed.
2. No supersession, digest change, or SRC-001 re-extraction is proposed during
   this review.

## Human Gate

No handoff row has been changed. A human must explicitly adopt, revise, or
reject each recommendation before any corresponding `OPEN` human disposition
can be replaced. SRC-001 remains open, and SRC-002 must not begin.
