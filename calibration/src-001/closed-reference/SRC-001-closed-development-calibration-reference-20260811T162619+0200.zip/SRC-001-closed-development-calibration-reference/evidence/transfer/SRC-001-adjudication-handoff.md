# SRC-001 Adjudication Handoff

> NONCANONICAL DEVELOPMENT-CALIBRATION EVIDENCE
>
> This is not a run ledger, worker return, packet admission, acceptance record, replay, sanction, or authority decision. Mechanical correction and survival in this candidate list do not imply semantic acceptance. SRC-002 must not begin until a human explicitly closes SRC-001.

## Review State

- state: `OPEN_FOR_HUMAN_ADJUDICATION`
- disposition authority: human
- all 206 candidate dispositions: `OPEN`
- human semantic close decision: `OPEN`
- source-coverage caveat: the full L1-L792 source was present earlier in the active branch, but the completion prompt omitted L669 and did not re-present L689-L792; semantic reasons and human approval for both no-admission statements are not recorded
- generated output path: `/tmp/SRC-001-adjudication-handoff.md`
- generated from immutable evidence only; no repository, run, source, criteria, fixture, or cache mutation

## Exact Identity

| field | exact value |
|---|---|
| conversation title | Writing Detailed Product Specs |
| conversation ID | `69f6127f-26e4-8394-aae6-0f40547db804` |
| conversation current node | `f5361b0c-c03f-4a3e-99a4-cc98f9456189` |
| conversation created | `2026-05-02T15:04:46.802Z` |
| conversation updated | `2026-07-30T15:12:21.203Z` |
| cached mapping nodes | `694` |
| cache path | `/mnt/c/Users/Eileen/AppData/Local/Packages/OpenAI.ChatGPT-Desktop_2p2nqsd0c76g0/LocalCache/Roaming/ChatGPT/Cache/Cache_Data/f_001f4f` |
| cache representation | Brotli-compressed JSON |
| cache bytes | `420917` |
| cache SHA-256 | `d3635e0cbddbd9dc051863ffc97b39556ec9f09000dcc0371808e2e85e5eb3dd` |
| source ID | `SRC-001` |
| source title | *A simple neural network module for relational reasoning* |
| frozen text path used for verification | `/home/eileenspectremoon/loa-dev/loa/grimoires/loa/aleph/sources/ilya-sutskever/A simple neural network module for relational reasoning.txt` |
| frozen text bytes | `54207` |
| frozen text lines | `792` |
| frozen text SHA-256 | `5aef61988ff0db6f2ecc2b7980f370583a317e2427c85a6f78adc3ccc8a1d22a` |
| source PDF identity in conversation | `A simple neural network module for relational reasoning.pdf` |
| source PDF SHA-256 | `c115123a511418ab46f04c4f9f78b6a569712960dbe9ca596d4edd6f0686d521` (declared in source wrapper; PDF bytes not independently verified) |
| extraction notice | `pypdf (text-layer extraction; figures/equations may be degraded)` |
| PDF pages | `16` |
| criteria message | `416fac66-9743-41c2-857c-c4ed1127690d` @ `2026-07-18T22:10:37.913Z` |
| criteria digest procedure | exact substring beginning `# Extraction Criteria`, then `trimEnd() + LF` |
| criteria bytes under that procedure | `4297` |
| criteria SHA-256 | `1df51f9872895a3a87a9face2bafe50db34cdfbfd73826e2a31f531c4c538df8` |

### Source-Presentation Provenance

- Source tool nodes carrying the declared PDF wrapper: `34efc471-577d-4193-8a77-c032ece0838e`, `76bd7cc0-f77f-4544-86f7-e467cb8f754a`, and `d7607a36-7412-4e67-93c6-3760346c403d`.
- Tool node `34efc471-577d-4193-8a77-c032ece0838e` @ `2026-07-18T22:10:50.051Z` contains the exact complete frozen source from L1-L792; its source segment SHA-256 is `5aef61988ff0db6f2ecc2b7980f370583a317e2427c85a6f78adc3ccc8a1d22a`.
- The two later source tool nodes end during local source line L530 with `The file is too long and its contents have been truncated.`
- Later user messages supplied numbered source chunks through L688, except L669 was omitted from the final chunk. No dedicated final prompt re-presented L689-L792.
- The unresolved coverage question is whether the assistant actually re-reviewed L669-L792 before emitting the requested no-admission wording. The cache records no semantic reason or human approval.

## Exact Criteria Text

```markdown
# Extraction Criteria — RUN-20260718T200215838Z-b836c0a930da

- written: 2026-07-18T20:29:18.450Z
- author: Eileen (human operator; Codex-prepared proposal adopted verbatim)

## Candidate-claim definition (this corpus)

A candidate claim is any source-borne assertion, definition, formal or
empirical result, design proposal, constraint, or unresolved choice that could
plausibly inform how complex systems are represented, organized, coordinated,
trained, optimized, scaled, measured, evaluated, or designed. Importance and
truth are judged later. Uncertain spans are admitted.

## Admission criteria

| # | criterion | example span that qualifies |
|---|-----------|-----------------------------|
| 1 | Definitions, measures, or properties of complexity, information, intelligence, representation, or system behavior. | SRC-024 L11-L22 defines and reports behavior of apparent complexity. |
| 2 | Architectures, components, mechanisms, interactions, memory, communication, hierarchy, or information flow. | SRC-014 L13-L18 describes coupling a neural network to external memory through attention. |
| 3 | Construction, training, optimization, scaling, resource-allocation, or implementation methods. | SRC-005 L32-L43 describes pipeline parallelism and batch splitting across accelerators. |
| 4 | Explanations linking a design choice or mechanism to behavior, performance, robustness, or generalization. | SRC-006 L12-L19 links identity mappings to signal propagation, easier training, and generalization. |
| 5 | Theoretical or empirical results, comparisons, ablations, and scaling relationships, including their conditions and metrics. | SRC-019 L39-L47 reports power-law scaling and compute-allocation consequences. |
| 6 | Assumptions, constraints, boundaries, tradeoffs, limitations, and failure modes. | SRC-016 L15-L26 states the variable-output-dictionary constraint and the proposed mechanism. |
| 7 | Design proposals, recommendations, alternatives, open choices, and stated future directions. | SRC-013 L18-L31 proposes the next search and evaluation direction for message-passing models. |

## Exclusion classes (outside candidacy, recorded here once)

| class | description | example |
|-------|-------------|---------|
| extraction-wrapper | Extraction wrapper metadata such as `SOURCE-PDF`, hashes, extractor name, and page count. | SRC-001 L1-L5 |
| document-administration | Titles, author lists, affiliations, licensing boilerplate, headings, tables of contents, page numbers, and separators when they assert nothing substantive. | SRC-023 L7-L8 licensing permission |
| bibliography-and-index | Bibliography entries, indexes, and acknowledgements without an independent subject-matter assertion. | A reference-list citation with no assertion by the source text |
| extraction-noise | Repeated navigation text and unrecoverable extraction fragments. | SRC-020 L8-L10 repeated navigation text |
| uninterpreted-fragment | Isolated equations, table cells, code fragments, or symbols without enough adjacent prose or captions to identify an assertion. Ambiguous cases are widened and admitted. | A detached numeric row with no caption or interpretive prose |
| refusal-blocked | `refusal-blocked` is inapplicable in manual mode; unreadable material remains visibly flagged rather than silently discarded. | n/a |

## Packet granularity policy

Use the smallest contiguous line span containing one coherent assertion,
widened for necessary definitions, qualifiers, conditions, or comparators.
Split independent assertions. Include claim-bearing captions or prose around
equations, tables, figures, and code. Preserve degraded text exactly and flag
it; never reconstruct missing content. Over-extract when uncertain.

## Normalization conventions (used at S3)

Preserve attribution, hedging, modality, causal versus correlational language,
conditions, quantities, units, metrics, and source-specific meanings of
"complexity." Repair only obvious line-wrap artifacts in normalized prose;
retain exact quotations and flag ambiguous OCR. Do not import external facts,
synthesize across sources, merge duplicates, resolve conflicts, or assign
dispositions.

## Supersessions

| # | date | change | re-extraction completed over |
|---|------|--------|------------------------------|
```

## Reconstruction Rules

- Candidate IDs `C-001` through `C-206` are local review IDs only. They are not `PKT-*` IDs.
- The list uses the mechanically surviving final rows in source order.
- `Candidate wording` is `NOT RECORDED` because the original pass returned locators, criteria, and exact quotes, not normalized candidate prose.
- Exact quotes below are JSON string literals. `\n` denotes an exact LF from the originating assistant response; Unicode characters are preserved.
- `UNADJUDICATED` and correction flags are evidence labels, not semantic dispositions.
- Every listed quote was rechecked against the frozen source locator and every final quote has at most 60 whitespace-delimited words.
- Criterion counts: `1=13`, `2=27`, `3=64`, `4=39`, `5=35`, `6=20`, `7=8`.
- Exact duplicate quotes among the 206 final rows: `0`. Semantic duplicate adjudication: `NOT RECORDED`.

## Complete Coverage Map

| reviewed block | candidate IDs | spans with candidates | spans with no candidates | spans explicitly excluded | unresolved coverage questions |
|---|---|---|---|---|---|
| L1-L78 | C-001-C-025 | L16, L16-L17, L17-L19, L19-L22, L22-L24, L24-L26, L28-L29, L29-L31, L31-L33, L34, L34-L36, L37-L38, L38-L39, L39-L41, L56-L60, L63-L64, L64, L65-L67, L68-L69, L70-L72, L72-L73, L73-L74, L74-L75, L76-L77, L77-L78 | L1-L15, L27, L42-L55, L61-L62 | L1-L5: extraction-wrapper (stated in exact criteria text) | L1-L5 is explicitly identified by the criteria as extraction-wrapper material. A preliminary 21-row assistant pass exists before the final 25-row pass; the semantic differences were not human-adjudicated. |
| L79-L156 | C-026-C-053 | L80, L80-L82, L82-L85, L86-L95, L95, L98, L98-L100, L101-L103, L104-L105, L105-L107, L108-L109, L110-L111, L111-L113, L113-L114, L115-L117, L117-L119, L119-L122, L122-L125, L126-L128, L128-L130, L132-L134, L136-L139, L139-L141, L141-L143, L146-L148, L148-L150, L151-L153, L153-L156 | L79, L96-L97, L131, L135, L144-L145 | NOT RECORDED | Seven overlong proposals were mechanically split; review fragmentation and whether the RN equation/material remains sufficiently grounded. |
| L157-L234 | C-054-C-086 | L157-L160, L161-L163, L163-L165, L165-L167, L169-L171, L172-L175, L175-L177, L177-L178, L178-L179, L179-L181, L181-L182, L184-L185, L185-L187, L187-L188, L188-L189, L189-L192, L193, L197-L199, L199-L201, L201-L204, L205-L207, L207-L210, L211-L213, L213-L214, L215-L216, L219-L220, L220-L222, L222-L223, L223-L225, L226-L228, L228-L229, L229-L231, L231-L233 | L168, L183, L194-L196, L217-L218, L234 | NOT RECORDED | Per-gap exclusion rationales and missing-packet decisions are NOT RECORDED. |
| L235-L312 | C-087-C-106 | L235-L236, L236-L238, L238-L241, L241-L242, L271-L274, L274-L275, L276-L279, L280-L282, L282-L285, L286-L287, L288-L289, L289-L290, L290-L291, L291-L293, L294-L296, L296-L297, L297-L298, L298-L300, L300-L301, L301-L302 | L243-L270, L303-L312 | NOT RECORDED | Two locators were mechanically widened. Figure 2 labels/diagram material at L243-L270 requires original-PDF review. |
| L313-L390 | C-107-C-119 | L320, L321-L322, L327-L329, L330-L331, L331-L332, L332-L334, L335-L337, L337-L338, L338-L340, L340-L342, L344-L345, L345-L348, L348-L350 | L313-L319, L323-L326, L343, L351-L390 | NOT RECORDED | Raw Table 1 cells at L313-L319 and Figure 3 chart labels at L351-L390 produced no candidates; formal-material disposition is NOT RECORDED. |
| L391-L468 | C-120-C-145 | L393-L395, L397-L398, L399-L402, L403-L405, L405-L408, L409-L410, L410-L413, L415-L416, L417-L419, L419-L420, L420-L423, L429-L430, L430-L432, L432-L434, L436-L438, L438-L440, L440-L441, L442-L444, L444-L446, L446-L448, L449-L450, L450-L453, L454-L456, L456-L459, L459-L462, L463-L464 | L391-L392, L396, L414, L424-L428, L435, L465-L468 | NOT RECORDED | One 67-word proposal was split. L465-L468 contains acknowledgement/page material, but no contemporaneous line-specific exclusion rationale was recorded. |
| L469-L518 | C-146-C-162 | L476-L478, L480-L481, L481-L482, L482-L485, L485-L486, L488-L490, L490-L491, L493-L494, L494-L496, L496-L499, L499-L500, L500-L501, L502-L504, L504-L505, L505-L508, L510-L512, L513-L517 | L469-L475, L479, L487, L492, L509, L518 | NOT RECORDED | Related-work and implementation-detail breadth judgments are NOT RECORDED. |
| L519-L568 | C-163-C-183 | L519-L520, L520-L522, L522-L524, L524-L525, L525-L527, L528, L528-L530, L532-L534, L534-L537, L539-L540, L540-L541, L541-L543, L543-L545, L547-L548, L549-L551, L552-L553, L554-L557, L557-L559, L560-L562, L565-L568, L568 | L531, L538, L546, L563-L564 | NOT RECORDED | One 61-word proposal was split. Candidate-level over-breadth judgments for implementation minutiae are NOT RECORDED. |
| L569-L618 | C-184-C-204 | L569-L570, L570-L572, L573-L575, L575-L576, L576-L578, L580-L581, L581-L582, L582-L583, L583-L585, L587-L589, L589-L590, L590-L592, L592-L594, L595-L598, L598-L600, L600-L602, L603-L604, L604-L606, L606-L608, L608-L609, L609-L610 | L579, L586, L611-L618 | NOT RECORDED | L611-L618 contains a URL, page marker, and extracted figure labels; line-specific exclusion rationale is NOT RECORDED. |
| L619-L668 | C-205-C-206 | L657-L659, L659-L662 | L619-L656, L663-L668 | NOT RECORDED | Figure 4 diagram/example cells at L619-L656 and L663-L668 produced no candidates; formal-material disposition is NOT RECORDED. |
| L669-L688 | none | none | L669-L688 | NOT RECORDED | The prompt supplied L670-L688 but omitted L669. The assistant then emitted a no-admission statement. Semantic reason and human approval are NOT RECORDED. |
| L689-L792 | none | none | L689-L792 | NOT RECORDED | The exact full source was present earlier at tool node 34efc471-577d-4193-8a77-c032ece0838e, but no dedicated final prompt re-presented L689-L792. Semantic reason and human approval are NOT RECORDED. |

Coverage-map interpretation: every source line is mechanically classified above as intersecting at least one final candidate locator or as having no final candidate. That does not establish semantic completeness. Except for the criteria's explicit L1-L5 extraction-wrapper example, per-span exclusion reasons and missing-packet decisions remain open.

## No-Admission Evidence

### L669-L688

- Prompting user message: `592f10ad-21c4-4b32-8f62-bd848d5c3bde` @ `2026-07-20T11:48:27.662Z`.
- That message supplied numbered text for L670-L688, omitted L669, and instructed: `provide selections for L669-L688 (or No admitted spans in L669-L688)`.
- Assistant response: `e3d2aaba-3c09-4342-8c10-1379c2e1970b` @ `2026-07-20T11:48:34.478Z`.
- Exact response: `No admitted spans in L669-L688.`
- Semantic reason: `NOT RECORDED`.
- Human semantic approval: `NOT RECORDED`.
- Coverage question: L669 was not present in the prompting message.

### L689-L792

- Prompting user message: `592f10ad-21c4-4b32-8f62-bd848d5c3bde` @ `2026-07-20T11:48:27.662Z`.
- Exact requested confirmation: `No admitted spans in L689-L792. Walked through L792; SRC-001 complete.`
- Assistant response: `e3d2aaba-3c09-4342-8c10-1379c2e1970b` @ `2026-07-20T11:48:34.478Z`.
- Exact response: `No admitted spans in L689-L792. Walked through L792; SRC-001 complete.`
- Source text L689-L792 was present in the earlier exact full-source tool node `34efc471-577d-4193-8a77-c032ece0838e`; it was not re-presented in the completion prompt.
- Semantic reason: `NOT RECORDED`.
- Human semantic approval: `NOT RECORDED`.
- Later assistant summaries are navigation aids, not substitutes for a recorded semantic reason or human approval.

## Known Corrections And Concerns

### Duplicate Candidates

- Exact duplicate quote scan across C-001..C-206: `0`.
- Human semantic duplicate decisions: `NOT RECORDED`.
- A preliminary 21-row L1-L78 response exists at `efaf9158-656c-435b-996c-f13d8b45b0c8` @ `2026-07-18T23:18:37.491Z`; the later 25-row response at `2781851f-0e5e-4eb9-b7d4-5bd717e5251f` @ `2026-07-19T09:15:46.806Z` is the set used here. Treat the preliminary set as superseded proposal evidence, not as 21 additional candidates.
- The user message `260421b6-c585-4d7d-84dc-e3ac6317d766` records an operational `no duplicate append` recovery check. That is not a semantic duplicate-candidate judgment.

### Splits And Word-Count Corrections

| original proposal | words | replacement candidates | correction response |
|---|---:|---|---|
| L80-L85 | 74 | C-027, C-028 | `d14892c1-3b57-4bd6-9a0e-63ecb6d67715` @ `2026-07-19T11:42:21.223Z` |
| L104-L107 | 61 | C-034, C-035 | same |
| L110-L114 | 74 | C-037, C-038, C-039 | same |
| L115-L119 | 71 | C-040, C-041 | same |
| L126-L130 | 73 | C-044, C-045 | same |
| L139-L143 | 67 | C-048, C-049 | same |
| L146-L150 | 83 | C-050, C-051 | same |
| L419-L423 | 67 | C-129, C-130 | `6bf679e6-5ac2-4901-980f-5e9c38c5ccef` @ `2026-07-19T13:20:42.694Z` |
| L565-L568 | 61 | C-182, C-183 | `f89e8bdc-56b8-4b13-af97-609c7d85377f` @ `2026-07-19T18:31:37.398Z` |

Mechanical word-count compliance does not establish that the replacements are semantically atomic or sufficiently contextualized.

### Locator And Quote-Containment Corrections

- C-091: `L271-L273` widened to `L271-L274`; the quoted words `from the convolved image` occur on L274.
- C-106: `L302-L302` widened to `L301-L302`; the quoted word `The` occurs at the end of L301.
- No quote text was semantically approved by these corrections; only containment was repaired.

### Possible Over-Broad Candidates

- Assistant message `77894fc7-7ecc-4373-b41a-d78e63a30c3d` @ `2026-07-18T22:11:03.880Z` provisionally warned that the criteria may over-admit hidden-layer sizes, learning rates, worker counts, dataset splits, individual benchmark rows, generic background observations, and CLEVR question-type descriptions.
- Candidate-level mapping and human judgment for that warning: `NOT RECORDED`.
- Review priority: criterion-3 implementation-heavy rows, related-work rows C-146..C-162, and table/result granularity around C-107..C-120. This is a review queue, not a disposition.

### Possible Over-Narrow Candidates

- The same assistant message warned that strict atomicity can detach claims from their evidentiary basis and dependencies. Human acceptance: `NOT RECORDED`.
- Mandatory fragmentation review: C-027/C-028, C-034/C-035, C-037/C-038/C-039, C-040/C-041, C-044/C-045, C-048/C-049, C-050/C-051, C-129/C-130, and C-182/C-183.
- Candidate-level judgments outside those mechanical split groups: `NOT RECORDED`.

### Possible Missing Packets

- Confirmed missing packets: `NONE RECORDED`.
- Human missing-packet audit over candidate-free spans: `NOT RECORDED`.
- Highest-risk unresolved spans: L307-L319 (raw Table 1), L351-L392 (Figure 3 chart extraction), L615-L656 (Figure 4 labels/examples), L663-L688 (Figure/Table 2 examples and caption), and L689-L792 (not re-presented or semantically reasoned at completion).

### Formal-Material Concerns

- Source wrapper warning: `figures/equations may be degraded`.
- Original PDF byte verification and visual reopening: `NOT RECORDED`.
- Candidate rows containing explicit equation/figure/table/function markers: C-007 (L28-L29), C-015 (L56-L60), C-029 (L86-L95), C-030 (L95-L95), C-032 (L98-L100), C-034 (L104-L105), C-040 (L115-L117), C-041 (L117-L119), C-044 (L126-L128), C-047 (L136-L139), C-050 (L146-L148), C-085 (L229-L231), C-088 (L236-L238), C-091 (L271-L274), C-102 (L296-L297), C-103 (L297-L298), C-108 (L321-L322), C-109 (L327-L329), C-120 (L393-L395), C-170 (L532-L534), C-174 (L541-L543), C-183 (L568-L568), C-184 (L569-L570), C-190 (L581-L582), C-200 (L603-L604), C-201 (L604-L606), C-205 (L657-L659).
- The pre-extraction assistant observation proposed stronger handling for equations with symbol definitions, table results with metrics/comparators/conditions, and figures with captions plus interpretive prose. Human acceptance: `NOT RECORDED`; accepted criteria change: `NONE`.

### Provisional Criteria Observations

- Recorded assistant-only proposals: claim role, evidence basis, scope/temporal qualifiers, and claim dependencies.
- Status of every such proposal: `PROVISIONAL; NOT HUMAN-ACCEPTED`.
- Accepted criteria supersession or digest change: `NONE`.

## Candidate Decisions

Replace each `OPEN` only through explicit human review. `Candidate wording` remains `NOT RECORDED` unless the human supplies replacement wording.

### Review Block L1-L78 (C-001-C-025)

| ID | source locator | exact quote (JSON string) | criterion | candidate wording | flags | originating message ID and timestamp | mechanical corrections already applied | disposition | human judgment | reason | replacement or split | missing-packet decision | exclusion rationale |
|---|---|---|---:|---|---|---|---|---|---|---|---|---|---|
| C-001 | L16-L16 | <code>"Relational reasoning is a central component of generally intelligent behavior,"</code> | 1 | NOT RECORDED | UNADJUDICATED | `2781851f-0e5e-4eb9-b7d4-5bd717e5251f` @ `2026-07-19T09:15:46.806Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-002 | L16-L17 | <code>"but has proven\ndiﬃcult for neural networks to learn."</code> | 6 | NOT RECORDED | UNADJUDICATED | `2781851f-0e5e-4eb9-b7d4-5bd717e5251f` @ `2026-07-19T09:15:46.806Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-003 | L17-L19 | <code>"In this paper we describe how to use Relation Networks\n(RNs) as a simple plug-and-play module to solve problems that fundamentally hinge on relational\nreasoning."</code> | 2 | NOT RECORDED | UNADJUDICATED | `2781851f-0e5e-4eb9-b7d4-5bd717e5251f` @ `2026-07-19T09:15:46.806Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-004 | L19-L22 | <code>"We tested RN-augmented networks on three tasks: visual question answering\nusing a challenging dataset called CLEVR, on which we achieve state-of-the-art, super-human\nperformance; text-based question answering using the bAbI suite of tasks; and complex reasoning\nabout dynamic physical systems."</code> | 5 | NOT RECORDED | UNADJUDICATED | `2781851f-0e5e-4eb9-b7d4-5bd717e5251f` @ `2026-07-19T09:15:46.806Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-005 | L22-L24 | <code>"Then, using a curated dataset called Sort-of-CLEVR we show\nthat powerful convolutional networks do not have a general capacity to solve relational questions,\nbut can gain this capacity when augmented with RNs."</code> | 5 | NOT RECORDED | UNADJUDICATED | `2781851f-0e5e-4eb9-b7d4-5bd717e5251f` @ `2026-07-19T09:15:46.806Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-006 | L24-L26 | <code>"Our work shows how a deep learning\narchitecture equipped with an RN module can implicitly discover and learn to reason about\nentities and their relations."</code> | 4 | NOT RECORDED | UNADJUDICATED | `2781851f-0e5e-4eb9-b7d4-5bd717e5251f` @ `2026-07-19T09:15:46.806Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-007 | L28-L29 | <code>"The ability to reason about the relations between entities and their properties is central to generally\nintelligent behavior (Figure 1) [ 18, 15]."</code> | 1 | NOT RECORDED | UNADJUDICATED, formal-material-review | `2781851f-0e5e-4eb9-b7d4-5bd717e5251f` @ `2026-07-19T09:15:46.806Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-008 | L29-L31 | <code>"Consider a child proposing a race between the two trees\nin the park that are furthest apart: the pairwise distances between every tree in the park must be\ninferred and compared to know where to run."</code> | 4 | NOT RECORDED | UNADJUDICATED | `2781851f-0e5e-4eb9-b7d4-5bd717e5251f` @ `2026-07-19T09:15:46.806Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-009 | L31-L33 | <code>"Or, consider a reader piecing together evidence to\npredict the culprit in a murder-mystery novel: each clue must be considered in its broader context to\nbuild a plausible narrative and solve the mystery."</code> | 4 | NOT RECORDED | UNADJUDICATED | `2781851f-0e5e-4eb9-b7d4-5bd717e5251f` @ `2026-07-19T09:15:46.806Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-010 | L34-L34 | <code>"Symbolic approaches to artiﬁcial intelligence are inherently relational [32, 11]."</code> | 1 | NOT RECORDED | UNADJUDICATED | `2781851f-0e5e-4eb9-b7d4-5bd717e5251f` @ `2026-07-19T09:15:46.806Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-011 | L34-L36 | <code>"Practitioners deﬁne\nthe relations between symbols using the language of logic and mathematics, and then reason about\nthese relations using a multitude of powerful methods, including deduction, arithmetic, and algebra."</code> | 2 | NOT RECORDED | UNADJUDICATED | `2781851f-0e5e-4eb9-b7d4-5bd717e5251f` @ `2026-07-19T09:15:46.806Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-012 | L37-L38 | <code>"But symbolic approaches suﬀer from the symbol grounding problem and are not robust to small\ntask and input variations [ 11]."</code> | 6 | NOT RECORDED | UNADJUDICATED | `2781851f-0e5e-4eb9-b7d4-5bd717e5251f` @ `2026-07-19T09:15:46.806Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-013 | L38-L39 | <code>"Other approaches, such as those based on statistical learning, build\nrepresentations from raw data and often generalize across diverse and noisy conditions [ 25]."</code> | 4 | NOT RECORDED | UNADJUDICATED | `2781851f-0e5e-4eb9-b7d4-5bd717e5251f` @ `2026-07-19T09:15:46.806Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-014 | L39-L41 | <code>"However,\na number of these approaches, such as deep learning, often struggle in data-poor problems where the\nunderlying structure is characterized by sparse but complex relations [ 7, 23]."</code> | 6 | NOT RECORDED | UNADJUDICATED | `2781851f-0e5e-4eb9-b7d4-5bd717e5251f` @ `2026-07-19T09:15:46.806Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-015 | L56-L60 | <code>"Figure 1: An illustrative example from the CLEVR dataset of relational reasoning . An\nimage containing four objects is shown alongside non-relational and relational questions. The\nrelational question requires explicit reasoning about the relations between the four objects in the\nimage, whereas the non-relational question requires reasoning about the attributes of a particular\nobject."</code> | 1 | NOT RECORDED | UNADJUDICATED, formal-material-review | `2781851f-0e5e-4eb9-b7d4-5bd717e5251f` @ `2026-07-19T09:15:46.806Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-016 | L63-L64 | <code>"Here, we explore “Relation Networks” (RN) as a general solution to relational reasoning in neural\nnetworks."</code> | 7 | NOT RECORDED | UNADJUDICATED | `2781851f-0e5e-4eb9-b7d4-5bd717e5251f` @ `2026-07-19T09:15:46.806Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-017 | L64-L64 | <code>"RNs are architectures whose computations focus explicitly on relational reasoning [ 35]."</code> | 2 | NOT RECORDED | UNADJUDICATED | `2781851f-0e5e-4eb9-b7d4-5bd717e5251f` @ `2026-07-19T09:15:46.806Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-018 | L65-L67 | <code>"Although several other models supporting relation-centric computation have been proposed, such\nas Graph Neural Networks, Gated Graph Sequence Neural Networks, and Interaction Networks,\n[37, 26, 2], RNs are simple, plug-and-play, and are exclusively focused on ﬂexible relational reasoning."</code> | 2 | NOT RECORDED | UNADJUDICATED | `2781851f-0e5e-4eb9-b7d4-5bd717e5251f` @ `2026-07-19T09:15:46.806Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-019 | L68-L69 | <code>"Moreover, through joint training RNs can inﬂuence and shape upstream representations in CNNs\nand LSTMs to produce implicit object-like representations that it can exploit for relational reasoning."</code> | 4 | NOT RECORDED | UNADJUDICATED | `2781851f-0e5e-4eb9-b7d4-5bd717e5251f` @ `2026-07-19T09:15:46.806Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-020 | L70-L72 | <code>"We applied an RN-augmented architecture to CLEVR [ 15], a recent visual question answering\n(QA) dataset on which state-of-the-art approaches have struggled due to the demand for rich\nrelational reasoning."</code> | 3 | NOT RECORDED | UNADJUDICATED | `2781851f-0e5e-4eb9-b7d4-5bd717e5251f` @ `2026-07-19T09:15:46.806Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-021 | L72-L73 | <code>"Our networks vastly outperformed the best generally-applicable visual QA\narchitectures, and achieve state-of-the-art, super-human performance."</code> | 5 | NOT RECORDED | UNADJUDICATED | `2781851f-0e5e-4eb9-b7d4-5bd717e5251f` @ `2026-07-19T09:15:46.806Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-022 | L73-L74 | <code>"RNs also solve CLEVR from\nstate descriptions, highlighting their versatility in regards to the form of their input."</code> | 5 | NOT RECORDED | UNADJUDICATED | `2781851f-0e5e-4eb9-b7d4-5bd717e5251f` @ `2026-07-19T09:15:46.806Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-023 | L74-L75 | <code>"We also applied\nan RN-based architecture to the bAbI text-based QA suite [ 41] and solved 18/20 of the subtasks."</code> | 5 | NOT RECORDED | UNADJUDICATED | `2781851f-0e5e-4eb9-b7d4-5bd717e5251f` @ `2026-07-19T09:15:46.806Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-024 | L76-L77 | <code>"Finally, we trained an RN to make challenging relational inferences about complex physical systems\nand motion capture data."</code> | 3 | NOT RECORDED | UNADJUDICATED | `2781851f-0e5e-4eb9-b7d4-5bd717e5251f` @ `2026-07-19T09:15:46.806Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-025 | L77-L78 | <code>"The success of RNs across this set of substantially dissimilar task domains\nis testament to the general utility of RNs for solving problems that require relation reasoning."</code> | 4 | NOT RECORDED | UNADJUDICATED | `2781851f-0e5e-4eb9-b7d4-5bd717e5251f` @ `2026-07-19T09:15:46.806Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |

### Review Block L79-L156 (C-026-C-053)

| ID | source locator | exact quote (JSON string) | criterion | candidate wording | flags | originating message ID and timestamp | mechanical corrections already applied | disposition | human judgment | reason | replacement or split | missing-packet decision | exclusion rationale |
|---|---|---|---:|---|---|---|---|---|---|---|---|---|---|
| C-026 | L80-L80 | <code>"An RN is a neural network module with a structure primed for relational reasoning."</code> | 1 | NOT RECORDED | UNADJUDICATED | `5bccd9a7-a1ed-4f7d-b52b-1222db868035` @ `2026-07-19T10:12:21.211Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-027 | L80-L82 | <code>"The design\nphilosophy behind RNs is to constrain the functional form of a neural network so that it captures the\ncore common properties of relational reasoning."</code> | 4 | NOT RECORDED | UNADJUDICATED, word-count-correction, split | `d14892c1-3b57-4bd6-9a0e-63ecb6d67715` @ `2026-07-19T11:42:21.223Z` | Replaces L80-L85 (74 words) from message 5bccd9a7-a1ed-4f7d-b52b-1222db868035 with two rows. | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-028 | L82-L85 | <code>"In other words, the capacity to compute relations\nis baked into the RN architecture without needing to be learned, just as the capacity to reason\nabout spatial, translation invariant properties is built-in to CNNs, and the capacity to reason about\nsequential dependencies is built into recurrent neural networks."</code> | 4 | NOT RECORDED | UNADJUDICATED, word-count-correction, split | `d14892c1-3b57-4bd6-9a0e-63ecb6d67715` @ `2026-07-19T11:42:21.223Z` | Replaces L80-L85 (74 words) from message 5bccd9a7-a1ed-4f7d-b52b-1222db868035 with two rows. | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-029 | L86-L95 | <code>"In its simplest form the RN is a composite function:\nRN(O) =fφ\n\n∑\ni,j\ngθ(oi,oj)\n\n, (1)\nwhere the input is a set of “objects” O ={o1,o 2,...,o n}, oi∈ Rm is the ith object, and fφ and gθ\nare functions with parameters φ and θ, respectively."</code> | 2 | NOT RECORDED | UNADJUDICATED, formal-material-review | `5bccd9a7-a1ed-4f7d-b52b-1222db868035` @ `2026-07-19T10:12:21.211Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-030 | L95-L95 | <code>"For our purposes, fφ and gθ are MLPs"</code> | 2 | NOT RECORDED | UNADJUDICATED, formal-material-review | `5bccd9a7-a1ed-4f7d-b52b-1222db868035` @ `2026-07-19T10:12:21.211Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-031 | L98-L98 | <code>"parameters are learnable synaptic weights, making RNs end-to-end diﬀerentiable."</code> | 2 | NOT RECORDED | UNADJUDICATED | `5bccd9a7-a1ed-4f7d-b52b-1222db868035` @ `2026-07-19T10:12:21.211Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-032 | L98-L100 | <code>"We call the output\nof gθ a “relation”; therefore, the role of gθ is to infer the ways in which two objects are related, or if\nthey are even related at all."</code> | 1 | NOT RECORDED | UNADJUDICATED, formal-material-review | `5bccd9a7-a1ed-4f7d-b52b-1222db868035` @ `2026-07-19T10:12:21.211Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-033 | L101-L103 | <code>"RNs have three notable strengths: they learn to infer relations, they are data eﬃcient, and they\noperate on a set of objects – a particularly general and versatile input format – in a manner that is\norder invariant."</code> | 1 | NOT RECORDED | UNADJUDICATED | `5bccd9a7-a1ed-4f7d-b52b-1222db868035` @ `2026-07-19T10:12:21.211Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-034 | L104-L105 | <code>"RNs learn to infer relations The functional form in Equation 1 dictates that an RN should\nconsider the potential relations between all object pairs."</code> | 2 | NOT RECORDED | UNADJUDICATED, word-count-correction, split, formal-material-review | `d14892c1-3b57-4bd6-9a0e-63ecb6d67715` @ `2026-07-19T11:42:21.223Z` | Replaces L104-L107 (61 words) from message 5bccd9a7-a1ed-4f7d-b52b-1222db868035 with two rows. | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-035 | L105-L107 | <code>"This implies that an RN is not necessarily\nprivy to which object relations actually exist, nor to the actual meaning of any particular relation.\nThus, RNs must learn to infer the existence and implications of object relations."</code> | 2 | NOT RECORDED | UNADJUDICATED, word-count-correction, split | `d14892c1-3b57-4bd6-9a0e-63ecb6d67715` @ `2026-07-19T11:42:21.223Z` | Replaces L104-L107 (61 words) from message 5bccd9a7-a1ed-4f7d-b52b-1222db868035 with two rows. | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-036 | L108-L109 | <code>"In graph theory parlance, the input can be thought of as a complete and directed graph whose\nnodes are objects and whose edges denote the object pairs whose relations should be considered."</code> | 2 | NOT RECORDED | UNADJUDICATED | `5bccd9a7-a1ed-4f7d-b52b-1222db868035` @ `2026-07-19T10:12:21.211Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-037 | L110-L111 | <code>"Although we focus on this “all-to-all” version of the RN throughout this paper, this RN deﬁnition\ncan be adjusted to consider only some object pairs."</code> | 7 | NOT RECORDED | UNADJUDICATED, word-count-correction, split | `d14892c1-3b57-4bd6-9a0e-63ecb6d67715` @ `2026-07-19T11:42:21.223Z` | Replaces L110-L114 (74 words) from message 5bccd9a7-a1ed-4f7d-b52b-1222db868035 with three rows. | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-038 | L111-L113 | <code>"Similar to Interaction Networks [ 2], to which\nRNs are related, RNs can take as input a list of only those pairs that should be considered, if this\ninformation is available."</code> | 7 | NOT RECORDED | UNADJUDICATED, word-count-correction, split | `d14892c1-3b57-4bd6-9a0e-63ecb6d67715` @ `2026-07-19T11:42:21.223Z` | Replaces L110-L114 (74 words) from message 5bccd9a7-a1ed-4f7d-b52b-1222db868035 with three rows. | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-039 | L113-L114 | <code>"This information could be explicit in the input data, or could perhaps be\nextracted by some upstream mechanism."</code> | 7 | NOT RECORDED | UNADJUDICATED, word-count-correction, split | `d14892c1-3b57-4bd6-9a0e-63ecb6d67715` @ `2026-07-19T11:42:21.223Z` | Replaces L110-L114 (74 words) from message 5bccd9a7-a1ed-4f7d-b52b-1222db868035 with three rows. | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-040 | L115-L117 | <code>"RNs are data eﬃcient RNs use a single function gθ to compute each relation. This can be\nthought of as a single function operating on a batch of object pairs, where each member of the\nbatch is a particular object-object pair from the same object set."</code> | 2 | NOT RECORDED | UNADJUDICATED, word-count-correction, split, formal-material-review | `d14892c1-3b57-4bd6-9a0e-63ecb6d67715` @ `2026-07-19T11:42:21.223Z` | Replaces L115-L119 (71 words) from message 5bccd9a7-a1ed-4f7d-b52b-1222db868035 with two rows. | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-041 | L117-L119 | <code>"This mode of operation encourages\ngreater generalization for computing relations, since gθ is encouraged not to over-ﬁt to the features\nof any particular object pair."</code> | 4 | NOT RECORDED | UNADJUDICATED, word-count-correction, split, formal-material-review | `d14892c1-3b57-4bd6-9a0e-63ecb6d67715` @ `2026-07-19T11:42:21.223Z` | Replaces L115-L119 (71 words) from message 5bccd9a7-a1ed-4f7d-b52b-1222db868035 with two rows. | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-042 | L119-L122 | <code>"Consider how an MLP would learn the same function. An MLP would\nreceive all objects from the object set simultaneously as its input. It must then learn and embed n2\n(where n is the number of objects) identical functions within its weight parameters to account for all\npossible object pairings. This quickly becomes intractable as the number of objects grows."</code> | 6 | NOT RECORDED | UNADJUDICATED | `5bccd9a7-a1ed-4f7d-b52b-1222db868035` @ `2026-07-19T10:12:21.211Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-043 | L122-L125 | <code>"Therefore,\nthe cost of learning a relation function n2 times using a single feedforward pass per sample, as in an\nMLP, is replaced by the cost of n2 feedforward passes per object set (i.e., for each possible object\npair in the set) and learning a relation function just once, as in an RN."</code> | 4 | NOT RECORDED | UNADJUDICATED | `5bccd9a7-a1ed-4f7d-b52b-1222db868035` @ `2026-07-19T10:12:21.211Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-044 | L126-L128 | <code>"RNs operate on a set of objects The summation in Equation 1 ensures that the RN is invariant\nto the order of objects in the input. This invariance ensures that the RN’s input respects the property\nthat sets are order invariant, and it ensures that the output is order invariant."</code> | 4 | NOT RECORDED | UNADJUDICATED, word-count-correction, split, formal-material-review | `d14892c1-3b57-4bd6-9a0e-63ecb6d67715` @ `2026-07-19T11:42:21.223Z` | Replaces L126-L130 (73 words) from message 5bccd9a7-a1ed-4f7d-b52b-1222db868035 with two rows. | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-045 | L128-L130 | <code>"Ultimately, this\ninvariance ensures that the RN’s output contains information that is generally representative of the\nrelations that exist in the object set."</code> | 4 | NOT RECORDED | UNADJUDICATED, word-count-correction, split | `d14892c1-3b57-4bd6-9a0e-63ecb6d67715` @ `2026-07-19T11:42:21.223Z` | Replaces L126-L130 (73 words) from message 5bccd9a7-a1ed-4f7d-b52b-1222db868035 with two rows. | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-046 | L132-L134 | <code>"We applied RN-augmented networks to a variety of tasks that hinge on relational reasoning. To\ndemonstrate the versatility of these networks we chose tasks from a number of diﬀerent domains,\nincluding visual QA, text-based QA, and dynamic physical systems."</code> | 3 | NOT RECORDED | UNADJUDICATED | `5bccd9a7-a1ed-4f7d-b52b-1222db868035` @ `2026-07-19T10:12:21.211Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-047 | L136-L139 | <code>"In visual QA a model must learn to answer questions about an image (Figure 1). This is a challenging\nproblem domain because it requires high-level scene understanding [1, 29]. Architectures must perform\ncomplex relational reasoning – spatial and otherwise – over the features in the visual inputs, language\ninputs, and their conjunction."</code> | 2 | NOT RECORDED | UNADJUDICATED, formal-material-review | `5bccd9a7-a1ed-4f7d-b52b-1222db868035` @ `2026-07-19T10:12:21.211Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-048 | L139-L141 | <code>"However, the majority of visual QA datasets require reasoning in the\nabsence of fully speciﬁed word vocabularies, and perhaps more perniciously, a vast and complicated\nknowledge of the world that is not available in the training data."</code> | 6 | NOT RECORDED | UNADJUDICATED, word-count-correction, split | `d14892c1-3b57-4bd6-9a0e-63ecb6d67715` @ `2026-07-19T11:42:21.223Z` | Replaces L139-L143 (67 words) from message 5bccd9a7-a1ed-4f7d-b52b-1222db868035 with two rows. | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-049 | L141-L143 | <code>"They also contain ambiguities and\nexhibit strong linguistic biases that allow a model to learn answering strategies that exploit those\nbiases, without reasoning about the visual input [1, 31, 36]."</code> | 6 | NOT RECORDED | UNADJUDICATED, word-count-correction, split | `d14892c1-3b57-4bd6-9a0e-63ecb6d67715` @ `2026-07-19T11:42:21.223Z` | Replaces L139-L143 (67 words) from message 5bccd9a7-a1ed-4f7d-b52b-1222db868035 with two rows. | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-050 | L146-L148 | <code>"To control for these issues, and to distill the core challenges of visual QA, the CLEVR visual QA\ndataset was developed [ 15]. CLEVR contains images of 3D-rendered objects, such as spheres and\ncylinders (Figure 2)."</code> | 3 | NOT RECORDED | UNADJUDICATED, word-count-correction, split, formal-material-review | `d14892c1-3b57-4bd6-9a0e-63ecb6d67715` @ `2026-07-19T11:42:21.223Z` | Replaces L146-L150 (83 words) from message 5bccd9a7-a1ed-4f7d-b52b-1222db868035 with two rows. | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-051 | L148-L150 | <code>"Each image is associated with a number of questions that fall into diﬀerent\ncategories. For example, query attribute questions may ask “ What is the color of the sphere? ”,\nwhile compare attribute questions may ask “ Is the cube the same material as the cylinder? ”."</code> | 3 | NOT RECORDED | UNADJUDICATED, word-count-correction, split | `d14892c1-3b57-4bd6-9a0e-63ecb6d67715` @ `2026-07-19T11:42:21.223Z` | Replaces L146-L150 (83 words) from message 5bccd9a7-a1ed-4f7d-b52b-1222db868035 with two rows. | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-052 | L151-L153 | <code>"For our purposes, an important feature of CLEVR is that many questions are explicitly relational\nin nature. Remarkably, powerful QA architectures [ 46] are unable to solve CLEVR, presumably\nbecause they cannot handle core relational aspects of the task."</code> | 5 | NOT RECORDED | UNADJUDICATED | `5bccd9a7-a1ed-4f7d-b52b-1222db868035` @ `2026-07-19T10:12:21.211Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-053 | L153-L156 | <code>"For example, as reported in the\noriginal paper a model comprised of ResNet-101 image embeddings with LSTM question processing\nand augmented with stacked attention modules vastly outperformed other models at an overall\nperformance of 68.5% (compared to 52.3% for the next best, and 92 .6% human performance) [ 15]."</code> | 5 | NOT RECORDED | UNADJUDICATED | `5bccd9a7-a1ed-4f7d-b52b-1222db868035` @ `2026-07-19T10:12:21.211Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |

### Review Block L157-L234 (C-054-C-086)

| ID | source locator | exact quote (JSON string) | criterion | candidate wording | flags | originating message ID and timestamp | mechanical corrections already applied | disposition | human judgment | reason | replacement or split | missing-packet decision | exclusion rationale |
|---|---|---|---:|---|---|---|---|---|---|---|---|---|---|
| C-054 | L157-L160 | <code>"However, for compare attribute and count questions (i.e., questions heavily involving relations\nacross objects), the model performed little better than the simplest baseline, which answered questions\nsolely based on the probability of answers in the training set for a given question category (Q-type\nbaseline)."</code> | 5 | NOT RECORDED | UNADJUDICATED | `7ea78694-7e00-4d06-9a8c-fba190d0c11f` @ `2026-07-19T12:48:15.910Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-055 | L161-L163 | <code>"We used two versions of the CLEVR dataset: (i) the pixel version, in which images were\nrepresented in standard 2D pixel form, and (ii) a state description version, in which images were\nexplicitly represented by state description matrices containing factored object descriptions."</code> | 3 | NOT RECORDED | UNADJUDICATED | `7ea78694-7e00-4d06-9a8c-fba190d0c11f` @ `2026-07-19T12:48:15.910Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-056 | L163-L165 | <code>"Each\nrow in the matrix contained the features of a single object – 3D coordinates (x, y, z); color (r, g,\nb); shape (cube, cylinder, etc.); material (rubber, metal, etc.); size (small, large, etc.)."</code> | 3 | NOT RECORDED | UNADJUDICATED | `7ea78694-7e00-4d06-9a8c-fba190d0c11f` @ `2026-07-19T12:48:15.910Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-057 | L165-L167 | <code>"When we\ntrained our models, we used either the pixel version or the state description version, depending on\nthe experiment, but not both together."</code> | 3 | NOT RECORDED | UNADJUDICATED | `7ea78694-7e00-4d06-9a8c-fba190d0c11f` @ `2026-07-19T12:48:15.910Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-058 | L169-L171 | <code>"To explore our hypothesis that the RN architecture is better suited to general relational reasoning as\ncompared to more standard neural architectures, we constructed a dataset similar to CLEVR that\nwe call “Sort-of-CLEVR” 1. This dataset separates relational and non-relational questions."</code> | 3 | NOT RECORDED | UNADJUDICATED | `7ea78694-7e00-4d06-9a8c-fba190d0c11f` @ `2026-07-19T12:48:15.910Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-059 | L172-L175 | <code>"Sort-of-CLEVR consists of images of 2D colored shapes along with questions and answers about\nthe images. Each image has a total of 6 objects, where each object is a randomly chosen shape\n(square or circle). We used 6 colors (red, blue, green, orange, yellow, gray) to unambiguously identify\neach object."</code> | 3 | NOT RECORDED | UNADJUDICATED | `7ea78694-7e00-4d06-9a8c-fba190d0c11f` @ `2026-07-19T12:48:15.910Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-060 | L175-L177 | <code>"Questions are hard-coded as ﬁxed-length binary strings to reduce the diﬃculty involved\nwith natural language question-word processing, and thereby remove any confounding diﬃculty\nwith language parsing."</code> | 4 | NOT RECORDED | UNADJUDICATED | `7ea78694-7e00-4d06-9a8c-fba190d0c11f` @ `2026-07-19T12:48:15.910Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-061 | L177-L178 | <code>"For each image we generated 10 relational questions and 10 non-relational\nquestions."</code> | 3 | NOT RECORDED | UNADJUDICATED | `7ea78694-7e00-4d06-9a8c-fba190d0c11f` @ `2026-07-19T12:48:15.910Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-062 | L178-L179 | <code>"Examples of relational questions are: “ What is the shape of the object that is farthest from\nthe gray object? ”; and “How many objects have the same shape as the green object? ”."</code> | 3 | NOT RECORDED | UNADJUDICATED | `7ea78694-7e00-4d06-9a8c-fba190d0c11f` @ `2026-07-19T12:48:15.910Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-063 | L179-L181 | <code>"Examples of\nnon-relational questions are: “What is the shape of the gray object?”; and “ Is the blue object on the\ntop or bottom of the scene? ”."</code> | 3 | NOT RECORDED | UNADJUDICATED | `7ea78694-7e00-4d06-9a8c-fba190d0c11f` @ `2026-07-19T12:48:15.910Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-064 | L181-L182 | <code>"The dataset is also visually simple, reducing complexities involved in\nimage processing."</code> | 4 | NOT RECORDED | UNADJUDICATED | `7ea78694-7e00-4d06-9a8c-fba190d0c11f` @ `2026-07-19T12:48:15.910Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-065 | L184-L185 | <code>"bAbI is a pure text-based QA dataset [ 41]. There are 20 tasks, each corresponding to a particular\ntype of reasoning, such as deduction, induction, or counting."</code> | 1 | NOT RECORDED | UNADJUDICATED | `7ea78694-7e00-4d06-9a8c-fba190d0c11f` @ `2026-07-19T12:48:15.910Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-066 | L185-L187 | <code>"Each question is associated with a set\nof supporting facts. For example, the facts “ Sandra picked up the football ” and “ Sandra went to\nthe oﬃce” support the question “ Where is the football? ” (answer: “ oﬃce”)."</code> | 1 | NOT RECORDED | UNADJUDICATED | `7ea78694-7e00-4d06-9a8c-fba190d0c11f` @ `2026-07-19T12:48:15.910Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-067 | L187-L188 | <code>"A model succeeds on\na task if its performance surpasses 95%."</code> | 5 | NOT RECORDED | UNADJUDICATED | `7ea78694-7e00-4d06-9a8c-fba190d0c11f` @ `2026-07-19T12:48:15.910Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-068 | L188-L189 | <code>"Many memory-augmented neural networks have reported\nimpressive results on bAbI."</code> | 5 | NOT RECORDED | UNADJUDICATED | `7ea78694-7e00-4d06-9a8c-fba190d0c11f` @ `2026-07-19T12:48:15.910Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-069 | L189-L192 | <code>"When training jointly on all tasks using 10 K examples per task, Memory\nNetworks pass 14/20, DNC 18/20, Sparse DNC 19/20, and EntNet 16/20 (the authors of EntNets\nreport state-of-the-art at 20/20; however, unlike previously reported results this was not done with\njoint training on all tasks, where they instead achieve 16 /20) [42, 9, 34, 13]."</code> | 5 | NOT RECORDED | UNADJUDICATED | `7ea78694-7e00-4d06-9a8c-fba190d0c11f` @ `2026-07-19T12:48:15.910Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-070 | L193-L193 | <code>"The “Sort-of-CLEVR” dataset will be made publicly available online."</code> | 7 | NOT RECORDED | UNADJUDICATED | `7ea78694-7e00-4d06-9a8c-fba190d0c11f` @ `2026-07-19T12:48:15.910Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-071 | L197-L199 | <code>"We developed a dataset of simulated physical mass-spring systems using the MuJoCo physics engine\n[40]. Each scene contained 10 colored balls moving on a table-top surface. Some of the balls moved\nindependently, free to collide with other balls and the barrier walls."</code> | 3 | NOT RECORDED | UNADJUDICATED | `7ea78694-7e00-4d06-9a8c-fba190d0c11f` @ `2026-07-19T12:48:15.910Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-072 | L199-L201 | <code>"Other randomly selected ball\npairs were connected by invisible springs or a rigid constraint. These connections prevented the\nballs from moving independently, due to the force imposed through the connections."</code> | 3 | NOT RECORDED | UNADJUDICATED | `7ea78694-7e00-4d06-9a8c-fba190d0c11f` @ `2026-07-19T12:48:15.910Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-073 | L201-L204 | <code>"Input data\nconsisted of state descriptions matrices, where each ball was represented as a row in a matrix with\nfeatures representing the RGB color values of each object and their spatial coordinates ( x,y ) across\n16 sequential time steps."</code> | 3 | NOT RECORDED | UNADJUDICATED | `7ea78694-7e00-4d06-9a8c-fba190d0c11f` @ `2026-07-19T12:48:15.910Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-074 | L205-L207 | <code>"The introduction of random links between balls created an evolving physical system with a\nvariable number “systems” of connected balls (where “systems” refers to connected graphs with\nballs as nodes and connections between balls as edges)."</code> | 3 | NOT RECORDED | UNADJUDICATED | `7ea78694-7e00-4d06-9a8c-fba190d0c11f` @ `2026-07-19T12:48:15.910Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-075 | L207-L210 | <code>"We deﬁned two separate tasks: 1) infer the\nexistence or absence of connections between balls when only observing their color and coordinate\npositions across multiple sequential frames, and 2) count the number of systems on the table-top,\nagain when only observing each ball’s color and coordinate position across multiple sequential frames."</code> | 3 | NOT RECORDED | UNADJUDICATED | `7ea78694-7e00-4d06-9a8c-fba190d0c11f` @ `2026-07-19T12:48:15.910Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-076 | L211-L213 | <code>"Both of these tasks involve reasoning about the relative positions and velocities of the balls to\ninfer whether they are moving independently, or whether their movement is somehow dependent on\nthe movement of other balls through invisible connections."</code> | 4 | NOT RECORDED | UNADJUDICATED | `7ea78694-7e00-4d06-9a8c-fba190d0c11f` @ `2026-07-19T12:48:15.910Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-077 | L213-L214 | <code>"For example, if the distance between two\nballs remains similar across frames, then it can be inferred that there is a connection between them."</code> | 4 | NOT RECORDED | UNADJUDICATED | `7ea78694-7e00-4d06-9a8c-fba190d0c11f` @ `2026-07-19T12:48:15.910Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-078 | L215-L216 | <code>"The ﬁrst task makes these inferences explicit, while the second task demands that this reasoning\noccur implicitly, which is much more diﬃcult."</code> | 6 | NOT RECORDED | UNADJUDICATED | `7ea78694-7e00-4d06-9a8c-fba190d0c11f` @ `2026-07-19T12:48:15.910Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-079 | L219-L220 | <code>"In their simplest form RNs operate on objects, and hence do not explicitly operate on images or\nnatural language."</code> | 2 | NOT RECORDED | UNADJUDICATED | `7ea78694-7e00-4d06-9a8c-fba190d0c11f` @ `2026-07-19T12:48:15.910Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-080 | L220-L222 | <code>"A central contribution of this work is to demonstrate the ﬂexibility with which\nrelatively unstructured inputs, such as CNN or LSTM embeddings, can be considered as a set of\nobjects for an RN."</code> | 2 | NOT RECORDED | UNADJUDICATED | `7ea78694-7e00-4d06-9a8c-fba190d0c11f` @ `2026-07-19T12:48:15.910Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-081 | L222-L223 | <code>"Although the RN expects object representations as input, the semantics of what\nan object is need not be speciﬁed."</code> | 6 | NOT RECORDED | UNADJUDICATED | `7ea78694-7e00-4d06-9a8c-fba190d0c11f` @ `2026-07-19T12:48:15.910Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-082 | L223-L225 | <code>"Our results below demonstrate that the learning process induces\nupstream processing, comprised of conventional neural network modules, to produce a set of useful\n“objects” from distributed representations."</code> | 4 | NOT RECORDED | UNADJUDICATED | `7ea78694-7e00-4d06-9a8c-fba190d0c11f` @ `2026-07-19T12:48:15.910Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-083 | L226-L228 | <code>"Dealing with pixels We used a CNN to parse pixel inputs into a set of objects. The CNN took\nimages of size 128× 128 and convolved them through four convolutional layers to k feature maps of\nsize d×d, where k is the number of kernels in the ﬁnal convolutional layer."</code> | 3 | NOT RECORDED | UNADJUDICATED | `7ea78694-7e00-4d06-9a8c-fba190d0c11f` @ `2026-07-19T12:48:15.910Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-084 | L228-L229 | <code>"We remained agnostic\nas to what particular image features should constitute an object."</code> | 6 | NOT RECORDED | UNADJUDICATED | `7ea78694-7e00-4d06-9a8c-fba190d0c11f` @ `2026-07-19T12:48:15.910Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-085 | L229-L231 | <code>"So, after convolving the image,\neach of the d2 k-dimensional cells in the d×d feature maps was tagged with an arbitrary coordinate\nindicating its relative spatial position, and was treated as an object for the RN (see Figure 2)."</code> | 3 | NOT RECORDED | UNADJUDICATED, formal-material-review | `7ea78694-7e00-4d06-9a8c-fba190d0c11f` @ `2026-07-19T12:48:15.910Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-086 | L231-L233 | <code>"This\nmeans that an “object” could comprise the background, a particular physical object, a texture,\nconjunctions of physical objects, etc., which aﬀords the model great ﬂexibility in the learning process."</code> | 4 | NOT RECORDED | UNADJUDICATED | `7ea78694-7e00-4d06-9a8c-fba190d0c11f` @ `2026-07-19T12:48:15.910Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |

### Review Block L235-L312 (C-087-C-106)

| ID | source locator | exact quote (JSON string) | criterion | candidate wording | flags | originating message ID and timestamp | mechanical corrections already applied | disposition | human judgment | reason | replacement or split | missing-packet decision | exclusion rationale |
|---|---|---|---:|---|---|---|---|---|---|---|---|---|---|
| C-087 | L235-L236 | <code>"relation should be question dependent. For example, if a question asks about a large sphere, then\nthe relations between small cubes are probably irrelevant."</code> | 4 | NOT RECORDED | UNADJUDICATED | `389c039d-6aa5-4900-8a30-5439d1e9effe` @ `2026-07-19T12:56:14.928Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-088 | L236-L238 | <code>"So, we modiﬁed the RN architecture such\nthat gθ could condition its processing on the question: a =fφ(∑\ni,jgθ(oi,oj,q ))."</code> | 3 | NOT RECORDED | UNADJUDICATED, formal-material-review | `389c039d-6aa5-4900-8a30-5439d1e9effe` @ `2026-07-19T12:56:14.928Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-089 | L238-L241 | <code>"To get the question\nembedding q, we used the ﬁnal state of an LSTM that processed question words. Question words\nwere assigned unique integers, which were then used to index a learnable lookup table that provided\nembeddings to the LSTM."</code> | 3 | NOT RECORDED | UNADJUDICATED | `389c039d-6aa5-4900-8a30-5439d1e9effe` @ `2026-07-19T12:56:14.928Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-090 | L241-L242 | <code>"At each time-step, the LSTM received a single word embedding as input,\naccording to the syntax of the English-encoded question."</code> | 3 | NOT RECORDED | UNADJUDICATED | `389c039d-6aa5-4900-8a30-5439d1e9effe` @ `2026-07-19T12:56:14.928Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-091 | L271-L274 | <code>"Figure 2: Visual QA architecture. Questions are processed with an LSTM to produce a question\nembedding, and images are processed with a CNN to produce a set of objects for the RN. Objects\n(three examples illustrated here in yellow, red, and blue) are constructed using feature-map vectors\nfrom the convolved image."</code> | 2 | NOT RECORDED | UNADJUDICATED, locator-correction, quote-containment-correction, formal-material-review | `726752ed-81b4-4ac7-a94a-a077bbe1cc80` @ `2026-07-19T13:05:13.783Z` | Locator widened from L271-L273 to L271-L274 because "from the convolved image" occurs on L274; original message 389c039d-6aa5-4900-8a30-5439d1e9effe. | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-092 | L274-L275 | <code>"The RN considers relations across all pairs of objects, conditioned on the\nquestion embedding, and integrates all these relations to answer the question."</code> | 2 | NOT RECORDED | UNADJUDICATED | `389c039d-6aa5-4900-8a30-5439d1e9effe` @ `2026-07-19T12:56:14.928Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-093 | L276-L279 | <code>"Dealing with state descriptions We can provide state descriptions directly into the RN, since\nstate descriptions are pre-factored object representations. Question processing can proceed as before:\nquestions pass through an LSTM using a learnable lookup embedding for individual words, and the\nﬁnal state of the LSTM is concatenated to each object-pair."</code> | 3 | NOT RECORDED | UNADJUDICATED | `389c039d-6aa5-4900-8a30-5439d1e9effe` @ `2026-07-19T12:56:14.928Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-094 | L280-L282 | <code>"Dealing with natural language For the bAbI suite of tasks the natural language inputs must\nbe transformed into a set of objects. This is a distinctly diﬀerent requirement from visual QA, where\nobjects were deﬁned as spatially distinct regions in convolved feature maps."</code> | 2 | NOT RECORDED | UNADJUDICATED | `389c039d-6aa5-4900-8a30-5439d1e9effe` @ `2026-07-19T12:56:14.928Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-095 | L282-L285 | <code>"So, we ﬁrst identiﬁed up\nto 20 sentences in the support set that were immediately prior to the probe question. Then, we tagged\nthese sentences with labels indicating their relative position in the support set, and processed each\nsentence word-by-word with an LSTM (with the same LSTM acting on each sentence independently)."</code> | 3 | NOT RECORDED | UNADJUDICATED | `389c039d-6aa5-4900-8a30-5439d1e9effe` @ `2026-07-19T12:56:14.928Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-096 | L286-L287 | <code>"We note that this setup invokes minimal prior knowledge, in that we delineate objects as sentences,\nwhereas previous bAbI models processed all word tokens from all support sentences sequentially."</code> | 6 | NOT RECORDED | UNADJUDICATED | `389c039d-6aa5-4900-8a30-5439d1e9effe` @ `2026-07-19T12:56:14.928Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-097 | L288-L289 | <code>"It’s unclear how much of an advantage this prior knowledge provides, since period punctuation also\nunambiguously delineates sentences for the token-by-token processing models."</code> | 6 | NOT RECORDED | UNADJUDICATED | `389c039d-6aa5-4900-8a30-5439d1e9effe` @ `2026-07-19T12:56:14.928Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-098 | L289-L290 | <code>"The ﬁnal state of the\nsentence-processing-LSTM is considered to be an object."</code> | 2 | NOT RECORDED | UNADJUDICATED | `389c039d-6aa5-4900-8a30-5439d1e9effe` @ `2026-07-19T12:56:14.928Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-099 | L290-L291 | <code>"Similar to visual QA, a separate LSTM\nproduced a question embedding, which was appened to each object pair as input to the RN."</code> | 3 | NOT RECORDED | UNADJUDICATED | `389c039d-6aa5-4900-8a30-5439d1e9effe` @ `2026-07-19T12:56:14.928Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-100 | L291-L293 | <code>"Our\nmodel was trained on the joint version of bAbI (all 20 tasks simultaneously), using the full dataset of\n10K examples per task."</code> | 3 | NOT RECORDED | UNADJUDICATED | `389c039d-6aa5-4900-8a30-5439d1e9effe` @ `2026-07-19T12:56:14.928Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-101 | L294-L296 | <code>"Model conﬁguration details For the CLEVR-from-pixels task we used: 4 convolutional layers\neach with 24 kernels, ReLU non-linearities, and batch normalization; 128 unit LSTM for question\nprocessing; 32 unit word-lookup embeddings;"</code> | 3 | NOT RECORDED | UNADJUDICATED | `389c039d-6aa5-4900-8a30-5439d1e9effe` @ `2026-07-19T12:56:14.928Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-102 | L296-L297 | <code>"four-layer MLP consisting of 256 units per layer with\nReLU non-linearities for gθ;"</code> | 3 | NOT RECORDED | UNADJUDICATED, formal-material-review | `389c039d-6aa5-4900-8a30-5439d1e9effe` @ `2026-07-19T12:56:14.928Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-103 | L297-L298 | <code>"and a three-layer MLP consisting of 256, 256 (with 50% dropout), and\n29 units with ReLU non-linearities for fφ."</code> | 3 | NOT RECORDED | UNADJUDICATED, formal-material-review | `389c039d-6aa5-4900-8a30-5439d1e9effe` @ `2026-07-19T12:56:14.928Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-104 | L298-L300 | <code>"The ﬁnal layer was a linear layer that produced logits\nfor a softmax over the answer vocabulary. The softmax output was optimized with a cross-entropy\nloss function using the Adam optimizer with a learning rate of 2 .5e−4."</code> | 3 | NOT RECORDED | UNADJUDICATED | `389c039d-6aa5-4900-8a30-5439d1e9effe` @ `2026-07-19T12:56:14.928Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-105 | L300-L301 | <code>"We used size 64 mini-batches\nand distributed training with 10 workers synchronously updating a central parameter server."</code> | 3 | NOT RECORDED | UNADJUDICATED | `389c039d-6aa5-4900-8a30-5439d1e9effe` @ `2026-07-19T12:56:14.928Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-106 | L301-L302 | <code>"The\nconﬁgurations for the other tasks are similar, and can be found in the supplementary information."</code> | 3 | NOT RECORDED | UNADJUDICATED, locator-correction, quote-containment-correction | `726752ed-81b4-4ac7-a94a-a077bbe1cc80` @ `2026-07-19T13:05:13.783Z` | Locator widened from L302-L302 to L301-L302 because "The" occurs at the end of L301; original message 389c039d-6aa5-4900-8a30-5439d1e9effe. | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |

### Review Block L313-L390 (C-107-C-119)

| ID | source locator | exact quote (JSON string) | criterion | candidate wording | flags | originating message ID and timestamp | mechanical corrections already applied | disposition | human judgment | reason | replacement or split | missing-packet decision | exclusion rationale |
|---|---|---|---:|---|---|---|---|---|---|---|---|---|---|
| C-107 | L320-L320 | <code>"* Our implementation, with optimized hyperparameters and trained fully end-to-end."</code> | 3 | NOT RECORDED | UNADJUDICATED | `f4c5b574-d651-4dd6-8ef2-0d376536f010` @ `2026-07-19T13:13:57.597Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-108 | L321-L322 | <code>"Table 1: Results on CLEVR from pixels. Performances of our model (RN) and previously\nreported models [16], measured as accuracy on the test set and broken down by question category."</code> | 5 | NOT RECORDED | UNADJUDICATED, formal-material-review | `f4c5b574-d651-4dd6-8ef2-0d376536f010` @ `2026-07-19T13:13:57.597Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-109 | L327-L329 | <code>"Our model achieved state-of-the-art performance on CLEVR at 95 .5%, exceeding the best model\ntrained only on the pixel images and questions at the time of the dataset’s publication by 27%, and\nsurpassing human performance in the task (see Table 1 and Figure 3)."</code> | 5 | NOT RECORDED | UNADJUDICATED, formal-material-review | `f4c5b574-d651-4dd6-8ef2-0d376536f010` @ `2026-07-19T13:13:57.597Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-110 | L330-L331 | <code>"These results – in particular, those obtained in the compare attribute and count categories –\nare a testament to the ability of our model to do relational reasoning."</code> | 4 | NOT RECORDED | UNADJUDICATED | `f4c5b574-d651-4dd6-8ef2-0d376536f010` @ `2026-07-19T13:13:57.597Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-111 | L331-L332 | <code>"In fact, it is in these categories\nthat state-of-the-art models struggle most."</code> | 5 | NOT RECORDED | UNADJUDICATED | `f4c5b574-d651-4dd6-8ef2-0d376536f010` @ `2026-07-19T13:13:57.597Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-112 | L332-L334 | <code>"Furthermore, the relative simplicity of the network\ncomponents used in our model suggests that the diﬃculty of the CLEVR task lies in its relational\nreasoning demands, not on the language or the visual processing."</code> | 4 | NOT RECORDED | UNADJUDICATED | `f4c5b574-d651-4dd6-8ef2-0d376536f010` @ `2026-07-19T13:13:57.597Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-113 | L335-L337 | <code>"Results using privileged training information A more recent study reports overall perfor-\nmance of 96.9% on CLEVR, but uses additional supervisory signals on the functional programs\nused to generate the CLEVR questions [ 16]."</code> | 5 | NOT RECORDED | UNADJUDICATED | `f4c5b574-d651-4dd6-8ef2-0d376536f010` @ `2026-07-19T13:13:57.597Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-114 | L337-L338 | <code>"It is not possible for us to directly compare this\nto our work since we do not use these additional supervision signals."</code> | 6 | NOT RECORDED | UNADJUDICATED | `f4c5b574-d651-4dd6-8ef2-0d376536f010` @ `2026-07-19T13:13:57.597Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-115 | L338-L340 | <code>"Nonetheless, our approach\ngreatly outperforms a version of their model that was not trained with these extra signals, and even\nversions of their model trained using 9 K or 18K ground-truth programs."</code> | 5 | NOT RECORDED | UNADJUDICATED | `f4c5b574-d651-4dd6-8ef2-0d376536f010` @ `2026-07-19T13:13:57.597Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-116 | L340-L342 | <code>"Thus, RNs can achieve\nvery competitive, and even super-human results under much weaker and more natural assumptions,\nand even in situations when functional programs are unavailable."</code> | 5 | NOT RECORDED | UNADJUDICATED | `f4c5b574-d651-4dd6-8ef2-0d376536f010` @ `2026-07-19T13:13:57.597Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-117 | L344-L345 | <code>"To demonstrate that the RN is robust to the form of its input, we trained our model on the state\ndescription matrix version of the CLEVR dataset. The model achieved an accuracy of 96 .4%."</code> | 5 | NOT RECORDED | UNADJUDICATED | `f4c5b574-d651-4dd6-8ef2-0d376536f010` @ `2026-07-19T13:13:57.597Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-118 | L345-L348 | <code>"This\nresult demonstrates the generality of the RN module, showing its capacity to learn and reason\nabout object relations while being agnostic to the kind of inputs it receives – i.e., to the particular\nrepresentation of the object features to which it has access."</code> | 4 | NOT RECORDED | UNADJUDICATED | `f4c5b574-d651-4dd6-8ef2-0d376536f010` @ `2026-07-19T13:13:57.597Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-119 | L348-L350 | <code>"Therefore, RNs are not necessarily\nrestricted to visual problems, and can thus be applied in very diﬀerent contexts, and to diﬀerent\ntasks that require relational reasoning."</code> | 4 | NOT RECORDED | UNADJUDICATED | `f4c5b574-d651-4dd6-8ef2-0d376536f010` @ `2026-07-19T13:13:57.597Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |

### Review Block L391-L468 (C-120-C-145)

| ID | source locator | exact quote (JSON string) | criterion | candidate wording | flags | originating message ID and timestamp | mechanical corrections already applied | disposition | human judgment | reason | replacement or split | missing-packet decision | exclusion rationale |
|---|---|---|---:|---|---|---|---|---|---|---|---|---|---|
| C-120 | L393-L395 | <code>"Figure 3: Results on CLEVR from pixels. The RN augmented model outperformed all other\nmodels and exhibited super-human performance overall. In particular, it solved “compare attribute”\nquestions, which trouble all other models because they heavily depend on relational reasoning."</code> | 5 | NOT RECORDED | UNADJUDICATED, formal-material-review | `0d490d79-0cbb-4e96-a694-0f3382cb70c3` @ `2026-07-19T13:18:06.560Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-121 | L397-L398 | <code>"The results so far led us to hypothesize that the diﬃculty in solving CLEVR lies in its heavy emphasis\non relational reasoning, contrary to previous claims that the diﬃculty lies in question parsing [ 17]."</code> | 4 | NOT RECORDED | UNADJUDICATED | `0d490d79-0cbb-4e96-a694-0f3382cb70c3` @ `2026-07-19T13:18:06.560Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-122 | L399-L402 | <code>"However, the questions in the CLEVR dataset are not categorized based on the degree to which they\nmay be relational, making it hard to assess our hypothesis. Therefore, we use the Sort-of-CLEVR\ndataset which we explicitly designed to seperate out relational and non-relational questions (see\nSection 3.2)."</code> | 6 | NOT RECORDED | UNADJUDICATED | `0d490d79-0cbb-4e96-a694-0f3382cb70c3` @ `2026-07-19T13:18:06.560Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-123 | L403-L405 | <code>"We ﬁnd that a CNN augmented with an RN achieves an accuracy above 94% for both relational\nand non-relational questions. However, a CNN augmented with an MLP only reached this performance\non the non-relational questions, plateauing at 63% on the relational questions."</code> | 5 | NOT RECORDED | UNADJUDICATED | `0d490d79-0cbb-4e96-a694-0f3382cb70c3` @ `2026-07-19T13:18:06.560Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-124 | L405-L408 | <code>"This strongly indicates\nthat models lacking a dedicated relational reasoning component struggle, or may even be completely\nincapable of solving tasks that require very simple relational reasoning. Augmenting these models\nwith a relational module, like the RN, is suﬃcient to overcome this hurdle."</code> | 4 | NOT RECORDED | UNADJUDICATED | `0d490d79-0cbb-4e96-a694-0f3382cb70c3` @ `2026-07-19T13:18:06.560Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-125 | L409-L410 | <code>"A simple “closest-to” or “furthest-from” relation is particularly revealing of a CNN+MLP’s\nlack of general reasoning capabilities (52.3% success)."</code> | 5 | NOT RECORDED | UNADJUDICATED | `0d490d79-0cbb-4e96-a694-0f3382cb70c3` @ `2026-07-19T13:18:06.560Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-126 | L410-L413 | <code>"For these relations a model must gauge the\ndistances between each object, and then compare each of these distances. Moreover, depending on\nthe images, the relevant distance could be quite small in magnitude, or quite large, further increasing\nthe combinatoric diﬃculty of this task."</code> | 4 | NOT RECORDED | UNADJUDICATED | `0d490d79-0cbb-4e96-a694-0f3382cb70c3` @ `2026-07-19T13:18:06.560Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-127 | L415-L416 | <code>"Our model succeeded on 18 /20 tasks. Notably, it succeeded on the basic induction task (2 .1%\ntotal error), which proved diﬃcult for the Sparse DNC (54%), DNC (55 .1%), and EntNet (52.1%)."</code> | 5 | NOT RECORDED | UNADJUDICATED | `0d490d79-0cbb-4e96-a694-0f3382cb70c3` @ `2026-07-19T13:18:06.560Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-128 | L417-L419 | <code>"Also, our model did not catastrophically fail in any of the tasks: for the 2 tasks that it failed (the\n“two supporting facts”, and “three supporting facts” tasks), it missed the 95% threshold by 3 .1%\nand 11.5%, respectively."</code> | 5 | NOT RECORDED | UNADJUDICATED | `0d490d79-0cbb-4e96-a694-0f3382cb70c3` @ `2026-07-19T13:18:06.560Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-129 | L419-L420 | <code>"We also note that the model we evaluated was chosen based on overall\nperformance on a withheld validation set, using a single seed."</code> | 6 | NOT RECORDED | UNADJUDICATED, word-count-correction, split, possible-over-narrow-review | `6bf679e6-5ac2-4901-980f-5e9c38c5ccef` @ `2026-07-19T13:20:42.694Z` | Replaces L419-L423 (67 words) from message 0d490d79-0cbb-4e96-a694-0f3382cb70c3 with two rows. | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-130 | L420-L423 | <code>"That is, we did not run multiple\nreplicas with the best hyperparameter settings (as was done in other models, such as the Sparse\nDNC, which demonstrated performance ﬂuctuations with a standard deviation of more than ±3\ntasks passed for the best choice of hyperparameters)."</code> | 6 | NOT RECORDED | UNADJUDICATED, word-count-correction, split, possible-over-narrow-review | `6bf679e6-5ac2-4901-980f-5e9c38c5ccef` @ `2026-07-19T13:20:42.694Z` | Replaces L419-L423 (67 words) from message 0d490d79-0cbb-4e96-a694-0f3382cb70c3 with two rows. | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-131 | L429-L430 | <code>"93% of the sample scenes in the test set. In the counting task, the RN achieved similar performance,\nreporting the correct number of connected systems for 95% of the test scene samples."</code> | 5 | NOT RECORDED | UNADJUDICATED | `0d490d79-0cbb-4e96-a694-0f3382cb70c3` @ `2026-07-19T13:18:06.560Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-132 | L430-L432 | <code>"In comparison,\nan MLP with comparable number of parameters was unable to perform better than chance for both\ntasks."</code> | 5 | NOT RECORDED | UNADJUDICATED | `0d490d79-0cbb-4e96-a694-0f3382cb70c3` @ `2026-07-19T13:18:06.560Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-133 | L432-L434 | <code>"Moreover, using this task to learn to infer relations results in transfer to unseen motion capture\ndata, where RNs predict the connections between body joints of a walking human (see supplementary\ninformation for experimental details and example videos)."</code> | 5 | NOT RECORDED | UNADJUDICATED | `0d490d79-0cbb-4e96-a694-0f3382cb70c3` @ `2026-07-19T13:18:06.560Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-134 | L436-L438 | <code>"This work showed how the RN, a dedicated module for computing inter-entity relations, can be\nplugged into broader deep learning architectures to substantially improve performance on tasks that\ndemand rich relational reasoning."</code> | 4 | NOT RECORDED | UNADJUDICATED | `0d490d79-0cbb-4e96-a694-0f3382cb70c3` @ `2026-07-19T13:18:06.560Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-135 | L438-L440 | <code>"Our CLEVR results included super-human performance at 95 .5%\noverall. Our bAbI results demonstrated broad reasoning capabilities, solving 18 /20 tasks with no\ncatastrophic failures."</code> | 5 | NOT RECORDED | UNADJUDICATED | `0d490d79-0cbb-4e96-a694-0f3382cb70c3` @ `2026-07-19T13:18:06.560Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-136 | L440-L441 | <code>"Together these results demonstrate the ﬂexibility and power of this simple\nneural network building block."</code> | 4 | NOT RECORDED | UNADJUDICATED | `0d490d79-0cbb-4e96-a694-0f3382cb70c3` @ `2026-07-19T13:18:06.560Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-137 | L442-L444 | <code>"One of the most interesting aspects of the work is that RN module inclusion in relatively simple\nCNN- and LSTM-based VQA architectures raised the performance on CLEVR from 68 .5% to 95.5%\nand achieved state-of-the-art, super-human performance."</code> | 5 | NOT RECORDED | UNADJUDICATED | `0d490d79-0cbb-4e96-a694-0f3382cb70c3` @ `2026-07-19T13:18:06.560Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-138 | L444-L446 | <code>"We speculate that the RN provided a more\npowerful mechanism for ﬂexible relational reasoning, and freed up the CNN to focus more exclusively\non processing local spatial structure."</code> | 4 | NOT RECORDED | UNADJUDICATED | `0d490d79-0cbb-4e96-a694-0f3382cb70c3` @ `2026-07-19T13:18:06.560Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-139 | L446-L448 | <code>"This distinction between processing and reasoning is important.\nPowerful deep learning architectures, such as ResNets, are highly capable visual processors, but they\nmay not be the most appropriate choice for reasoning about arbitrary relations."</code> | 4 | NOT RECORDED | UNADJUDICATED | `0d490d79-0cbb-4e96-a694-0f3382cb70c3` @ `2026-07-19T13:18:06.560Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-140 | L449-L450 | <code>"A key contribution of this work is that the RN was able to induce, through the learning process,\nupstream processing to provide a set of useful object-like representations."</code> | 4 | NOT RECORDED | UNADJUDICATED | `0d490d79-0cbb-4e96-a694-0f3382cb70c3` @ `2026-07-19T13:18:06.560Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-141 | L450-L453 | <code>"Note, the input data\nand target objective functions did not specify any particular form or semantics of the internal\nobject representations. This demonstrates the RN’s rich capacity for structured reasoning even with\nunstructured inputs and outputs."</code> | 4 | NOT RECORDED | UNADJUDICATED | `0d490d79-0cbb-4e96-a694-0f3382cb70c3` @ `2026-07-19T13:18:06.560Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-142 | L454-L456 | <code>"Future work should apply RNs to a variety of problems that can beneﬁt from structure learning\nand exploitation, such as rich scene understanding in RL agents, modeling social networks, and\nabstract problem solving. Future work could also improve the eﬃciency of RN computations."</code> | 7 | NOT RECORDED | UNADJUDICATED | `0d490d79-0cbb-4e96-a694-0f3382cb70c3` @ `2026-07-19T13:18:06.560Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-143 | L456-L459 | <code>"Though\nour results show that no knowledge about the particular relations among objects are necessary, RNs\ncan exploit such knowledge if available or useful. For example, if two objects are known to have no\nactual relation, the RN’s computation of their relation can be omitted."</code> | 7 | NOT RECORDED | UNADJUDICATED | `0d490d79-0cbb-4e96-a694-0f3382cb70c3` @ `2026-07-19T13:18:06.560Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-144 | L459-L462 | <code>"An important direction is\nexercising this option in circumstances with strict computational constraints, where, for instance,\nattentional mechanisms could be used to ﬁlter unimportant relations and thus bound the otherwise\nquadratic complexity of the number of considered pairwise relations."</code> | 7 | NOT RECORDED | UNADJUDICATED | `0d490d79-0cbb-4e96-a694-0f3382cb70c3` @ `2026-07-19T13:18:06.560Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-145 | L463-L464 | <code>"Relation Networks are a simple and powerful approach for learning to perform rich, structured\nreasoning in complex, real-world domains."</code> | 4 | NOT RECORDED | UNADJUDICATED | `0d490d79-0cbb-4e96-a694-0f3382cb70c3` @ `2026-07-19T13:18:06.560Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |

### Review Block L469-L518 (C-146-C-162)

| ID | source locator | exact quote (JSON string) | criterion | candidate wording | flags | originating message ID and timestamp | mechanical corrections already applied | disposition | human judgment | reason | replacement or split | missing-packet decision | exclusion rationale |
|---|---|---|---:|---|---|---|---|---|---|---|---|---|---|
| C-146 | L476-L478 | <code>"Since the RN is highly versatile, it can be used for visual, text-based, and state-based tasks. As such,\nit touches upon a broad range of areas in machine learning, computer vision, and natural language\nunderstanding. Here, we provide a brief overview of some of the most relevant related work."</code> | 2 | NOT RECORDED | UNADJUDICATED | `d284fdf1-8fbc-4f41-ad01-bcf66ea89cd3` @ `2026-07-19T16:48:41.426Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-147 | L480-L481 | <code>"Relational reasoning is implicit in many symbolic approaches [ 11, 32] and has been explicitly pursued\nusing neural networks as well [4]."</code> | 2 | NOT RECORDED | UNADJUDICATED | `d284fdf1-8fbc-4f41-ad01-bcf66ea89cd3` @ `2026-07-19T16:48:41.426Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-148 | L481-L482 | <code>"There is recent work applying neural networks to graphs, which are\na natural structure for formalising relations [12, 19, 33, 37, 26, 2]."</code> | 2 | NOT RECORDED | UNADJUDICATED | `d284fdf1-8fbc-4f41-ad01-bcf66ea89cd3` @ `2026-07-19T16:48:41.426Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-149 | L482-L485 | <code>"Perhaps a crucial diﬀerence between\nthis work and our work here is that RNs require minimal oversight to produce their input (a set of\nobjects), and can be applied successfully to tasks even when provided with relatively unstructured\ninputs coming from CNNs and LSTMs."</code> | 4 | NOT RECORDED | UNADJUDICATED | `d284fdf1-8fbc-4f41-ad01-bcf66ea89cd3` @ `2026-07-19T16:48:41.426Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-150 | L485-L486 | <code>"There has also been some recent work on reasoning about\nsets, although this work does not explicitly reason about the relations of elements within sets [47]."</code> | 6 | NOT RECORDED | UNADJUDICATED | `d284fdf1-8fbc-4f41-ad01-bcf66ea89cd3` @ `2026-07-19T16:48:41.426Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-151 | L488-L490 | <code>"Although grounding language in spatial percepts has a long-standing tradition, the majority of\nprevious research has focused on either rule-based spatial representations or hand-engineered spatial\nfeatures [8, 10, 20, 21, 24, 29, 38, 39]."</code> | 2 | NOT RECORDED | UNADJUDICATED | `d284fdf1-8fbc-4f41-ad01-bcf66ea89cd3` @ `2026-07-19T16:48:41.426Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-152 | L490-L491 | <code>"Although there are some attempts to learn spatial relations\nusing spatial templates [28, 30], these approaches are less versatile than ours."</code> | 5 | NOT RECORDED | UNADJUDICATED | `d284fdf1-8fbc-4f41-ad01-bcf66ea89cd3` @ `2026-07-19T16:48:41.426Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-153 | L493-L494 | <code>"Visual question answering is a recently introduced task that measures a machine understanding of the\nscene through questions [1, 29]."</code> | 1 | NOT RECORDED | UNADJUDICATED | `d284fdf1-8fbc-4f41-ad01-bcf66ea89cd3` @ `2026-07-19T16:48:41.426Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-154 | L494-L496 | <code>"Related to our work, we are mostly interested in the newly introduced\nCLEVR dataset [ 15] that distills core challenges of the task, namely relational and multi-modal\nreasoning."</code> | 1 | NOT RECORDED | UNADJUDICATED | `d284fdf1-8fbc-4f41-ad01-bcf66ea89cd3` @ `2026-07-19T16:48:41.426Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-155 | L496-L499 | <code>"The majority of approaches to question answering share the same pipeline [ 6, 31, 36]. First,\nquestions are encoded with recurrent neural networks, and images are encoded with convolutional\nneural networks. Next, both representations are combined, and the answers are either predicted or\ngenerated."</code> | 2 | NOT RECORDED | UNADJUDICATED | `d284fdf1-8fbc-4f41-ad01-bcf66ea89cd3` @ `2026-07-19T16:48:41.426Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-156 | L499-L500 | <code>"Most successful methods also use an attention mechanism that locate important image\nregions [5, 44, 45, 46]."</code> | 2 | NOT RECORDED | UNADJUDICATED | `d284fdf1-8fbc-4f41-ad01-bcf66ea89cd3` @ `2026-07-19T16:48:41.426Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-157 | L500-L501 | <code>"In our work, we follow a similar pipeline, but we use Relation Networks as a\npowerful reasoning module."</code> | 2 | NOT RECORDED | UNADJUDICATED | `d284fdf1-8fbc-4f41-ad01-bcf66ea89cd3` @ `2026-07-19T16:48:41.426Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-158 | L502-L504 | <code>"Parallel to our work, two architectures have shown impressive results on the CLEVR dataset\n[14, 16]. Both approaches hinge on compositionality principles, and have shown they are capable of\nsome relational reasoning."</code> | 5 | NOT RECORDED | UNADJUDICATED | `d284fdf1-8fbc-4f41-ad01-bcf66ea89cd3` @ `2026-07-19T16:48:41.426Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-159 | L504-L505 | <code>"However, both require either designing modules, or require direct access to\nground-truth programs."</code> | 6 | NOT RECORDED | UNADJUDICATED | `d284fdf1-8fbc-4f41-ad01-bcf66ea89cd3` @ `2026-07-19T16:48:41.426Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-160 | L505-L508 | <code>"The RN module, on the other hand, is conceptually simpler, can readily be\ncombined with basic neural components such as CNNs or LSTMs, can be broadly applied to various\ntasks, and achieves signiﬁcantly better results on CLEVR [ 15] than [14], and on par with strongly\nsupervised system of [16]."</code> | 5 | NOT RECORDED | UNADJUDICATED | `d284fdf1-8fbc-4f41-ad01-bcf66ea89cd3` @ `2026-07-19T16:48:41.426Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-161 | L510-L512 | <code>"Answering text-based questions has long been an active research area in the NLP community\n[3, 22, 27, 48]. Recently, in addition to traditional symbolic-based question answering architectures,\nwe observe a growing interest in neural-based approaches to text based question answering [34, 42, 43]."</code> | 2 | NOT RECORDED | UNADJUDICATED | `d284fdf1-8fbc-4f41-ad01-bcf66ea89cd3` @ `2026-07-19T16:48:41.426Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-162 | L513-L517 | <code>"While these architectures rely on ‘memories’, we empirically show that the RN module has similar\n10\n\ncapabilities, reaching very competitive results on the bAbI dataset [ 41] – a dataset that test reasoning\ncapabilities of text-based question answering models."</code> | 5 | NOT RECORDED | UNADJUDICATED | `d284fdf1-8fbc-4f41-ad01-bcf66ea89cd3` @ `2026-07-19T16:48:41.426Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |

### Review Block L519-L568 (C-163-C-183)

| ID | source locator | exact quote (JSON string) | criterion | candidate wording | flags | originating message ID and timestamp | mechanical corrections already applied | disposition | human judgment | reason | replacement or split | missing-packet decision | exclusion rationale |
|---|---|---|---:|---|---|---|---|---|---|---|---|---|---|
| C-163 | L519-L520 | <code>"Our model (described in Section 4 of the main text) was trained on 70000 scenes from the CLEVR\ndataset and a total of 699989 questions."</code> | 3 | NOT RECORDED | UNADJUDICATED | `ac25326b-0940-466a-96af-2a4da56ccd56` @ `2026-07-19T18:03:37.359Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-164 | L520-L522 | <code>"Images were ﬁrst down-sampled to size 128 × 128, then\npre-processed with padding to size 136 × 136, followed by random cropping back to size 128 × 128\nand slight random rotations between −0.05 and 0.05 rads."</code> | 3 | NOT RECORDED | UNADJUDICATED | `ac25326b-0940-466a-96af-2a4da56ccd56` @ `2026-07-19T18:03:37.359Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-165 | L522-L524 | <code>"We used 10 distributed workers that\nsynchronously updated a central parameter server. Each worker learned with mini-batches of size\n64, using the Adam optimizer and a learning rate of 2 .5e−4."</code> | 3 | NOT RECORDED | UNADJUDICATED | `ac25326b-0940-466a-96af-2a4da56ccd56` @ `2026-07-19T18:03:37.359Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-166 | L524-L525 | <code>"Dropout of 50% was used on the\npenultimate layer of the RN."</code> | 3 | NOT RECORDED | UNADJUDICATED | `ac25326b-0940-466a-96af-2a4da56ccd56` @ `2026-07-19T18:03:37.359Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-167 | L525-L527 | <code>"In our best performing model each convolutional layer used 24 kernels of\nsize 3× 3 and stride 2, batch normalization, and rectiﬁed linear units. The model stopped improving\nin performance after approximately 1.4 million iterations, at which point training was concluded."</code> | 3 | NOT RECORDED | UNADJUDICATED | `ac25326b-0940-466a-96af-2a4da56ccd56` @ `2026-07-19T18:03:37.359Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-168 | L528-L528 | <code>"The model achieved 96.8% accuracy on the validation set."</code> | 5 | NOT RECORDED | UNADJUDICATED | `ac25326b-0940-466a-96af-2a4da56ccd56` @ `2026-07-19T18:03:37.359Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-169 | L528-L530 | <code>"In general, we found that smaller models\nperformed best. For example, 128 hidden unit LSTMs performed better than 256 or 512, and CNNs\nwith 24 kernels were better than CNNs with more kernels, such as 32, 64, or more."</code> | 5 | NOT RECORDED | UNADJUDICATED | `ac25326b-0940-466a-96af-2a4da56ccd56` @ `2026-07-19T18:03:37.359Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-170 | L532-L534 | <code>"Although our model gets most answers correct, a closer examination of the failure cases help us to\nidentify limitations of our architecture. In Table 2, we show some examples of CLEVR questions that\nour model fails to answer correctly, along with the ground-truth answers."</code> | 6 | NOT RECORDED | UNADJUDICATED, formal-material-review | `ac25326b-0940-466a-96af-2a4da56ccd56` @ `2026-07-19T18:03:37.359Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-171 | L534-L537 | <code>"Based on our observations,\nwe hypothesize that our architecture fails especially when objects are heavily occluded, or whenever\na high precision object position representation is required. We also observe that many failure cases\nfor our model are also challenging for humans."</code> | 6 | NOT RECORDED | UNADJUDICATED | `ac25326b-0940-466a-96af-2a4da56ccd56` @ `2026-07-19T18:03:37.359Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-172 | L539-L540 | <code>"The model that we train on the state description version of CLEVR is similar to the model trained\non the pixel version of CLEVR, but without the vision processing module."</code> | 2 | NOT RECORDED | UNADJUDICATED | `ac25326b-0940-466a-96af-2a4da56ccd56` @ `2026-07-19T18:03:37.359Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-173 | L540-L541 | <code>"We used a 256 unit LSTM\nfor question processing and word-lookup embeddings of size 32."</code> | 3 | NOT RECORDED | UNADJUDICATED | `ac25326b-0940-466a-96af-2a4da56ccd56` @ `2026-07-19T18:03:37.359Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-174 | L541-L543 | <code>"For the RN we used a four-layer\nMLP with 512 units per layer, with ReLU non-linearities for gθ. A three-layer MLP consisting of\n512, 1024 (with 2% dropout) and 29 units with ReLU non-linearities was used for fθ."</code> | 3 | NOT RECORDED | UNADJUDICATED, formal-material-review | `ac25326b-0940-466a-96af-2a4da56ccd56` @ `2026-07-19T18:03:37.359Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-175 | L543-L545 | <code>"To train the\nmodel we used 10 distributed workers that synchronously updated a central parameter server. Each\nworker learned with mini-batches of size 64, using the Adam optimizer and a learning rate of 1 e−4."</code> | 3 | NOT RECORDED | UNADJUDICATED | `ac25326b-0940-466a-96af-2a4da56ccd56` @ `2026-07-19T18:03:37.359Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-176 | L547-L548 | <code>"The Sort-of-CLEVR dataset contains 10000 images of size 75 × 75, 200 of which were withheld for\nvalidation. There were 20 questions generated per image (10 relational and 10 non-relational)."</code> | 3 | NOT RECORDED | UNADJUDICATED | `ac25326b-0940-466a-96af-2a4da56ccd56` @ `2026-07-19T18:03:37.359Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-177 | L549-L551 | <code>"Non-relational questions are split into three categories: (i) query shape, e.g. “ What is the shape\nof the red object? ”; (ii) query horizontal position, e.g. “ Is the red object on the left or right of the\nimage?”; (iii) query vertical position, e.g. “ Is the red object on the top or bottom of the image? ”."</code> | 1 | NOT RECORDED | UNADJUDICATED | `ac25326b-0940-466a-96af-2a4da56ccd56` @ `2026-07-19T18:03:37.359Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-178 | L552-L553 | <code>"These questions are non-relational because one can answer them by reasoning about the attributes\n(e.g. position, shape) of a single entity which is identiﬁed by its unique color (e.g. red)."</code> | 4 | NOT RECORDED | UNADJUDICATED | `ac25326b-0940-466a-96af-2a4da56ccd56` @ `2026-07-19T18:03:37.359Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-179 | L554-L557 | <code>"Relational questions are split into three categories: (i) closest-to, e.g. “ What is the shape of the\nobject that is closest to the green object? ”; (ii) furthest-from, e.g. “ What is the shape of the object\nthat is furthest from the green object? ”; (iii) count, e.g. “ How many objects have the shape of the\ngreen object?”."</code> | 1 | NOT RECORDED | UNADJUDICATED | `ac25326b-0940-466a-96af-2a4da56ccd56` @ `2026-07-19T18:03:37.359Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-180 | L557-L559 | <code>"We consider these relational because answering them requires reasoning about the\nattributes of one or more objects that are deﬁned relative to the attributes of a reference object.\nThis reference object is uniquely identiﬁed by its color."</code> | 4 | NOT RECORDED | UNADJUDICATED | `ac25326b-0940-466a-96af-2a4da56ccd56` @ `2026-07-19T18:03:37.359Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-181 | L560-L562 | <code>"Questions were encoded as binary strings of length 11, where the ﬁrst 6 bits identiﬁed the color\nof the object to which the question referred, as a one-hot vector, and the last 5 bits identiﬁed the\nquestion type and subtype."</code> | 3 | NOT RECORDED | UNADJUDICATED | `ac25326b-0940-466a-96af-2a4da56ccd56` @ `2026-07-19T18:03:37.359Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-182 | L565-L568 | <code>"In this task our model used: four convolutional layers with 32, 64, 128 and 256 kernels, ReLU\nnon-linearities, and batch normalization; the questions, which were encoded as ﬁxed-length binary\nstrings, were treated as question embeddings and passed directly to the RN alongside the object\npairs;"</code> | 3 | NOT RECORDED | UNADJUDICATED, word-count-correction, split, possible-over-narrow-review | `f89e8bdc-56b8-4b13-af97-609c7d85377f` @ `2026-07-19T18:31:37.398Z` | Replaces L565-L568 (61 words) from message ac25326b-0940-466a-96af-2a4da56ccd56 with two rows. | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-183 | L568-L568 | <code>"a four-layer MLP consisting of 2000 units per layer with ReLU non-linearities was used for gθ;"</code> | 3 | NOT RECORDED | UNADJUDICATED, word-count-correction, split, possible-over-narrow-review, formal-material-review | `f89e8bdc-56b8-4b13-af97-609c7d85377f` @ `2026-07-19T18:31:37.398Z` | Replaces L565-L568 (61 words) from message ac25326b-0940-466a-96af-2a4da56ccd56 with two rows. | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |

### Review Block L569-L618 (C-184-C-204)

| ID | source locator | exact quote (JSON string) | criterion | candidate wording | flags | originating message ID and timestamp | mechanical corrections already applied | disposition | human judgment | reason | replacement or split | missing-packet decision | exclusion rationale |
|---|---|---|---:|---|---|---|---|---|---|---|---|---|---|
| C-184 | L569-L570 | <code>"and a four-layer MLP consisting of 2000, 1000, 500, and 100 units with ReLU non-linearities used for\nfφ. An additional ﬁnal linear layer produced logits for a softmax over the possible answers."</code> | 3 | NOT RECORDED | UNADJUDICATED, formal-material-review | `8d9c448e-7b5f-4662-99e7-839cb7d1db4a` @ `2026-07-19T20:15:48.189Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-185 | L570-L572 | <code>"The\nsoftmax output was optimized with a cross-entropy loss function using the Adam optimizer with a\nlearning rate of 1e−4 and mini-batches of size 64."</code> | 3 | NOT RECORDED | UNADJUDICATED | `8d9c448e-7b5f-4662-99e7-839cb7d1db4a` @ `2026-07-19T20:15:48.189Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-186 | L573-L575 | <code>"We also trained a comparable MLP based model (CNN+MLP model) on the Sort-of-CLEVR\ntask, to explore the extent to which a standard model can learn to answer relational questions. We\nused the same CNN and LSTM, trained end-to-end, as described above."</code> | 3 | NOT RECORDED | UNADJUDICATED | `8d9c448e-7b5f-4662-99e7-839cb7d1db4a` @ `2026-07-19T20:15:48.189Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-187 | L575-L576 | <code>"However, this time we\nreplaced the RN with an MLP with the same number of layers and number of units per layer."</code> | 3 | NOT RECORDED | UNADJUDICATED | `8d9c448e-7b5f-4662-99e7-839cb7d1db4a` @ `2026-07-19T20:15:48.189Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-188 | L576-L578 | <code>"Note\nthat there are more parameters in this model because the input layer of the MLP connects to the\nfull CNN image embedding."</code> | 6 | NOT RECORDED | UNADJUDICATED | `8d9c448e-7b5f-4662-99e7-839cb7d1db4a` @ `2026-07-19T20:15:48.189Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-189 | L580-L581 | <code>"For the bAbI task, each of the 20 sentences in the support set was processed through a 32 unit LSTM\nto produce an object."</code> | 3 | NOT RECORDED | UNADJUDICATED | `8d9c448e-7b5f-4662-99e7-839cb7d1db4a` @ `2026-07-19T20:15:48.189Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-190 | L581-L582 | <code>"For the RN, gθ was a four-layer MLP consisting of 256 units per layer. For\nfφ, we used a three-layer MLP consisting of 256, 512, and 159 units,"</code> | 3 | NOT RECORDED | UNADJUDICATED, formal-material-review | `8d9c448e-7b5f-4662-99e7-839cb7d1db4a` @ `2026-07-19T20:15:48.189Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-191 | L582-L583 | <code>"where the ﬁnal layer was a\nlinear layer that produced logits for a softmax over the answer vocabulary."</code> | 3 | NOT RECORDED | UNADJUDICATED | `8d9c448e-7b5f-4662-99e7-839cb7d1db4a` @ `2026-07-19T20:15:48.189Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-192 | L583-L585 | <code>"A separate LSTM with\n32 units was used to process the question. The softmax output was optimized with a cross-entropy\nloss function using the Adam optimizer with a learning rate of 2 e−4."</code> | 3 | NOT RECORDED | UNADJUDICATED | `8d9c448e-7b5f-4662-99e7-839cb7d1db4a` @ `2026-07-19T20:15:48.189Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-193 | L587-L589 | <code>"For the connection inference task the targets were binary vectors representing the existence (or\nnon-existence) of a connection between each ball pair. For a total of 10 objects, the targets were\n102 length vectors."</code> | 3 | NOT RECORDED | UNADJUDICATED | `8d9c448e-7b5f-4662-99e7-839cb7d1db4a` @ `2026-07-19T20:15:48.189Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-194 | L589-L590 | <code>"For the counting task, the targets were one-hot vectors (of length 10) indicating\nthe number of systems of connected balls."</code> | 3 | NOT RECORDED | UNADJUDICATED | `8d9c448e-7b5f-4662-99e7-839cb7d1db4a` @ `2026-07-19T20:15:48.189Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-195 | L590-L592 | <code>"It is important to point out that in the ﬁrst task the\nsupervision signal provided by the targets explicitly informs about the relations that need to be\ncomputed."</code> | 4 | NOT RECORDED | UNADJUDICATED | `8d9c448e-7b5f-4662-99e7-839cb7d1db4a` @ `2026-07-19T20:15:48.189Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-196 | L592-L594 | <code>"In the second task, the supervision signal (counts of systems) do not provide explicit\ninformation about the kind of relations that need to be computed. Therefore, the models that solve\nthe counting task must successfully infer the relations implicitly."</code> | 4 | NOT RECORDED | UNADJUDICATED | `8d9c448e-7b5f-4662-99e7-839cb7d1db4a` @ `2026-07-19T20:15:48.189Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-197 | L595-L598 | <code>"Inputs to the RN were state descriptions. Each row of a state description matrix provided\ninformation about a particular object (i.e. ball), including its coordinate position and color. Since\nthe system was dynamic, and hence evolved through time, each row contained object property\ndescriptions for 16 consecutive time-frames."</code> | 3 | NOT RECORDED | UNADJUDICATED | `8d9c448e-7b5f-4662-99e7-839cb7d1db4a` @ `2026-07-19T20:15:48.189Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-198 | L598-L600 | <code>"For example, a row could be comprised of 33 ﬂoats:\n16 for the object’s x coordinate position across 16 frames, 16 for the object’s y coordinate position\nacross 16 frames, and 1 for the object’s color."</code> | 3 | NOT RECORDED | UNADJUDICATED | `8d9c448e-7b5f-4662-99e7-839cb7d1db4a` @ `2026-07-19T20:15:48.189Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-199 | L600-L602 | <code>"The RN treated each row in this state description\nmatrix as an object. Thus, it had to infer an object description contained information of the object’s\nproperties evolving through time."</code> | 4 | NOT RECORDED | UNADJUDICATED | `8d9c448e-7b5f-4662-99e7-839cb7d1db4a` @ `2026-07-19T20:15:48.189Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-200 | L603-L604 | <code>"For the connection inference task, the RN’s gθ was a four-layer MLP consisting of three layers\nwith 1000 units and one layer with 500 units."</code> | 3 | NOT RECORDED | UNADJUDICATED, formal-material-review | `8d9c448e-7b5f-4662-99e7-839cb7d1db4a` @ `2026-07-19T20:15:48.189Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-201 | L604-L606 | <code>"For fφ, we used a three-layer MLP consisting of 500,\n100, and 100 units, where the ﬁnal layer was a linear layer that produced logits corresponding to\nthe existence/absence of a connection between each ball pair."</code> | 3 | NOT RECORDED | UNADJUDICATED, formal-material-review | `8d9c448e-7b5f-4662-99e7-839cb7d1db4a` @ `2026-07-19T20:15:48.189Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-202 | L606-L608 | <code>"The output was optimized with a\ncross-entropy loss function using the Adam optimizer with a learning rate of 1 e−4 and a batch size\nof 50."</code> | 3 | NOT RECORDED | UNADJUDICATED | `8d9c448e-7b5f-4662-99e7-839cb7d1db4a` @ `2026-07-19T20:15:48.189Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-203 | L608-L609 | <code>"The same model was used for the counting task, but this time the output layer of the RN\nwas a linear layer with 10 units."</code> | 3 | NOT RECORDED | UNADJUDICATED | `8d9c448e-7b5f-4662-99e7-839cb7d1db4a` @ `2026-07-19T20:15:48.189Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-204 | L609-L610 | <code>"For baseline comparisons we replaced the RNs with MLPs with\ncomparable number of parameters."</code> | 3 | NOT RECORDED | UNADJUDICATED | `8d9c448e-7b5f-4662-99e7-839cb7d1db4a` @ `2026-07-19T20:15:48.189Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |

### Review Block L619-L668 (C-205-C-206)

| ID | source locator | exact quote (JSON string) | criterion | candidate wording | flags | originating message ID and timestamp | mechanical corrections already applied | disposition | human judgment | reason | replacement or split | missing-packet decision | exclusion rationale |
|---|---|---|---:|---|---|---|---|---|---|---|---|---|---|
| C-205 | L657-L659 | <code>"Figure 4: “Sort-of-CLEVR” task: examples and results. The Sort-of-CLEVR example here\nconsists of an image of six objects and two questions – a relational question, and a non-relational\nquestion – along with the corresponding answers."</code> | 3 | NOT RECORDED | UNADJUDICATED, formal-material-review | `17f6a173-8427-4067-adfd-6b391c4c5648` @ `2026-07-20T10:24:02.095Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |
| C-206 | L659-L662 | <code>"The fraction of correctly answered relational\nquestions (inset bar plot) for our model (CNN+RN) is much larger than the comparable MLP\nbased model (CNN+MLP), whereas both models have similar performance levels for non-relational\nquestions."</code> | 5 | NOT RECORDED | UNADJUDICATED | `17f6a173-8427-4067-adfd-6b391c4c5648` @ `2026-07-20T10:24:02.095Z` | none | OPEN | OPEN | OPEN | OPEN | OPEN | OPEN |

## No-Candidate Review Rows

| review ID | source span | recovered status | disposition | human judgment | reason | missing-packet decision | exclusion rationale |
|---|---|---|---|---|---|---|---|
| G-001 | L1-L15 | no final candidate; semantic reason NOT RECORDED; L1-L5 explicitly named extraction-wrapper in criteria | OPEN | OPEN | OPEN | OPEN | OPEN |
| G-002 | L27 | no final candidate; semantic reason NOT RECORDED | OPEN | OPEN | OPEN | OPEN | OPEN |
| G-003 | L42-L55 | no final candidate; semantic reason NOT RECORDED | OPEN | OPEN | OPEN | OPEN | OPEN |
| G-004 | L61-L62 | no final candidate; semantic reason NOT RECORDED | OPEN | OPEN | OPEN | OPEN | OPEN |
| G-005 | L79 | no final candidate; semantic reason NOT RECORDED | OPEN | OPEN | OPEN | OPEN | OPEN |
| G-006 | L96-L97 | no final candidate; semantic reason NOT RECORDED | OPEN | OPEN | OPEN | OPEN | OPEN |
| G-007 | L131 | no final candidate; semantic reason NOT RECORDED | OPEN | OPEN | OPEN | OPEN | OPEN |
| G-008 | L135 | no final candidate; semantic reason NOT RECORDED | OPEN | OPEN | OPEN | OPEN | OPEN |
| G-009 | L144-L145 | no final candidate; semantic reason NOT RECORDED | OPEN | OPEN | OPEN | OPEN | OPEN |
| G-010 | L168 | no final candidate; semantic reason NOT RECORDED | OPEN | OPEN | OPEN | OPEN | OPEN |
| G-011 | L183 | no final candidate; semantic reason NOT RECORDED | OPEN | OPEN | OPEN | OPEN | OPEN |
| G-012 | L194-L196 | no final candidate; semantic reason NOT RECORDED | OPEN | OPEN | OPEN | OPEN | OPEN |
| G-013 | L217-L218 | no final candidate; semantic reason NOT RECORDED | OPEN | OPEN | OPEN | OPEN | OPEN |
| G-014 | L234 | no final candidate; semantic reason NOT RECORDED | OPEN | OPEN | OPEN | OPEN | OPEN |
| G-015 | L243-L270 | no final candidate; semantic reason NOT RECORDED | OPEN | OPEN | OPEN | OPEN | OPEN |
| G-016 | L303-L312 | no final candidate; semantic reason NOT RECORDED | OPEN | OPEN | OPEN | OPEN | OPEN |
| G-017 | L313-L319 | no final candidate; semantic reason NOT RECORDED | OPEN | OPEN | OPEN | OPEN | OPEN |
| G-018 | L323-L326 | no final candidate; semantic reason NOT RECORDED | OPEN | OPEN | OPEN | OPEN | OPEN |
| G-019 | L343 | no final candidate; semantic reason NOT RECORDED | OPEN | OPEN | OPEN | OPEN | OPEN |
| G-020 | L351-L390 | no final candidate; semantic reason NOT RECORDED | OPEN | OPEN | OPEN | OPEN | OPEN |
| G-021 | L391-L392 | no final candidate; semantic reason NOT RECORDED | OPEN | OPEN | OPEN | OPEN | OPEN |
| G-022 | L396 | no final candidate; semantic reason NOT RECORDED | OPEN | OPEN | OPEN | OPEN | OPEN |
| G-023 | L414 | no final candidate; semantic reason NOT RECORDED | OPEN | OPEN | OPEN | OPEN | OPEN |
| G-024 | L424-L428 | no final candidate; semantic reason NOT RECORDED | OPEN | OPEN | OPEN | OPEN | OPEN |
| G-025 | L435 | no final candidate; semantic reason NOT RECORDED | OPEN | OPEN | OPEN | OPEN | OPEN |
| G-026 | L465-L468 | no final candidate; semantic reason NOT RECORDED | OPEN | OPEN | OPEN | OPEN | OPEN |
| G-027 | L469-L475 | no final candidate; semantic reason NOT RECORDED | OPEN | OPEN | OPEN | OPEN | OPEN |
| G-028 | L479 | no final candidate; semantic reason NOT RECORDED | OPEN | OPEN | OPEN | OPEN | OPEN |
| G-029 | L487 | no final candidate; semantic reason NOT RECORDED | OPEN | OPEN | OPEN | OPEN | OPEN |
| G-030 | L492 | no final candidate; semantic reason NOT RECORDED | OPEN | OPEN | OPEN | OPEN | OPEN |
| G-031 | L509 | no final candidate; semantic reason NOT RECORDED | OPEN | OPEN | OPEN | OPEN | OPEN |
| G-032 | L518 | no final candidate; semantic reason NOT RECORDED | OPEN | OPEN | OPEN | OPEN | OPEN |
| G-033 | L531 | no final candidate; semantic reason NOT RECORDED | OPEN | OPEN | OPEN | OPEN | OPEN |
| G-034 | L538 | no final candidate; semantic reason NOT RECORDED | OPEN | OPEN | OPEN | OPEN | OPEN |
| G-035 | L546 | no final candidate; semantic reason NOT RECORDED | OPEN | OPEN | OPEN | OPEN | OPEN |
| G-036 | L563-L564 | no final candidate; semantic reason NOT RECORDED | OPEN | OPEN | OPEN | OPEN | OPEN |
| G-037 | L579 | no final candidate; semantic reason NOT RECORDED | OPEN | OPEN | OPEN | OPEN | OPEN |
| G-038 | L586 | no final candidate; semantic reason NOT RECORDED | OPEN | OPEN | OPEN | OPEN | OPEN |
| G-039 | L611-L618 | no final candidate; semantic reason NOT RECORDED | OPEN | OPEN | OPEN | OPEN | OPEN |
| G-040 | L619-L656 | no final candidate; semantic reason NOT RECORDED | OPEN | OPEN | OPEN | OPEN | OPEN |
| G-041 | L663-L668 | no final candidate; semantic reason NOT RECORDED | OPEN | OPEN | OPEN | OPEN | OPEN |
| G-042 | L669-L688 | no final candidate; semantic reason NOT RECORDED; L669 absent from completion prompt | OPEN | OPEN | OPEN | OPEN | OPEN |
| G-043 | L689-L792 | no final candidate; exact source present earlier in full-source tool node; no dedicated final re-presentation; semantic reason NOT RECORDED | OPEN | OPEN | OPEN | OPEN | OPEN |

## Recommended Review Order

Each batch must be self-contained. Reopen the exact frozen source lines and include the full exact criteria text and digest in the working context. Do not rely on a summary of an earlier batch.

1. Verify immutable identity, source digest, criteria digest, cache digest, and the evidence caveats. Make no semantic dispositions in this step.
2. Review L1-L78: C-001..C-025 plus every listed no-candidate span; reconcile the superseded preliminary 21-row pass.
3. Review L79-L156: C-026..C-053; focus on Equation 1 and the seven word-count split groups.
4. Review L157-L234: C-054..C-086 plus all gaps.
5. Review L235-L312: C-087..C-106; focus on Figure 2, diagram labels, and the two locator corrections.
6. Review L313-L390: C-107..C-119; reopen Table 1 and Figure 3 against the PDF.
7. Review L391-L468: C-120..C-145; focus on claims/results/limitations and C-129/C-130 fragmentation.
8. Review L469-L518: C-146..C-162; explicitly judge related-work breadth.
9. Review L519-L568: C-163..C-183; explicitly judge implementation-detail breadth and C-182/C-183 fragmentation.
10. Review L569-L618: C-184..C-204 plus URL/page/figure-label gaps.
11. Review L619-L668: C-205..C-206 and every Figure 4/example-cell gap against source and PDF.
12. Review L669-L688 from the frozen source, including the omitted L669; independently decide candidates, missing packets, and exclusions. Do not accept the recovered assistant statement by default.
13. Review L689-L792 from the frozen source; independently decide candidates, missing packets, and exclusions. The cached completion statement records an assistant decision but not its semantic reason or human approval.
14. Run a whole-source consistency pass over all decisions, duplicates, splits, breadth, missing packets, formal material, and unresolved questions.
15. Present provisional criteria observations separately. Apply no criteria change unless the human explicitly accepts it through the proper later process.
16. Ask for an explicit human SRC-001 close decision. Until then, SRC-002 remains blocked.

## Close Checklist

- [ ] Every candidate C-001 through C-206 has an explicit human disposition.
- [ ] Every candidate has a recorded human judgment and reason.
- [ ] Every source span L1-L792 is accounted for as candidate-bearing, no-candidate, excluded with rationale where determinable, or explicitly unresolved.
- [ ] Every candidate-free span has an explicit missing-packet decision.
- [ ] Every determinable exclusion reason is recorded; undeterminable reasons remain `NOT RECORDED` or unresolved rather than inferred.
- [ ] Every split and possible duplicate has been semantically reviewed.
- [ ] Every possible over-broad and over-narrow candidate has been decided.
- [ ] Equation, table, figure, diagram, caption, and degraded-text concerns have been reopened against the original PDF where available.
- [ ] L669-L688 has been independently reviewed from exact source bytes.
- [ ] L689-L792 has been independently reviewed from exact source bytes.
- [ ] Missing packets are recorded with locator, exact quote, proposed wording, criterion, and reason missed.
- [ ] Unresolved coverage and semantic questions remain visible.
- [ ] Provisional criteria observations are separate from accepted criteria changes.
- [ ] No criteria, source, historical run, fixture, cache, or canonical ledger was mutated during adjudication.
- [ ] Human close decision is explicit: `SRC-001 CLOSED FOR CALIBRATION` or `SRC-001 NOT CLOSED`.
- [ ] SRC-002 remains unstarted unless and until the human explicitly closes SRC-001.

## Human Close Decision

- decision: `OPEN`
- authority: `OPEN`
- timestamp: `OPEN`
- unresolved questions carried forward: `OPEN`
- SRC-002 authorization: `NOT AUTHORIZED BY THIS DOCUMENT`
