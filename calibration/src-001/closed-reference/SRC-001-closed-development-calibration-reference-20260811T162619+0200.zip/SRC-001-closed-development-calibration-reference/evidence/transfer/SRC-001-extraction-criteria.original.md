# Extraction Criteria — RUN-20260718T200215838Z-b836c0a930da

- written: 2026-07-18T20:29:18.450Z
- author: Eileen (human operator; Codex-prepared proposal adopted verbatim)

## Candidate-claim definition (this corpus)

A candidate claim is any source-borne assertion, definition, formal or
empirical result, design proposal, constraint, or unresolved choice that could
plausibly inform how complex systems are represented, organized, coordinated,
trained, optimized, scaled, measured, evaluated, or designed. Importance and
truth are judged later. Uncertain spans are admitted.

## Admission criteria

| # | criterion | example span that qualifies |
|---|-----------|-----------------------------|
| 1 | Definitions, measures, or properties of complexity, information, intelligence, representation, or system behavior. | SRC-024 L11-L22 defines and reports behavior of apparent complexity. |
| 2 | Architectures, components, mechanisms, interactions, memory, communication, hierarchy, or information flow. | SRC-014 L13-L18 describes coupling a neural network to external memory through attention. |
| 3 | Construction, training, optimization, scaling, resource-allocation, or implementation methods. | SRC-005 L32-L43 describes pipeline parallelism and batch splitting across accelerators. |
| 4 | Explanations linking a design choice or mechanism to behavior, performance, robustness, or generalization. | SRC-006 L12-L19 links identity mappings to signal propagation, easier training, and generalization. |
| 5 | Theoretical or empirical results, comparisons, ablations, and scaling relationships, including their conditions and metrics. | SRC-019 L39-L47 reports power-law scaling and compute-allocation consequences. |
| 6 | Assumptions, constraints, boundaries, tradeoffs, limitations, and failure modes. | SRC-016 L15-L26 states the variable-output-dictionary constraint and the proposed mechanism. |
| 7 | Design proposals, recommendations, alternatives, open choices, and stated future directions. | SRC-013 L18-L31 proposes the next search and evaluation direction for message-passing models. |

## Exclusion classes (outside candidacy, recorded here once)

| class | description | example |
|-------|-------------|---------|
| extraction-wrapper | Extraction wrapper metadata such as `SOURCE-PDF`, hashes, extractor name, and page count. | SRC-001 L1-L5 |
| document-administration | Titles, author lists, affiliations, licensing boilerplate, headings, tables of contents, page numbers, and separators when they assert nothing substantive. | SRC-023 L7-L8 licensing permission |
| bibliography-and-index | Bibliography entries, indexes, and acknowledgements without an independent subject-matter assertion. | A reference-list citation with no assertion by the source text |
| extraction-noise | Repeated navigation text and unrecoverable extraction fragments. | SRC-020 L8-L10 repeated navigation text |
| uninterpreted-fragment | Isolated equations, table cells, code fragments, or symbols without enough adjacent prose or captions to identify an assertion. Ambiguous cases are widened and admitted. | A detached numeric row with no caption or interpretive prose |
| refusal-blocked | `refusal-blocked` is inapplicable in manual mode; unreadable material remains visibly flagged rather than silently discarded. | n/a |

## Packet granularity policy

Use the smallest contiguous line span containing one coherent assertion,
widened for necessary definitions, qualifiers, conditions, or comparators.
Split independent assertions. Include claim-bearing captions or prose around
equations, tables, figures, and code. Preserve degraded text exactly and flag
it; never reconstruct missing content. Over-extract when uncertain.

## Normalization conventions (used at S3)

Preserve attribution, hedging, modality, causal versus correlational language,
conditions, quantities, units, metrics, and source-specific meanings of
"complexity." Repair only obvious line-wrap artifacts in normalized prose;
retain exact quotations and flag ambiguous OCR. Do not import external facts,
synthesize across sources, merge duplicates, resolve conflicts, or assign
dispositions.

## Supersessions

| # | date | change | re-extraction completed over |
|---|------|--------|------------------------------|

