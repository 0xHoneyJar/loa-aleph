# SRC-001 Provisional Criteria Observations Through Batch 07

> Non-authoritative observations; no criteria change was applied.

1. Page-administration interruptions continue to require multiple exact fragments rather than a fabricated contiguous quote (`E-003`).
2. Related-work sentences can require semantic splitting when they combine architecture, result, and capability assertions (`C-147`, `C-158`, `C-160`).
3. Rejected context may remain necessary solely as an antecedent dependency without becoming admitted evidence (`C-161` → `E-003`).
4. Source-relative trend language and unquantified comparative adjectives require explicit scope controls.
5. Repeated graph, attention, pipeline, breadth, and CNN/LSTM propositions remain linked as overlap rather than counted as independent evidence.

No criterion was changed, superseded, accepted, or promoted.
