# SRC-001 Gap Decisions Through Batch 11

- G-042: original no-candidate status is incorrect.
- L669-L686: admitted through T2-000 through T2-012.
- L687-L688: no packet appropriate; document administration.
- Missing-packet decision: resolved.
