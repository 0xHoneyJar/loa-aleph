# SRC-001 Coverage State Through Batch 11

- reviewed source range: `L1-L688`
- last original candidate adjudicated: `C-206`
- last gap adjudicated: `G-042`
- added units: `T2-000` through `T2-012`
- original candidate inventory: complete through `C-206`
- next source-order item: `G-043` at `L689-L792`
- Figure 4 formal-material review: closed
- Table 2 formal-material review: closed
- SRC-001: OPEN
- SRC-002: NOT AUTHORIZED
