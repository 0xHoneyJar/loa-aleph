# SRC-001 Human Decisions Through Batch 11

- exact decision event: `decision-events/SRC-001-human-decision-event-B11A-20260806T2032+0200.md`
- G-042: no-candidate status incorrect
- T2-000 through T2-012: calibration-accept, criterion 5
- L687-L688: no packet appropriate; document administration
- B10-001 / Table 2 review: closed
- C-170 Table 2 forward dependency: resolved
- C-171 remains contextual only; examples do not prove its hypotheses

The exact human decision block remains authoritative.
