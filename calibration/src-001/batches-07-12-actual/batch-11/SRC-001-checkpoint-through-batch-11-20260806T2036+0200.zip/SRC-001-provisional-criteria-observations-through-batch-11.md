# SRC-001 Provisional Criteria Observations Through Batch 11

No criteria change is adopted. Batch 11 uses an explicit representation for multi-column formal material: frozen source-group provenance is preserved separately from PDF page/row/column alignment and PDF-visible transcription. This adopted case does not itself amend the criteria.
