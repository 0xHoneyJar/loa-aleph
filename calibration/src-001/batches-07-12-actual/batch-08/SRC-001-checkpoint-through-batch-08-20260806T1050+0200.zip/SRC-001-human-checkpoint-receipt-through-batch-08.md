# SRC-001 Human Checkpoint Receipt Through Batch 08

The exact attested Batch 07 checkpoint, exact Batch 08 proposal, Batch 07 attestation receipt, all Batch 08 human decision events, and the two append-only Batch 08 event-metadata corrections are preserved in this package.

Batch 08 decisions cover C-163 through C-183 and G-033 through G-036. C-167 is replaced by S-167a and S-167b. C-184 remains unadjudicated and is the first Batch 09 candidate.

Exact-byte human attestation for this checkpoint is pending. SRC-001 remains open and SRC-002 remains unauthorized.
