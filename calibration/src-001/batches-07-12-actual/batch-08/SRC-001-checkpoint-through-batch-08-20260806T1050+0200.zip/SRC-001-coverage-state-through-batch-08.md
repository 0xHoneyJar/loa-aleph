# SRC-001 Coverage Through Batch 08

- source reviewed contiguously through L568
- original candidates adjudicated through C-183
- gaps adjudicated through G-036
- next source line: L569
- next candidate: C-184
- next gap: G-037
- SRC-001 remains open
- SRC-002 remains unauthorized
