# SRC-001 Provisional Criteria Observations Through Batch 08

No extraction-criteria change was applied or authorized.

Batch 08 reinforces—not adopts as criteria—the need to preserve explicit task/model dependencies for configuration statements, explicit continuation links when a semicolon-delimited configuration is divided across packets and batches, and visible frozen-text/PDF discrepancy flags such as the C-174 `fθ`/`fφ` mismatch.

These are provisional observations only. They are not accepted Loa-Aleph criteria, golden examples, validation, sanction, or v1 evidence.
