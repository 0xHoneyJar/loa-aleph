# SRC-001 Human Decisions Through Batch 08

> NONCANONICAL HUMAN-SUPERVISED DEVELOPMENT-CALIBRATION RECORD

Exact human wording remains in the included Batch 08 decision events. This file is a structured summary, not a replacement for those events.

## Batch 08 counts

- original candidates: 21 (`C-163` through `C-183`)
- calibration-accept: 8
- edit: 12
- too-broad: 1
- added split units: `S-167a`, `S-167b`
- gaps: 4 (`G-033` through `G-036`)
- missing packets: none

| ID | Locator | Disposition | Criterion | Event |
|---|---|---|---:|---|
| C-163 | L519-L520 | calibration-accept | 3 | B08A |
| C-164 | L520-L522 | edit | 3 | B08A |
| C-165 | L522-L524 | edit | 3 | B08A |
| C-166 | L524-L525 | edit | 3 | B08A |
| C-167 | L525-L527 | too-broad | None | B08A |
| C-168 | L528 | edit | 5 | B08A |
| C-169 | L528-L530 | edit | 5 | B08B |
| C-170 | L532-L534 | calibration-accept | 6 | B08B |
| C-171 | L534-L537 | calibration-accept | 6 | B08B |
| C-172 | L539-L540 | calibration-accept | 2 | B08B |
| C-173 | L540-L541 | edit | 3 | B08C |
| C-174 | L541-L543 | edit | 3 | B08C |
| C-175 | L543-L545 | edit | 3 | B08C |
| C-176 | L547-L548 | calibration-accept | 3 | B08C |
| C-177 | L549-L551 | calibration-accept | 1 | B08C |
| C-178 | L552-L553 | edit | 4 | B08D |
| C-179 | L554-L557 | calibration-accept | 1 | B08D |
| C-180 | L557-L559 | edit | 4 | B08D |
| C-181 | L560-L562 | calibration-accept | 3 | B08D |
| C-182 | L565-L568 | edit | 3 | B08D |
| C-183 | L568 | edit | 3 | B08D |

C-167 is replaced by S-167a and S-167b. The configuration chain from C-182 and C-183 continues into unadjudicated C-184 in Batch 09.
