# SRC-001 Coverage Through Batch 09

- reviewed source: `L1-L618`
- candidates adjudicated through: `C-204`
- gaps adjudicated through: `G-039`
- next source-order item: `G-040` at `L619-L656`
- next candidate: `C-205` at `L657-L659`
- SRC-001: OPEN
- SRC-002: NOT AUTHORIZED
