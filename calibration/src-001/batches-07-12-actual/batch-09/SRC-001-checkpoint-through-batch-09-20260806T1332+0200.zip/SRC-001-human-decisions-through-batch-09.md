# SRC-001 Human Decisions Through Batch 09

> NONCANONICAL HUMAN-SUPERVISED DEVELOPMENT-CALIBRATION CHECKPOINT

- checkpoint: `SRC-001-CHECKPOINT-THROUGH-BATCH-09-20260806T1332+0200`
- Batch 09 original candidates: `C-184` through `C-204` (`21`)
- disposition counts: `calibration-accept=7`, `edit=11`, `too-broad=2`, `too-narrow=1`
- added units: `S-190a`, `S-190b`, `S-192a`, `S-192b`
- gaps: `G-037` through `G-039`
- cross-batch repair `B8-001`: closed by C-184
- Batch 09D resume metadata: corrected additively; exact human block unchanged
- SRC-001: OPEN
- SRC-002: NOT AUTHORIZED

The exact human blocks in `decision-events/` are authoritative for this noncanonical calibration record.
