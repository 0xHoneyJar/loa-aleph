# SRC-001 Coverage State Through Batch 10

- reviewed source range: `L1-L668`
- last original candidate adjudicated: `C-206`
- last gap adjudicated: `G-041`
- original candidate inventory: complete through `C-206`
- next source-order item: `G-042` at `L669-L688`
- Figure 4 formal-material review: closed
- Table 2 formal-material review: open as `B10-001`
- SRC-001: OPEN
- SRC-002: NOT AUTHORIZED
