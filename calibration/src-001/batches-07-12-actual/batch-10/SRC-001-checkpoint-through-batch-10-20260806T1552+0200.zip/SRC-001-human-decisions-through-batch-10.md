# SRC-001 Human Decisions Through Batch 10

- exact decision event: `decision-events/SRC-001-human-decision-event-B10A-20260806T1549+0200.md`
- C-205: calibration-accept, criterion 3
- C-206: calibration-accept, criterion 5
- G-040: no standalone packet appropriate; Figure 4 labels retained as provenance
- G-041: partitioned; only L663-L664 excluded, L665-L668 retained as substantive Table 2 material
- Figure 4 review: closed
- B10-001 / Table 2 review: open pending Batch 11

The exact human decision block remains authoritative.
