# SRC-001 Gap Decisions Through Batch 10

- G-040: no standalone packet appropriate; labels/examples retained as Figure 4 provenance.
- G-041: no-candidate status is not fully appropriate. Exclude only L663-L664; retain L665-L668 and continue Table 2 review through L688.
